<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - plugins.php -
//
// Copyrights (c) 2006-2009 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

// Forbid direct call
if(!defined('SYS_INDEX')) {
	die("You can't call this file directly!");
}

//Load all active module plugins in plugin template array var
$plugins_tmpl = array();
$db->query("SELECT * FROM ".$tbl_prefix."sys_plugin WHERE status = '1' && plugin_type = '0'");

while($db->next_record()):
	$plugins_tmpl['plugin_'.$db->f("name")] = SYS_WORK_DIR."/plugins/".$db->f("install_path").$db->f("index_tmpl");
endwhile;

// Load content plugin in system template array var
if($sys_explorer_vars['link_type'] == 3) {
	if($login_required == 0) {
		$db->query("SELECT * FROM ".$tbl_prefix."sys_plugin WHERE status = '1' && plugin_type = '1' && pid = '".$sys_explorer_vars['link_plugin']."' LIMIT 1");
		
		while($db->next_record()):
			$sys_tmpl_vars['content'] = "/plugins/".$db->f("install_path").$db->f("index_tmpl");
			if($db->f("tmpl_handler") != "") {
				include(SYS_WORK_DIR."/plugins/".$db->f("install_path").$db->f("tmpl_handler"));
			}
		endwhile;
	}
}

?>