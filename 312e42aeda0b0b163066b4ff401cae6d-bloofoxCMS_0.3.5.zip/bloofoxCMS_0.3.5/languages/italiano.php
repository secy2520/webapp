<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - languages/italiano.php -
//
// Copyrights (c) 2006-2009 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

//--------------------------------------------------
// Italian Language Layer
//--------------------------------------------------

// General
$str['Name'] = "Nome";
$str['Action'] = "Azione";
$str['Save'] = "Salva";
$str['No'] = "No";
$str['Yes'] = "S�";
$str['EntryDelete'] = "Cancella elemento";
$str['DeleteQuestion'] = "Vuoi davvero cancellare il seguente elemento?";
$str['EditText'] = "Modifica";
$str['DeleteText'] = "Cancella";
$str['Edit'] = "<img src='../admin/images/icon_edit.gif' border='0' width='16' height='16' alt='Modifica' />";
$str['Delete'] = "<img src='../admin/images/icon_trash.gif' border='0' width='16' height='16' alt='Cancella' />";
$str['IcoContents'] = "<img src='../admin/images/icon_content.gif' border='0' width='16' height='16' alt='Contenuti' />";
$str['Summary'] = "Sommario";
$str['DateFormat'] = "DD.MM.YYYY";
$str['Database'] = "Database";
$str['Server'] = "Server";
$str['Logout'] = "Uscita";
$str['CaptchaCode'] = "Inserisci per favore il seguente codice:";
$str['Print'] = "Vista stampa";
$str['Mail'] = "E-Mail";
$str['EditorEdit'] = "Editor";
$str['Dir'] = "Cartella";
$str['All'] = "Totale";
$str['SaveAndClose'] = "Salva e Chiudi";
$str['Settings'] = "Impostazioni";
$str['Administration'] = "Amministrazione";
$str['Security'] = "Sicurezza";
$str['Tools'] = "Utilit�";
$str['Version'] = "Versione";
$str['VersionUpdate'] = "There is a newer version of bloofoxCMS available. It is recommended to update to the latest version.";
$str['TopOfSite'] = "Torna all'inizio";
$str['Sorting'] = "Ordinamento";
$str['IcoPreview'] = "<img src='../admin/images/icon_preview.gif' border='0' width='16' height='16' alt='Anteprima' />";
$str['Preview'] = "Anteprima";
$str['Options'] = "Opzioni";
$str['General'] = "Generale";
$str['Next'] = "Avanti &gt;&gt;";
$str['Prev'] = "&lt&lt; Indietro";
$str['Quit'] = "Esci";
$str['Content'] = "Contenuto";
$str['AddText'] = "Nuovo";
$str['Legend'] = "Leggenda";
$str['SystemInformation'] = "Informazioni di Sistema";
$str['Notice'] = "Notice";
$str['NoticeArticlesNotFound'] = "Articles were not found for this page.";

// Filter
$str['SetFilter'] = "Filtro";
$str['FilterShowAllProjects'] = "Show all projects";
$str['FilterShowAllTypes'] = "Show all types";
$str['FilterShowAllPages'] = "Show all pages";
$str['FilterShowAllUsers'] = "Show all users";

// Contents
$str['Contents'] = "Contenuti";
$str['Levels'] = "Assortimento";
$str['Articles'] = "Articoli";
$str['Pages'] = "Pagine";
$str['ContentEdit'] = "Modifica Contenuto";
$str['HeadLine'] = "Intestazione";
$str['TextContent'] = "Contenuto testuale";
$str['SaveChanges'] = "Salva Modifiche";
$str['LinkType0'] = "Standard";
$str['LinkType1'] = "URL esterno";
$str['LinkType2'] = "Scorciatoia";
$str['LinkType3'] = "Plugin";
$str['EntryAdd'] = "Add Entry";
$str['EntryEdit'] = "Modify Entry";
$str['EntryDelete'] = "Delete Entry";
$str['PageAdd'] = "Aggiungi Pagina";
$str['PageEdit'] = "Modifica Pagina";
$str['PageDelete'] = "Cancella Pagina";
$str['Type'] = "Tipo";
$str['TargetWindow'] = "Destinazione";
$str['Url'] = "Url";
$str['Shortcut'] = "Scorciatoia";
$str['ShortcutOption1'] = "- Nessuna -";
$str['Blocked'] = "Bloccato";
$str['Hidden'] = "Nascosto";
$str['Groups'] = "Gruppi";
$str['SubPermissions'] = "Propaga i Permessi";
$str['Startdate'] = "Data d'inizio";
$str['Enddate'] = "Data di fine";
$str['Keywords'] = "Keywords";
$str['InsertAfter'] = "Inserisci dopo";
$str['InsertAfterOption1'] = "- All'inizio -";
$str['MoveLeft'] = "Muovi a sinistra";
$str['MoveRight'] = "Muovi a destra";
$str['MoveUp'] = "Muovi Su";
$str['MoveDown'] = "Muovi Gi�";
$str['Images'] = "Elenco d'immagini";
$str['PostedBy'] = "Inserito da";
$str['PageHandling'] = "Pagina";
$str['CreatedBy'] = "Creato da";
$str['CreatedAt'] = "Creato il";
$str['ChangedBy'] = "Modificato da";
$str['ChangedAt'] = "Modificato il";
$str['Parameter'] = "Parametro";
$str['DefaultContents'] = "Testi di Default";
$str['ArticleAdd'] = "Aggiungi Articolo";
$str['ArticleEdit'] = "Modifica Articolo";
$str['ArticleDelete'] = "Cancella Articolo";
$str['Top'] = "In cima";
$str['Bottom'] = "In fondo";
$str['SameLevel'] = "Stesso Livello";
$str['Underneath'] = "Al di sotto";
$str['EntryID'] = "Pagina N�";
$str['PreID'] = "Pagina Su";
$str['IcoLeft'] = "<img src='images/icon_left.gif' border='0' width='16' height='16' alt='".$str['MoveLeft']."' />";
$str['IcoRight'] = "<img src='images/icon_right.gif' border='0' width='16' height='16' alt='".$str['MoveRight']."' />";
$str['IcoUp'] = "<img src='images/icon_up.gif' border='0' width='16' height='16' alt='".$str['MoveUp']."' />";
$str['IcoDown'] = "<img src='images/icon_down.gif' border='0' width='16' height='16' alt='".$str['MoveDown']."' />";
$str['Pictures'] = "Immagini";
$str['Page'] = "Pagina";

// Profile
$str['MyProfile'] = "Mio Profilo";
$str['ProfileEdit'] = "Modifica il Mio Profilo";
$str['Firstname'] = "Nome";
$str['Lastname'] = "Cognome";
$str['Address1'] = "Indirizzo 1";
$str['Address2'] = "Indirizzo 2";
$str['City'] = "Citt�";
$str['ZipCode'] = "C.A.P.";
$str['Email'] = "E-Mail";
$str['Birthday'] = "Data di nascita";
$str['Gender'] = "Sesso";
$str['Picture'] = "Foto";
$str['BeLang'] = "Lingua dell'Admincenter";
$str['BeStyle'] = "Stile dell'Admincenter";
$str['GenderMale'] = "Maschio";
$str['GenderFemale'] = "Femmina";
$str['PrivateProfile'] = "Mostra Profilo";
$str['ContactInfo'] = "Informazioni di contatto";
$str['ShowEmail'] = "Show E-Mail";
$str['DeletePicture'] = "Cancella Foto";

// Projects
$str['Configurations'] = "Progetti";
$str['ConfigurationAdd'] = "Aggiungi Progetto";
$str['ConfigurationEdit'] = "Modifica Progetto";
$str['ConfigurationDelete'] = "Cancella Progetto";
$str['Language'] = "Lingua";
$str['Template'] = "Tema grafico";
$str['Urls'] = "Url (uno per riga)";
$str['RootPage'] = "Pagina di partenza";
$str['Title'] = "Titolo";
$str['MetaDescription'] = "Meta-Description";
$str['MetaKeywords'] = "Meta-Keywords";
$str['MetaAuthor'] = "Meta-Author";
$str['MetaCharset'] = "Meta-Charset";
$str['MetaDocType'] = "Meta-DocType";
$str['Copyright'] = "Meta-Copyright";
$str['ModRewrite'] = "mod_rewrite";
$str['DefaultGroup'] = "Gruppo Utenti di default";
$str['UserActivation'] = "User Activation";

// Home
$str['WelcomeToAdmincenter'] = "Benvenuto nell'Admincenter";
$str['YourLastLogin'] = "La tua ultima visita era stata il";
$str['WhoIsOnline'] = "Chi c'� online";
$str['Statistics'] = "Statistiche";
$str['YourIPAddress'] = "Your IP address is";
$str['InfoIPLog'] = "Your IP address was logged for security reasons.";
$str['WarningChangePassword'] = "Warning! It is strongly recommended to change the admin's password.";
$str['PasswordChanged'] = "Password successfully changed.";

// Login
$str['Username'] = "Username";
$str['Password'] = "Password";
$str['Login'] = "Login";
$str['FailedLogins'] = "Errori di login dall'ultimo login";
$str['UnblockAccount'] = "Sblocca il tuo account";
$str['AccountWasBlocked'] = "Il tuo account � stato bloccato in seguito a troppi tentativi errati di login. Clicca il link sottostante per sbloccare il tuo account:\n";
$str['LoggedIn'] = "Sei connesso come: ";
$str['NotLoggedIn'] = "Non sei connesso!";
$str['MyAccount'] = "Il Mio Account";
$str['OldPassword'] = "Current Password";
$str['NewPassword'] = "New Password";
$str['ChangePw'] = "Change Password";

// Mediacenter
$str['Mediacenter'] = "Media";
$str['MediafileAdd'] = "Aggiungi un Mediafile";
$str['File'] = "File";
$str['Image'] = "Immagine";
$str['MediafileEdit'] = "Modifica Mediafile";
$str['MediafileDelete'] = "Cancella Mediafile";
$str['FileAdd'] = "Aggiungi File";
$str['FileSize'] = "Dimensioni File";

//Plugins
$str['Plugins'] = "Plugins";
$str['Path'] = "Percorso";
$str['PluginAdd'] = "Aggiungi Plugin";
$str['Plugin'] = "Plugin";
$str['PluginDelete'] = "Cancella Plugin";
$str['PluginEdit'] = "Modifica Plugin";
$str['PluginID'] = "ID";

// Templates
$str['Templates'] = "Modelli";
$str['TemplateAdd'] = "Aggiungi Tema grafico";
$str['CSS'] = "CSS";
$str['Backend'] = "Backend";
$str['TemplateEdit'] = "Modifica Tema grafico";
$str['TemplateDelete'] = "Cancella Tema grafico";
$str['CreateNewDir'] = "Crea una nuova Cartella...";
$str['DirName'] = "Nome Cartella";
$str['TmplPrint'] = "Print View";
$str['TmplPrintCSS'] = "Print View CSS";
$str['TmplLogin'] = "Login";
$str['TmplText'] = "Article";

// Languages
$str['Languages'] = "Lingue";
$str['LanguageAdd'] = "Aggiungi Lingua";
$str['Flag'] = "Bandiera";
$str['LanguageEdit'] = "Modifica Lingua";
$str['LanguageDelete'] = "Cancella Lingua";
$str['DateFormula'] = "Formula per la Data";
$str['DateTimeFormula'] = "Formula per Data/Ora";
$str['Token'] = "Token";
$str['CreateNewFile'] = "Crea nuovo file...";
$str['FileName'] = "Nome File";

// Settings
$str['UpdateCheck'] = "Controlla la disponibilit� di una nuova versione in Admincenter home.";
$str['RegisterNotification'] = "Invia la notifica di registrazione all'admin per ogni registrazione.";
$str['LoginProtection'] = "Usa protezione del login/session logging.";
$str['OnlineStatus'] = "Aggiorna lo status di online ad ogni richiesta.";
$str['UserContentOnly'] = "Gli Utenti possono modificare solo i propri contenuti.";
$str['AdminMail'] = "Administrator mail address for notifications";
$str['HtmlMails'] = "Send mails in HTML format";
$str['HtmlEntitiesOff'] = "Deactivate PHP function htmlentities()";
$str['PasswordRule'] = "Password rule for user passwords";
$str['TextboxWidth'] = "Textbox width of wysiwyg editor (Pixel)";
$str['PwRule0'] = "None";
$str['PwRule1'] = "Medium";
$str['PwRule2'] = "Strict";

// Security
$str['User'] = "Utenti";
$str['Permissions'] = "Permessi";
$str['Read'] = "Lettura";
$str['Write'] = "Scrittura";
$str['Del'] = "Cancellazione";
$str['GroupAdd'] = "Aggiungi Gruppo";
$str['Demo'] = "Demo";
$str['GroupEdit'] = "Modifica Gruppo";
$str['GroupDelete'] = "Cancella Gruppo";
$str['Config'] = "Progetto";
$str['UserAdd'] = "Aggiungi Utente";
$str['Deleted'] = "Cancellato";
$str['Status'] = "Status";
$str['Inactive'] = "Disattivato";
$str['Active'] = "Attivo";
$str['UserEdit'] = "Modifica Utente";
$str['UserDelete'] = "Cancella Utente";
$str['PermissionsAdd'] = "Aggiungi Permessi";
$str['Group'] = "Gruppo";
$str['Area'] = "Area";
$str['PermissionsEdit'] = "Modifica Permessi";
$str['PermissionsDelete'] = "Cancella Permessi";
$str['EditUserProfile'] = "Modifica Profilo";
$str['IcoProfile'] = "<img src='../admin/images/icon_profile.gif' border='0' width='16' height='16' alt='Modifica Profilo' />";
$str['AreaConfigurations'] = "Home: Progetti";
$str['AreaLanguages'] = "Amministrazione: Lingue";
$str['AreaTemplates'] = "Amministrazione: Modelli";
$str['AreaPlugins'] = "Amministrazione: Plugins";
$str['AreaCharsets'] = "Amministrazione: Charsets";
$str['AreaSettings'] = "Amministrazione: Impostazioni";
$str['AreaExplorer'] = "Contenuti: Pagine";
$str['AreaContentsDefault'] = "Contenuti: Standard";
$str['AreaContentsPlugins'] = "Contenuti: Plugins";
$str['AreaMediacenter'] = "Contenuti: Media";
$str['AreaLevels'] = "Contenuti: Livelli";
$str['AreaEditor'] = "Editor";
$str['AreaUser'] = "Sicurezza: Utente";
$str['AreaGroups'] = "Sicurezza: Gruppi";
$str['AreaPermissions'] = "Sicurezza: Permessi";
$str['AreaSessions'] = "Sicurezza: Sessioni";
$str['AreaTools'] = "Utilit�";
$str['LoginPage'] = "Pagina di Utente";
$str['RegisterDate'] = "Data di Registrazione";

// Charsets
$str['Charset'] = "Charsets";
$str['CharsetAdd'] = "Aggiungi Charset";
$str['CharsetEdit'] = "Modifica Charset";
$str['CharsetDelete'] = "Cancella Charset";
$str['Description'] = "Descrizione";

// Tools
$str['Activity'] = "Attivit� Nome";
$str['ToolsActivities'] = "Attivit�";
$str['ToolsImport'] = "Importa";
$str['ToolsExport'] = "Esporta";
$str['ToolsUpload'] = "Upload";
$str['ToolsPhpmyadmin'] = "PhpMyAdmin";
$str['OptimizeDB'] = "Ottimizza il database";
$str['ClearInactiveUsers'] = "Cancella gli utenti inattivi";
$str['ClearDeletedUsers'] = "Cancella gli utenti eliminati";
$str['ClearSessions'] = "Cancella le sessioni";
$str['ClearFailedSessions'] = "Cancella solo le sessioni fallite";
$str['PhpMyAdmin'] = "Apre PhpMyAdmin";
$str['RegisterTillDate'] = "registrati fino alla data:";
$str['LoginTillDate'] = "Logins fino alla data:";
$str['TemplateFile'] = "File di Tema grafico";
$str['TemplateImage'] = "Immagine di Tema grafico";
$str['UploadFiles'] = "Upload file";
$str['HyperlinkNotConfigured'] = "Il collegamento non � stato definito (nel file config.php)";
$str['ToolsBackup'] = "Backup";

// Sessions
$str['Date'] = "Data";
$str['Time'] = "Ora";
$str['MySession'] = "Mia Sessione";
$str['KillSession'] = "Chiudi Sessione";
$str['IcoExit'] = "<img src='../admin/images/icon_exit.gif' border='0' width='16' height='16' alt='".$str['KillSession']."' />";
$str['TypeOpen'] = "Aperta";
$str['TypeClosed'] = "Chiusa";
$str['StatusFailed'] = "Login fallito";
$str['StatusOK'] = "Login Corretto";

// Errors
$str['ErrorName'] = "Occorre inserire un nome.";
$str['ErrorStartdate'] = "Data iniziale errata. Fai attenzione al formato.";
$str['ErrorEnddate'] = "Data finale errata. Fai attenzione al formato.";
$str['ErrorLinkType'] = "Devi selezionare una scorciatoia, se il tipo � definito come tale.";
$str['ErrorLinkTypePlugin'] = "Devi selezionare il tipo = Plugin, se hai scelto un plugin.";
$str['ErrorFirstname'] = "Occorre inserire il nome.";
$str['ErrorEmail'] = "Occorre inserire un indirizzo e-mail.";
$str['ErrorEmailValid'] = "Occorre inserire un indirizzo e-mail valido.";
$str['ErrorPictureSize'] = "La dimensione del file non pu� superare 15 KB.";
$str['ErrorPictureType'] = "Puoi caricare solo immagini di tipo GIF e JPEG.";
$str['ErrorPictureExist'] = "Il nome file � gi� presente sul server.";
$str['ErrorTitle'] = "Occorre inserire un titolo.";
$str['ErrorLogin'] = "Username e/o password errati.";
$str['ErrorFile'] = "Occorre selezionare un file.";
$str['ErrorFileExist'] = "Il nome file � gi� presente sul server.";
$str['ErrorWritePermission'] = "Non si dispone del permesso di scrittura (chmod 777) per scrivere in questa cartella.";
$str['ErrorWritePermissionFile'] = "You have no write permissions (chmod 666) to write in this file.";
$str['ErrorTemplate'] = "Occorre inserire il nome di un file di Tema grafico.";
$str['ErrorCSS'] = "Occorre inserire il nome di un file CSS.";
$str['ErrorTemplatePrint'] = "You must select a print view template file.";
$str['ErrorTemplatePrintCSS'] = "You must select a print view CSS file.";
$str['ErrorTemplateLogin'] = "You must select a login template file.";
$str['ErrorTemplateText'] = "You must select an article template file.";
$str['ErrorFolderExist'] = "La cartella � gi� presente sul server.";
$str['ErrorTemplateNotExist'] = "Il file di Tema grafico non esiste sul server.";
$str['ErrorCSSNotExist'] = "Il file CSS non esiste sul server.";
$str['ErrorFilename'] = "Occorre inserire un nome per il file.";
$str['ErrorFileNotExist'] = "Il file non esiste sul server.";
$str['ErrorFlag'] = "Occorre selzionare una bandiera.";
$str['ErrorUsername'] = "Occorre inserire un username.";
$str['ErrorUsernameShort'] = "L'username deve consistere di almeno 3 caratteri.";
$str['ErrorUsernameExist'] = "L'username esiste gi�.";
$str['ErrorPassword'] = "Occorre inserire una password.";
$str['ErrorPasswordShort'] = "La password deve consistere di almeno 6 caratteri.";
$str['ErrorPasswordValid1'] = "La password deve consistere sia di lettere, sia di numeri.";
$str['ErrorPasswordValid2'] = "The password must consist of numbers, letters and special signs (@!?|-_:+*.).";
$str['ErrorUserGroupPermission'] = "Non disponi dei permessi utente per vedere questa pagina.";
$str['ErrorLoginGroup'] = "Non disponi di permessi per vedere questa pagina.";
$str['ErrorCaptcha'] = "Prego inserisci un codice valido.";
$str['ErrorInstallPhp'] = "install.php non esiste in";
$str['ErrorPluginExist'] = "PluginID esiste gi� nella tabella";
$str['ErrorVersionCheck'] = "Errore: impossibile controllare l'ultima versione disponibile! Prego controlla manualmente.";
$str['ErrorDeleteGroup'] = "Impossibile cancellare un gruppo che � ancora in uso.";
$str['ErrorLoginMissingGroup'] = "Spiacente: non disponi dei permessi per accedere a questo contenuto.";
$str['ErrorInvalidDate'] = "Data errata.";
$str['ErrorIntegerOnly'] = "You may insert only integer values.";
$str['ErrorOldPassword'] = "Your current password is wrong.";
$str['ErrorDemoMode'] = "You are logged in as Demo user.";

// Plugin Date
$months = array(
1=>"Gennaio",
2=>"Febbraio",
3=>"Marzo",
4=>"Aprile",
5=>"Maggio",
6=>"Giugno",
7=>"Luglio",
8=>"Agosto",
9=>"Settembre",
10=>"Ottobre",
11=>"Novembre",
12=>"Dicembre");
$days = array(
"Domenica",
"Luned�",
"Marted�",
"Mercoled�",
"Gioved�",
"Venerd�",
"Sabato");
$date_vars['format'] = "[WEEKDAY], [DAY] [MONTH] [YEAR]";

// Plugin Sitemap
$str['Sitemap'] = "Mappa del Sito";

// Plugin Search/Searchbox
$str['Search'] = "Cerca";
$str['SearchResult'] = "Risultato della ricerca";
$str['SearchSubmit'] = "Cerca";
$str['SearchNotFound'] = "La ricerca non ha dato risultati.";
$str['SearchSubmitShort'] = "Cerca";

// Plugin Contact
$str['ContactSubject'] = "Modulo inviato tramite Web";
$str['Contact'] = "Contatto";
$str['Phone'] = "Telefono";
$str['Message'] = "Messaggio";
$str['MessageSubmit'] = "Invia il Messaggio";
$str['ErrorMessage'] = "Occorre inserire un messaggio.";
$str['ContactMessageSent'] = "Grazie della comunicazione! Messaggio inviato con successo.";

// Plugin Location
$str['Location'] = "Sei qui: ";
$str['Home'] = "Home";

// Plugin Register
$str['RegNew'] = "Registra un nuovo Account";
$str['RegNewDone'] = "Registrazione completata con successo";
$str['RegNewConfirm'] = "Conferma della Registrazione";
$str['RegPassword'] = "Password (conferma)";
$str['RegErrorPassword'] = "Le due password inserite non coincidono.";
$str['RegNewSubmit'] = "Registrazione &amp; Creazione di un Account";
$str['RegInfo'] = "Prego compila il modulo: tutti i campi sono indispensabili!";
$str['RegDone'] = "Grazie per aver registrato un account. Un <b>messaggio</b> con il tuo <b>link di attivazione</b> � stato spedito al tuo indirizzo email; prego controlla la tua casella! Devi attivare il tuo account per poterlo utilizzare.";
$str['RegConfirm'] = "Il tuo account � stato attivato con successo.";
$str['RegSubject'] = "Registrazione / Attivazione dell'Account";
$str['RegMsg'] = "Ciao [USERNAME],
Prego attiva il tuo account cliccando il link qui sotto:

[HYPERLINK]

Distinti saluti

[AUTHOR]
[URL]";
$str['RegConfirmError'] = "Nessun account valido per l'attivazione.";
$str['RegMsgAdmin'] = "Messaggio creato in automatico.

Un nuovo utente si � registrato su [URL] :

Username: [USERNAME]
E-Mail: [EMAIL]
Sesso: [GENDER]

...powered by bloofoxCMS.";
?>
