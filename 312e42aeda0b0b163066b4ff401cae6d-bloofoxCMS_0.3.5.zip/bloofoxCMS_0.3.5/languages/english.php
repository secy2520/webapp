<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - languages/english.php -
//
// Copyrights (c) 2006-2009 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

//--------------------------------------------------
// English Language Layer
//--------------------------------------------------

// General
$str['Name'] = "Name";
$str['Action'] = "Action";
$str['Save'] = "Save";
$str['No'] = "No";
$str['Yes'] = "Yes";
$str['EntryDelete'] = "Delete Entry";
$str['DeleteQuestion'] = "Do you really like to delete the following entry?";
$str['EditText'] = "Modify";
$str['DeleteText'] = "Delete";
$str['Edit'] = "<img src='../admin/images/icon_edit.gif' border='0' width='16' height='16' alt='Modify' />";
$str['Delete'] = "<img src='../admin/images/icon_trash.gif' border='0' width='16' height='16' alt='Delete' />";
$str['IcoContents'] = "<img src='../admin/images/icon_content.gif' border='0' width='16' height='16' alt='Contents' />";
$str['Summary'] = "Summary";
$str['DateFormat'] = "DD.MM.YYYY";
$str['Database'] = "Database";
$str['Server'] = "Server";
$str['Logout'] = "Logout";
$str['CaptchaCode'] = "Please enter the following code: <img src='admin/images/icon_help.gif' border='0' width='16' height='16' alt='Case sensitive, no spaces' title='Case sensitive, no spaces' />";
$str['Print'] = "Print View";
$str['Mail'] = "E-Mail";
$str['EditorEdit'] = "Editor";
$str['Dir'] = "Directory";
$str['All'] = "Total";
$str['SaveAndClose'] = "Save and Close";
$str['Settings'] = "Settings";
$str['Administration'] = "Administration";
$str['Security'] = "Security";
$str['Tools'] = "Tools";
$str['Version'] = "Version";
$str['VersionUpdate'] = "There is a newer version of bloofoxCMS available. It is recommended to update to the latest version.";
$str['TopOfSite'] = "Back to Top";
$str['Sorting'] = "Sorting";
$str['IcoPreview'] = "<img src='../admin/images/icon_preview.gif' border='0' width='16' height='16' alt='Preview' />";
$str['Preview'] = "Preview";
$str['Options'] = "Options";
$str['General'] = "General";
$str['Next'] = "Next &gt;&gt;";
$str['Prev'] = "&lt&lt; Previous";
$str['Quit'] = "Quit";
$str['Content'] = "Content";
$str['AddText'] = "New";
$str['Legend'] = "Legend";
$str['SystemInformation'] = "System Information";
$str['Notice'] = "Notice";
$str['NoticeArticlesNotFound'] = "Articles were not found for this page.";

// Filter
$str['SetFilter'] = "Filter";
$str['FilterShowAllProjects'] = "Show all projects";
$str['FilterShowAllTypes'] = "Show all types";
$str['FilterShowAllPages'] = "Show all pages";
$str['FilterShowAllUsers'] = "Show all users";

// Contents
$str['Contents'] = "Contents";
$str['Levels'] = "Sorting";
$str['Articles'] = "Articles";
$str['Pages'] = "Pages";
$str['ContentEdit'] = "Modify Contents";
$str['HeadLine'] = "Headline";
$str['TextContent'] = "Text";
$str['SaveChanges'] = "Save Changes";
$str['LinkType0'] = "Standard";
$str['LinkType1'] = "External Url";
$str['LinkType2'] = "Shortcut";
$str['LinkType3'] = "Plugin";
$str['EntryAdd'] = "Add Entry";
$str['EntryEdit'] = "Modify Entry";
$str['EntryDelete'] = "Delete Entry";
$str['PageAdd'] = "Add Page";
$str['PageEdit'] = "Modify Page";
$str['PageDelete'] = "Delete Page";
$str['Type'] = "Type";
$str['TargetWindow'] = "Target";
$str['Url'] = "Url";
$str['Shortcut'] = "Shortcut";
$str['ShortcutOption1'] = "- None -";
$str['Blocked'] = "Blocked";
$str['Hidden'] = "Hidden";
$str['Groups'] = "Groups";
$str['SubPermissions'] = "Relay Permissions";
$str['Startdate'] = "Starting Date";
$str['Enddate'] = "Ending Date";
$str['Keywords'] = "Keywords";
$str['InsertAfter'] = "Insert after";
$str['InsertAfterOption1'] = "- At the beginning -";
$str['MoveLeft'] = "Move Left";
$str['MoveRight'] = "Move Right";
$str['MoveUp'] = "Move Up";
$str['MoveDown'] = "Move Down";
$str['Images'] = "Image List";
$str['PostedBy'] = "posted by";
$str['PageHandling'] = "Page";
$str['CreatedBy'] = "Created by";
$str['CreatedAt'] = "Created at";
$str['ChangedBy'] = "Changed by";
$str['ChangedAt'] = "Changed at";
$str['Parameter'] = "Parameter";
$str['DefaultContents'] = "Default Texts";
$str['ArticleAdd'] = "Add Article";
$str['ArticleEdit'] = "Modify Article";
$str['ArticleDelete'] = "Delete Article";
$str['Top'] = "At the top";
$str['Bottom'] = "At the bottom";
$str['SameLevel'] = "Same Level";
$str['Underneath'] = "Underneath";
$str['EntryID'] = "Page No.";
$str['PreID'] = "Previous";
$str['IcoLeft'] = "<img src='images/icon_left.gif' border='0' width='16' height='16' alt='".$str['MoveLeft']."' />";
$str['IcoRight'] = "<img src='images/icon_right.gif' border='0' width='16' height='16' alt='".$str['MoveRight']."' />";
$str['IcoUp'] = "<img src='images/icon_up.gif' border='0' width='16' height='16' alt='".$str['MoveUp']."' />";
$str['IcoDown'] = "<img src='images/icon_down.gif' border='0' width='16' height='16' alt='".$str['MoveDown']."' />";
$str['Pictures'] = "Images";
$str['Page'] = "Page";

// Profile
$str['MyProfile'] = "My Profile";
$str['ProfileEdit'] = "Edit Profile";
$str['FirstName'] = "First Name";
$str['LastName'] = "Last Name";
$str['Address1'] = "Address 1";
$str['Address2'] = "Address 2";
$str['City'] = "City";
$str['ZipCode'] = "Zip-Code";
$str['Email'] = "E-Mail";
$str['Birthday'] = "Date of Birth";
$str['Gender'] = "Gender";
$str['Picture'] = "Picture";
$str['BeLang'] = "Admincenter Language";
$str['BeStyle'] = "Admincenter Style";
$str['GenderMale'] = "Male";
$str['GenderFemale'] = "Female";
$str['PrivateProfile'] = "Show Profile";
$str['ContactInfo'] = "Contact Information";
$str['ShowEmail'] = "Show E-Mail";
$str['DeletePicture'] = "Delete Picture";

// Projects
$str['Configurations'] = "Projects";
$str['ConfigurationAdd'] = "Add Project";
$str['ConfigurationEdit'] = "Modify Project";
$str['ConfigurationDelete'] = "Delete Project";
$str['Language'] = "Language";
$str['Template'] = "Template";
$str['Urls'] = "Urls (one per line)";
$str['RootPage'] = "Root Page";
$str['Title'] = "Title";
$str['MetaDescription'] = "Meta-Description";
$str['MetaKeywords'] = "Meta-Keywords";
$str['MetaAuthor'] = "Meta-Author";
$str['MetaCharset'] = "Meta-Charset";
$str['MetaDocType'] = "Meta-DocType";
$str['Copyright'] = "Meta-Copyright";
$str['ModRewrite'] = "mod_rewrite";
$str['DefaultGroup'] = "Default User Group";
$str['UserActivation'] = "User Activation by Admin";

// Home
$str['WelcomeToAdmincenter'] = "Welcome to the Admincenter";
$str['YourLastLogin'] = "Your last login was on";
$str['WhoIsOnline'] = "Who is online";
$str['Statistics'] = "Statistics";
$str['YourIPAddress'] = "Your IP address is";
$str['InfoIPLog'] = "Your IP address was logged for security reasons.";
$str['WarningChangePassword'] = "Warning! It is strongly recommended to change the admin's password.";
$str['PasswordChanged'] = "Password successfully changed.";

// Login
$str['Username'] = "Username";
$str['Password'] = "Password";
$str['Login'] = "Login";
$str['FailedLogins'] = "Failed logins since last login";
$str['UnblockAccount'] = "Unblock your account";
$str['AccountWasBlocked'] = "Your account has been blocked after too many failed logins. Click the link below to unblock your account:\n";
$str['LoggedIn'] = "You are logged in as: ";
$str['NotLoggedIn'] = "You are not logged in!";
$str['MyAccount'] = "My Account";
$str['OldPassword'] = "Current Password";
$str['NewPassword'] = "New Password";
$str['ChangePw'] = "Change Password";

// Mediacenter
$str['Mediacenter'] = "Media";
$str['MediafileAdd'] = "Add Mediafile";
$str['File'] = "File";
$str['Image'] = "Image";
$str['MediafileEdit'] = "Modify Mediafile";
$str['MediafileDelete'] = "Delete Mediafile";
$str['FileAdd'] = "Add File";
$str['FileSize'] = "File Size";

//Plugins
$str['Plugins'] = "Plugins";
$str['Path'] = "Path";
$str['PluginAdd'] = "Add Plugin";
$str['Plugin'] = "Plugin";
$str['PluginDelete'] = "Delete Plugin";
$str['PluginEdit'] = "Modify Plugin";
$str['PluginID'] = "ID";

// Templates
$str['Templates'] = "Templates";
$str['TemplateAdd'] = "Add Template";
$str['CSS'] = "CSS";
$str['Backend'] = "Backend";
$str['TemplateEdit'] = "Modify Template";
$str['TemplateDelete'] = "Delete Template";
$str['CreateNewDir'] = "Create new folder...";
$str['DirName'] = "Folder name";
$str['TmplPrint'] = "Print View";
$str['TmplPrintCSS'] = "Print View CSS";
$str['TmplLogin'] = "Login";
$str['TmplText'] = "Article";

// Languages
$str['Languages'] = "Languages";
$str['LanguageAdd'] = "Add Language";
$str['Flag'] = "Flag";
$str['LanguageEdit'] = "Modify Language";
$str['LanguageDelete'] = "Delete Language";
$str['DateFormula'] = "Date Formula";
$str['DateTimeFormula'] = "Date-/Time Formula";
$str['Token'] = "Token";
$str['CreateNewFile'] = "Create new file...";
$str['FileName'] = "File name";

// Settings
$str['UpdateCheck'] = "Check for new versions in Admincenter home.";
$str['RegisterNotification'] = "Send register notification to admin with each registration";
$str['LoginProtection'] = "Use login protection/session logging";
$str['OnlineStatus'] = "Refresh online status with each request";
$str['UserContentOnly'] = "Users can modify own contents only";
$str['AdminMail'] = "Administrator mail address for notifications";
$str['HtmlMails'] = "Send mails in HTML format";
$str['HtmlEntitiesOff'] = "Deactivate PHP function htmlentities()";
$str['PasswordRule'] = "Password rule for user passwords";
$str['TextboxWidth'] = "Textbox width of wysiwyg editor (Pixel)";
$str['PwRule0'] = "None";
$str['PwRule1'] = "Medium";
$str['PwRule2'] = "Strict";

// Security
$str['User'] = "Users";
$str['Permissions'] = "Rights";
$str['Read'] = "Read";
$str['Write'] = "Write";
$str['Del'] = "Delete";
$str['GroupAdd'] = "Add Group";
$str['Demo'] = "Demo";
$str['GroupEdit'] = "Modify Group";
$str['GroupDelete'] = "Delete Group";
$str['Config'] = "Project";
$str['UserAdd'] = "Add User";
$str['Deleted'] = "Deleted";
$str['Status'] = "Status";
$str['Inactive'] = "Inactive";
$str['Active'] = "Active";
$str['UserEdit'] = "Modify User";
$str['UserDelete'] = "Delete User";
$str['PermissionsAdd'] = "Add Rights";
$str['Group'] = "Group";
$str['Area'] = "Area";
$str['PermissionsEdit'] = "Modify Rights";
$str['PermissionsDelete'] = "Delete Rights";
$str['EditUserProfile'] = "Modify Profile";
$str['IcoProfile'] = "<img src='../admin/images/icon_profile.gif' border='0' width='16' height='16' alt='Modify Profile' />";
$str['AreaConfigurations'] = "Administration: Projects";
$str['AreaLanguages'] = "Administration: Languages";
$str['AreaTemplates'] = "Administration: Templates";
$str['AreaPlugins'] = "Administration: Plugins";
$str['AreaCharsets'] = "Administration: Charsets";
$str['AreaSettings'] = "Administration: Settings";
$str['AreaExplorer'] = "Contents: Pages";
$str['AreaContentsDefault'] = "Contents: Articles";
$str['AreaContentsPlugins'] = "Contents: Plugins";
$str['AreaMediacenter'] = "Contents: Media";
$str['AreaLevels'] = "Contents: Sorting";
$str['AreaEditor'] = "Editor";
$str['AreaUser'] = "Security: User";
$str['AreaGroups'] = "Security: Groups";
$str['AreaPermissions'] = "Security: Permissions";
$str['AreaSessions'] = "Security: Sessions";
$str['AreaTools'] = "Tools";
$str['LoginPage'] = "User Page";
$str['RegisterDate'] = "Register Date";

// Charsets
$str['Charset'] = "Charsets";
$str['CharsetAdd'] = "Add Charset";
$str['CharsetEdit'] = "Modify Charset";
$str['CharsetDelete'] = "Delete Charset";
$str['Description'] = "Description";

// Tools
$str['Activity'] = "Activity Name";
$str['ToolsActivities'] = "Activities";
$str['ToolsImport'] = "Import";
$str['ToolsExport'] = "Export";
$str['ToolsUpload'] = "Upload";
$str['ToolsPhpmyadmin'] = "PhpMyAdmin";
$str['OptimizeDB'] = "Optimize database";
$str['ClearInactiveUsers'] = "Clear inactive users";
$str['ClearDeletedUsers'] = "Clear deleted users";
$str['ClearSessions'] = "Clear sessions";
$str['ClearFailedSessions'] = "Clear only failed sessions";
$str['PhpMyAdmin'] = "Open PhpMyAdmin";
$str['RegisterTillDate'] = "registered until date:";
$str['LoginTillDate'] = "Logins until date:";
$str['TemplateFile'] = "Template file";
$str['TemplateImage'] = "Template image";
$str['UploadFiles'] = "Upload files";
$str['HyperlinkNotConfigured'] = "A hyperlink is currently not defined in file admin/config.php";
$str['ToolsBackup'] = "Backup";

// Sessions
$str['Date'] = "Date";
$str['Time'] = "Time";
$str['MySession'] = "My Session";
$str['KillSession'] = "Quit Session";
$str['IcoExit'] = "<img src='../admin/images/icon_exit.gif' border='0' width='16' height='16' alt='".$str['KillSession']."' />";
$str['TypeOpen'] = "Open";
$str['TypeClosed'] = "Closed";
$str['StatusFailed'] = "Failed Login";
$str['StatusOK'] = "Login OK";

// Errors
$str['ErrorName'] = "You must enter a name.";
$str['ErrorStartdate'] = "The starting date is invalid. Please consider the format.";
$str['ErrorEnddate'] = "The ending date is invalid. Please consider the format.";
$str['ErrorLinkType'] = "You must select a shortcut, if type = Shortcut.";
$str['ErrorLinkTypePlugin'] = "You must select type = Plugin, if you have chosen a plugin.";
$str['ErrorFirstname'] = "You must enter a first name.";
$str['ErrorEmail'] = "You must enter an e-mail.";
$str['ErrorEmailValid'] = "You must enter a valid e-mail.";
$str['ErrorPictureSize'] = "The file size may amount to maximally 15 KB.";
$str['ErrorPictureType'] = "You can upload only pictures with type GIF and JPEG.";
$str['ErrorPictureExist'] = "The file name exists already on the server.";
$str['ErrorTitle'] = "You must enter a title.";
$str['ErrorLogin'] = "Username and/or password is wrong.";
$str['ErrorFile'] = "You must select a file.";
$str['ErrorFileExist'] = "The file exists already on the server.";
$str['ErrorWritePermission'] = "You have no write permissions (chmod 777) to write in this folder.";
$str['ErrorWritePermissionFile'] = "You have no write permissions (chmod 666) to write in this file.";
$str['ErrorTemplate'] = "You must select a main template file.";
$str['ErrorCSS'] = "You must select a CSS file.";
$str['ErrorTemplatePrint'] = "You must select a print view template file.";
$str['ErrorTemplatePrintCSS'] = "You must select a print view CSS file.";
$str['ErrorTemplateLogin'] = "You must select a login template file.";
$str['ErrorTemplateText'] = "You must select an article template file.";
$str['ErrorFolderExist'] = "The folder exists already on the server.";
$str['ErrorTemplateNotExist'] = "The template file does not exist on the server.";
$str['ErrorCSSNotExist'] = "The CSS file does not exist on the server.";
$str['ErrorFilename'] = "You must enter a file.";
$str['ErrorFileNotExist'] = "The file does not exist on the server.";
$str['ErrorFlag'] = "You must enter a flag.";
$str['ErrorUsername'] = "You must enter a username.";
$str['ErrorUsernameShort'] = "The username must consist of at least 3 signs.";
$str['ErrorUsernameExist'] = "The username already exists.";
$str['ErrorPassword'] = "You must enter a password.";
$str['ErrorPasswordShort'] = "The password must consist of at least 6 signs.";
$str['ErrorPasswordValid1'] = "The password must consist of numbers and letters.";
$str['ErrorPasswordValid2'] = "The password must consist of numbers, letters and special signs (@!?|-_:+*.).";
$str['ErrorUserGroupPermission'] = "You have no user permissions to view this page.";
$str['ErrorLoginGroup'] = "You have no permissions to view this page.";
$str['ErrorCaptcha'] = "Please enter a valid code.";
$str['ErrorInstallPhp'] = "install.php doesn't exist in";
$str['ErrorPluginExist'] = "PluginID already exists in table";
$str['ErrorVersionCheck'] = "Error: could not check for latest available version! Please check it manually.";
$str['ErrorDeleteGroup'] = "You can not delete a group which is still in use.";
$str['ErrorLoginMissingGroup'] = "Sorry, but you have no permissions to access this content.";
$str['ErrorInvalidDate'] = "Invalid date.";
$str['ErrorIntegerOnly'] = "You may insert only integer values.";
$str['ErrorOldPassword'] = "Your current password is wrong.";
$str['ErrorDemoMode'] = "You are logged in as Demo user.";

// Plugin Date
$months = array(
1=>"January",
2=>"February",
3=>"March",
4=>"April",
5=>"May",
6=>"June",
7=>"July",
8=>"August",
9=>"September",
10=>"October",
11=>"November",
12=>"December");
$days = array(
"Sunday",
"Monday",
"Tuesday",
"Wednesday",
"Thursday",
"Friday",
"Saturday");
$date_vars['format'] = "[WEEKDAY], [MONTH] [DAY] [YEAR]";

// Plugin Sitemap
$str['Sitemap'] = "Sitemap";

// Plugin Search/Searchbox
$str['Search'] = "Search";
$str['SearchResult'] = "Search Result";
$str['SearchSubmit'] = "Search";
$str['SearchNotFound'] = "The search resulted no hits.";
$str['SearchSubmitShort'] = "Search";

// Plugin Contact
$str['ContactSubject'] = "Web Form";
$str['Contact'] = "Contact";
$str['Phone'] = "Phone";
$str['Message'] = "Message";
$str['MessageSubmit'] = "Submit Message";
$str['ErrorMessage'] = "You must enter a message.";
$str['ContactMessageSent'] = "Thank you for your message! Your message was successfully sent.";

// Plugin Contact Extended
$str['Salutation'] = "Salutation";
$str['TitleMrs'] = "Ms./Mrs.";
$str['TitleMr'] = "Mr.";
$str['Company'] = "Company";
$str['Address'] = "Address";
$str['PostCodeCity'] = "Zip Code/City";
$str['MobilePhone'] = "Mobile Phone";
$str['ErrorPhone'] = "You must enter a phone number.";

// Plugin Location
$str['Location'] = "You are here: ";
$str['Home'] = "Home";

// Plugin Register
$str['RegNew'] = "Register New Account";
$str['RegNewDone'] = "Registration Successful";
$str['RegNewConfirm'] = "Registration Confirmation";
$str['RegPassword'] = "Password (confirm)";
$str['RegErrorPassword'] = "Your password confirmation is different to your password.";
$str['RegNewSubmit'] = "Register &amp; Create Account";
$str['RegInfo'] = "Please fill out the form, all fields are required!";
$str['RegDone'] = "Thank you for signing up an account. We have sent an <b>email</b> with your <b>activation link</b> to your email address, please check your mail account! You have to activate your account before you can use it.";
$str['RegConfirm'] = "Your account was successfully activated.";
$str['RegSubject'] = "Registration / Account Activation";
$str['RegMsg'] = "Hello [USERNAME],
Please activate your account by clicking the link below:

[HYPERLINK]

Best Regards

[AUTHOR]
[URL]";
$str['RegConfirmError'] = "There was no valid account found for activation.";
$str['RegMsgAdmin'] = "This message was created automatically.

You have a new registered user for [URL] :

Username: [USERNAME]
E-Mail: [EMAIL]
Gender: [GENDER]

...powered by bloofoxCMS.";
?>
