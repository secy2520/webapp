<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - languages/deutsch.php -
//
// Copyrights (c) 2006-2009 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

//--------------------------------------------------
// Deutscher Sprachlayer
//--------------------------------------------------

// General
$str['Name'] = "Name";
$str['Action'] = "Aktion";
$str['Save'] = "Speichern";
$str['No'] = "Nein";
$str['Yes'] = "Ja";
$str['EntryDelete'] = "Eintrag l&ouml;schen";
$str['DeleteQuestion'] = "M&ouml;chten Sie folgenden Eintrag wirklich l&ouml;schen?";
$str['EditText'] = "Bearbeiten";
$str['DeleteText'] = "L&ouml;schen";
$str['Edit'] = "<img src='../admin/images/icon_edit.gif' border='0' width='16' height='16' alt='Bearbeiten' />";
$str['Delete'] = "<img src='../admin/images/icon_trash.gif' border='0' width='16' height='16' alt='L&ouml;schen' />";
$str['IcoContents'] = "<img src='../admin/images/icon_content.gif' border='0' width='16' height='16' alt='Inhalte' />";
$str['Summary'] = "&Uuml;bersicht";
$str['DateFormat'] = "TT.MM.JJJJ";
$str['Database'] = "Datenbank";
$str['Server'] = "Server";
$str['Logout'] = "Logout";
$str['CaptchaCode'] = "Bitte geben Sie folgenden Code ein: <img src='admin/images/icon_help.gif' border='0' width='16' height='16' alt='Gro�-/Kleinschreibung beachten, ohne Leerzeichen' title='Gro�-/Kleinschreibung beachten, ohne Leerzeichen' />";
$str['Print'] = "Druckansicht";
$str['Mail'] = "E-Mail";
$str['Dir'] = "Verzeichnis";
$str['All'] = "Gesamt";
$str['SaveAndClose'] = "Speichern und Schlie&szlig;en";
$str['IcoPreview'] = "<img src='../admin/images/icon_preview.gif' border='0' width='16' height='16' alt='Vorschau' />";
$str['Preview'] = "Vorschau";
$str['Version'] = "Version";
$str['VersionUpdate'] = "Es ist eine neuere Version von bloofoxCMS verf&uuml;gbar. Es wird empfohlen auf die neueste Version zu updaten.";
$str['TopOfSite'] = "Seitenanfang";
$str['Administration'] = "Verwaltung";
$str['Tools'] = "Tools";
$str['Settings'] = "Einstellungen";
$str['Security'] = "Sicherheit";
$str['EditorEdit'] = "Editor";
$str['Sorting'] = "Sortierung";
$str['Options'] = "Optionen";
$str['General'] = "Allgemein";
$str['Next'] = "Weiter &gt;&gt;";
$str['Prev'] = "&lt;&lt; Zur&uuml;ck";
$str['Quit'] = "Beenden";
$str['Content'] = "Inhalt";
$str['AddText'] = "Neu";
$str['Legend'] = "Legende";
$str['SystemInformation'] = "System Information";
$str['Notice'] = "Hinweis";
$str['NoticeArticlesNotFound'] = "Es wurden keine Artikel f�r diese Seite gefunden.";

// Filter
$str['SetFilter'] = "Filter";
$str['FilterShowAllProjects'] = "Zeige alle Projekte";
$str['FilterShowAllTypes'] = "Zeige alle Arten";
$str['FilterShowAllPages'] = "Zeige alle Seiten";
$str['FilterShowAllUsers'] = "Zeige alle Benutzer";

// Contents
$str['Contents'] = "Inhalte";
$str['Levels'] = "Sortierung";
$str['Articles'] = "Artikel";
$str['Pages'] = "Seiten";
$str['ContentEdit'] = "Inhalte bearbeiten";
$str['HeadLine'] = "&Uuml;berschrift";
$str['TextContent'] = "Text";
$str['SaveChanges'] = "&Auml;nderungen speichern";
$str['LinkType0'] = "Standard";
$str['LinkType1'] = "Externe Url";
$str['LinkType2'] = "Verkn&uuml;pfung";
$str['LinkType3'] = "Plugin";
$str['EntryAdd'] = "Eintrag hinzuf&uuml;gen";
$str['EntryEdit'] = "Eintrag bearbeiten";
$str['EntryDelete'] = "Eintrag l&ouml;schen";
$str['PageAdd'] = "Seite hinzuf&uuml;gen";
$str['PageEdit'] = "Seite bearbeiten";
$str['PageDelete'] = "Seite l&ouml;schen";
$str['Type'] = "Art";
$str['TargetWindow'] = "Zielfenster";
$str['Url'] = "Url";
$str['Shortcut'] = "Verkn&uuml;pfung";
$str['ShortcutOption1'] = "- Keine -";
$str['Blocked'] = "Gesperrt";
$str['Hidden'] = "Versteckt";
$str['Groups'] = "Gruppen";
$str['SubPermissions'] = "Rechte vererben";
$str['Startdate'] = "Startdatum";
$str['Enddate'] = "Enddatum";
$str['Keywords'] = "Keywords";
$str['InsertAfter'] = "Einf&uuml;gen nach";
$str['InsertAfterOption1'] = "- An den Anfang -";
$str['MoveLeft'] = "Nach Links";
$str['MoveRight'] = "Nach Rechts";
$str['MoveUp'] = "Nach Oben";
$str['MoveDown'] = "Nach Unten";
$str['Images'] = "Bildauswahl";
$str['PostedBy'] = "geschrieben von";
$str['PageHandling'] = "Seite";
$str['CreatedBy'] = "Erstellt von";
$str['CreatedAt'] = "Erstellt am";
$str['ChangedBy'] = "Ge&auml;ndert von";
$str['ChangedAt'] = "Ge&auml;ndert am";
$str['Parameter'] = "Parameter";
$str['DefaultContents'] = "Standardtexte";
$str['ArticleAdd'] = "Artikel hinzuf&uuml;gen";
$str['ArticleEdit'] = "Artikel bearbeiten";
$str['ArticleDelete'] = "Artikel l&ouml;schen";
$str['Top'] = "Oben";
$str['Bottom'] = "Unten";
$str['SameLevel'] = "Gleiche Ebene";
$str['Underneath'] = "Untergeordnet";
$str['EntryID'] = "Seiten-ID";
$str['PreID'] = "Vorg&auml;nger";
$str['IcoLeft'] = "<img src='images/icon_left.gif' border='0' width='16' height='16' alt='".$str['MoveLeft']."' />";
$str['IcoRight'] = "<img src='images/icon_right.gif' border='0' width='16' height='16' alt='".$str['MoveRight']."' />";
$str['IcoUp'] = "<img src='images/icon_up.gif' border='0' width='16' height='16' alt='".$str['MoveUp']."' />";
$str['IcoDown'] = "<img src='images/icon_down.gif' border='0' width='16' height='16' alt='".$str['MoveDown']."' />";
$str['Pictures'] = "Bilder";
$str['Page'] = "Seite";

// Profile
$str['MyProfile'] = "Mein Profil";
$str['ProfileEdit'] = "Profil bearbeiten";
$str['FirstName'] = "Vorname";
$str['LastName'] = "Nachname";
$str['Address1'] = "Adresse 1";
$str['Address2'] = "Adresse 2";
$str['City'] = "Wohnort";
$str['ZipCode'] = "PLZ";
$str['Email'] = "E-Mail";
$str['Birthday'] = "Geburtsdatum";
$str['Gender'] = "Geschlecht";
$str['Picture'] = "Foto";
$str['BeLang'] = "Admincenter Sprache";
$str['BeStyle'] = "Admincenter Style";
$str['GenderMale'] = "M&auml;nnlich";
$str['GenderFemale'] = "Weiblich";
$str['PrivateProfile'] = "Profil anzeigen";
$str['ContactInfo'] = "Kontaktdaten";
$str['ShowEmail'] = "E-Mail anzeigen";
$str['DeletePicture'] = "Foto l&ouml;schen";

// Projekte
$str['Configurations'] = "Projekte";
$str['ConfigurationAdd'] = "Projekt hinzuf&uuml;gen";
$str['ConfigurationEdit'] = "Projekt bearbeiten";
$str['ConfigurationDelete'] = "Projekt l&ouml;schen";
$str['Language'] = "Sprache";
$str['Template'] = "Template";
$str['Urls'] = "Urls (eine je Zeile)";
$str['RootPage'] = "Startseite";
$str['Title'] = "Titel";
$str['MetaDescription'] = "Meta-Beschreibung";
$str['MetaKeywords'] = "Meta-Keywords";
$str['MetaAuthor'] = "Meta-Author";
$str['MetaCharset'] = "Meta-Charset";
$str['MetaDocType'] = "Meta-DocType";
$str['Copyright'] = "Meta-Copyright";
$str['ModRewrite'] = "mod_rewrite";
$str['DefaultGroup'] = "Standard Benutzergruppe";
$str['UserActivation'] = "Benutzeraktivierung durch Admin";

// Home
$str['WelcomeToAdmincenter'] = "Willkommen im Admincenter";
$str['YourLastLogin'] = "Ihr letzter Login war am";
$str['WhoIsOnline'] = "Wer ist Online";
$str['Statistics'] = "Statistik";
$str['YourIPAddress'] = "Ihre IP-Adresse lautet";
$str['InfoIPLog'] = "Ihre IP-Adresse wurde aus Sicherheitsgr&uuml;nden gespeichert.";
$str['WarningChangePassword'] = "Warnung! Es wird dringend empfohlen das Admin-Passwort zu &auml;ndern.";
$str['PasswordChanged'] = "Passwort erfolgreich ge&auml;ndert.";

// Login
$str['Username'] = "Benutzername";
$str['Password'] = "Passwort";
$str['Login'] = "Login";
$str['FailedLogins'] = "Fehlerhafte Logins seit letztem Login";
$str['UnblockAccount'] = "Account entsperren";
$str['AccountWasBlocked'] = "Ihr Account ist nach zu vielen fehlerhaften Logins gesperrt worden. Klicken Sie auf den folgenden Link, um Ihren Account zu entsperren:\n";
$str['LoggedIn'] = "Sie sind angemeldet als: ";
$str['NotLoggedIn'] = "Sie sind nicht angemeldet!";
$str['MyAccount'] = "Mein Account";
$str['OldPassword'] = "Aktuelles Passwort";
$str['NewPassword'] = "Neues Passwort";
$str['ChangePw'] = "Passwort &auml;ndern";

// Mediacenter
$str['Mediacenter'] = "Medien";
$str['MediafileAdd'] = "Mediendatei hinzuf&uuml;gen";
$str['File'] = "Datei";
$str['Image'] = "Bild";
$str['MediafileEdit'] = "Mediendatei bearbeiten";
$str['MediafileDelete'] = "Mediendatei l&ouml;schen";
$str['FileAdd'] = "Datei hinzuf&uuml;gen";
$str['FileSize'] = "Dateigr&ouml;&szlig;e";

// Plugins
$str['Plugins'] = "Plugins";
$str['Path'] = "Pfad";
$str['Plugin'] = "Plugin";
$str['PluginAdd'] = "Plugin hinzuf&uuml;gen";
$str['PluginDelete'] = "Plugin l&ouml;schen";
$str['PluginEdit'] = "Plugin bearbeiten";
$str['PluginID'] = "ID";

// Templates
$str['Templates'] = "Templates";
$str['TemplateAdd'] = "Template hinzuf&uuml;gen";
$str['CSS'] = "CSS";
$str['Backend'] = "Backend";
$str['TemplateEdit'] = "Template bearbeiten";
$str['TemplateDelete'] = "Template l&ouml;schen";
$str['CreateNewDir'] = "Neuen Ordner erstellen...";
$str['DirName'] = "Ordnername";
$str['TmplPrint'] = "Druckansicht";
$str['TmplPrintCSS'] = "Druckansicht CSS";
$str['TmplLogin'] = "Login";
$str['TmplText'] = "Artikel";

// Languages
$str['Languages'] = "Sprachen";
$str['LanguageAdd'] = "Sprache hinzuf&uuml;gen";
$str['Flag'] = "Flagge";
$str['LanguageEdit'] = "Sprache bearbeiten";
$str['LanguageDelete'] = "Sprache l&ouml;schen";
$str['DateFormula'] = "Datumsformel";
$str['DateTimeFormula'] = "Datums-/Zeitformel";
$str['Token'] = "K&uuml;rzel";
$str['CreateNewFile'] = "Neue Datei erstellen...";
$str['FileName'] = "Dateiname";

// Settings
$str['UpdateCheck'] = "Nach neuen Versionen im Admincenter Home pr&uuml;fen";
$str['RegisterNotification'] = "Benachrichtigung mit jeder Registrierung an Admin senden";
$str['LoginProtection'] = "Login-Schutz verwenden/Sessions loggen";
$str['OnlineStatus'] = "Online Status mit jedem Seitenaufruf aktualisieren";
$str['UserContentOnly'] = "Benutzer k&ouml;nnen nur eigene Inhalte editieren";
$str['AdminMail'] = "Administrator E-Mail f�r Benachrichtigungen";
$str['HtmlMails'] = "Mails in HTML-Format senden";
$str['HtmlEntitiesOff'] = "PHP Funktion htmlentities() deaktivieren";
$str['PasswordRule'] = "Passwortrichtlinie f&uuml;r Benutzer Passw&ouml;rter";
$str['TextboxWidth'] = "Textbox-Breite im wysiwyg Editor (Pixel)";
$str['PwRule0'] = "Keine";
$str['PwRule1'] = "Mittel";
$str['PwRule2'] = "Streng";

// Security
$str['User'] = "Benutzer";
$str['Permissions'] = "Rechte";
$str['Read'] = "Lesen";
$str['Write'] = "Schreiben";
$str['Del'] = "L&ouml;schen";
$str['GroupAdd'] = "Gruppe hinzuf&uuml;gen";
$str['Demo'] = "Demo";
$str['GroupEdit'] = "Gruppe bearbeiten";
$str['GroupDelete'] = "Gruppe l&ouml;schen";
$str['Config'] = "Projekt";
$str['UserAdd'] = "Benutzer hinzuf&uuml;gen";
$str['Deleted'] = "Gel&ouml;scht";
$str['Status'] = "Status";
$str['Inactive'] = "Inaktiv";
$str['Active'] = "Aktiv";
$str['UserEdit'] = "Benutzer bearbeiten";
$str['UserDelete'] = "Benutzer l&ouml;schen";
$str['PermissionsAdd'] = "Rechte hinzuf&uuml;gen";
$str['Group'] = "Gruppe";
$str['Area'] = "Bereich";
$str['PermissionsEdit'] = "Rechte bearbeiten";
$str['PermissionsDelete'] = "Rechte l&ouml;schen";
$str['EditUserProfile'] = "Profil bearbeiten";
$str['IcoProfile'] = "<img src='../admin/images/icon_profile.gif' border='0' width='16' height='16' alt='Profil bearbeiten' />";
$str['AreaConfigurations'] = "Verwaltung: Projekte";
$str['AreaLanguages'] = "Verwaltung: Sprachen";
$str['AreaTemplates'] = "Verwaltung: Templates";
$str['AreaPlugins'] = "Verwaltung: Plugins";
$str['AreaCharsets'] = "Verwaltung: Charsets";
$str['AreaSettings'] = "Verwaltung: Einstellungen";
$str['AreaExplorer'] = "Inhalte: Seiten";
$str['AreaContentsDefault'] = "Inhalte: Artikel";
$str['AreaContentsPlugins'] = "Inhalte: Plugins";
$str['AreaMediacenter'] = "Inhalte: Medien";
$str['AreaLevels'] = "Inhalte: Sortierung";
$str['AreaEditor'] = "Editor";
$str['AreaUser'] = "Sicherheit: Benutzer";
$str['AreaGroups'] = "Sicherheit: Gruppen";
$str['AreaPermissions'] = "Sicherheit: Rechte";
$str['AreaSessions'] = "Sicherheit: Sessions";
$str['AreaTools'] = "Tools";
$str['LoginPage'] = "Benutzerseite";
$str['RegisterDate'] = "Registrierungsdatum";

// Charsets
$str['Charset'] = "Charsets";
$str['CharsetAdd'] = "Charset hinzuf&uuml;gen";
$str['CharsetEdit'] = "Charset bearbeiten";
$str['CharsetDelete'] = "Charset l&ouml;schen";
$str['Description'] = "Beschreibung";

// Tools
$str['Activity'] = "Aktivit&auml;t Name";
$str['ToolsActivities'] = "Aktivit&auml;ten";
$str['ToolsImport'] = "Import";
$str['ToolsExport'] = "Export";
$str['ToolsUpload'] = "Upload";
$str['ToolsPhpmyadmin'] = "PhpMyAdmin";
$str['OptimizeDB'] = "Datenbank optimieren";
$str['ClearInactiveUsers'] = "Inaktive Benutzer l&ouml;schen";
$str['ClearDeletedUsers'] = "Gel&ouml;schte Benutzer l&ouml;schen";
$str['ClearSessions'] = "Sessions l&ouml;schen";
$str['ClearFailedSessions'] = "Nur fehlerhafte Sessions l&ouml;schen";
$str['PhpMyAdmin'] = "PhpMyAdmin &ouml;ffnen";
$str['RegisterTillDate'] = "registriert bis Datum:";
$str['LoginTillDate'] = "Logins bis Datum:";
$str['TemplateFile'] = "Template-Datei";
$str['TemplateImage'] = "Template-Bild";
$str['UploadFiles'] = "Dateien hochladen";
$str['HyperlinkNotConfigured'] = "Es wurde noch kein Hyperlink in der Datei admin/config.php definiert.";
$str['ToolsBackup'] = "Backup";

// Sessions
$str['Date'] = "Datum";
$str['Time'] = "Uhrzeit";
$str['MySession'] = "Meine Session";
$str['KillSession'] = "Session beenden";
$str['IcoExit'] = "<img src='../admin/images/icon_exit.gif' border='0' width='16' height='16' alt='".$str['KillSession']."' />";
$str['TypeOpen'] = "Offen";
$str['TypeClosed'] = "Beendet";
$str['StatusFailed'] = "Login verfehlt";
$str['StatusOK'] = "Login OK";

// Errors
$str['ErrorName'] = "Sie m&uuml;ssen einen Namen eingeben.";
$str['ErrorStartdate'] = "Das Startdatum ist ung&uuml;ltig. Bitte Format beachten.";
$str['ErrorEnddate'] = "Das Enddatum ist ung&uuml;ltig. Bitte Format beachten.";
$str['ErrorLinkType'] = "Sie m&uuml;ssen eine Verkn&uuml;pfung ausw&auml;hlen, wenn Art = Shortcut ist.";
$str['ErrorLinkTypePlugin'] = "Sie m&uuml;ssen Art = Plugin w&auml;hlen, wenn ein Plugin ausgew&auml;hlt ist.";
$str['ErrorFirstname'] = "Sie m&uuml;ssen einen Vornamen eingeben.";
$str['ErrorEmail'] = "Sie m&uuml;ssen eine E-Mail eingeben.";
$str['ErrorEmailValid'] = "Sie m&uuml;ssen eine g&uuml;ltige E-Mail eingeben.";
$str['ErrorPictureSize'] = "Die Dateigr&ouml;�e darf maximal 15 kb betragen.";
$str['ErrorPictureType'] = "Sie k&ouml;nnen nur Fotos der Art GIF und JPEG uploaden.";
$str['ErrorPictureExist'] = "Der Dateiname existiert bereits auf dem Server.";
$str['ErrorTitle'] = "Sie m&uuml;ssen einen Titel eingeben.";
$str['ErrorLogin'] = "Benutzername und/oder Passwort sind falsch.";
$str['ErrorFile'] = "Sie m&uuml;ssen eine Datei ausw&auml;hlen.";
$str['ErrorFileExist'] = "Die Datei existiert bereits auf dem Server.";
$str['ErrorWritePermission'] = "Sie haben keine Schreibrechte (chmod 777), um in das Verzeichnis zu schreiben.";
$str['ErrorWritePermissionFile'] = "Sie haben keine Schreibrechte (chmod 666), um in die Datei zu schreiben.";
$str['ErrorTemplate'] = "Sie m&uuml;ssen eine Template Hauptdatei ausw&auml;hlen.";
$str['ErrorCSS'] = "Sie m&uuml;ssen eine CSS-Datei ausw&auml;hlen.";
$str['ErrorTemplatePrint'] = "Sie m&uuml;ssen ein Template f&uuml;r Druckansicht ausw&auml;hlen.";
$str['ErrorTemplatePrintCSS'] = "Sie m&uuml;ssen eine CSS-Datei f&uuml;r Druckansicht ausw&auml;hlen.";
$str['ErrorTemplateLogin'] = "Sie m&uuml;ssen ein Login Template ausw&auml;hlen.";
$str['ErrorTemplateText'] = "Sie m&uuml;ssen ein Artikel Template ausw&auml;hlen.";
$str['ErrorFolderExist'] = "Das Verzeichnis existiert bereits auf dem Server.";
$str['ErrorTemplateNotExist'] = "Die Template-Datei existiert auf dem Server nicht.";
$str['ErrorCSSNotExist'] = "Die CSS-Datei existiert auf dem Server nicht.";
$str['ErrorFilename'] = "Sie m&uuml;ssen eine Datei eingeben.";
$str['ErrorFileNotExist'] = "Die Datei existiert auf dem Server nicht.";
$str['ErrorFlag'] = "Sie m&uuml;ssen eine Flagge eingeben.";
$str['ErrorUsername'] = "Sie m&uuml;ssen einen Benutzernamen eingeben.";
$str['ErrorUsernameShort'] = "Der Benutzername muss aus mind. 3 Zeichen bestehen.";
$str['ErrorUsernameExist'] = "Der Benutzername existiert bereits.";
$str['ErrorPassword'] = "Sie m&uuml;ssen ein Passwort eingeben.";
$str['ErrorPasswordShort'] = "Das Passwort muss aus mind. 6 Zeichen bestehen.";
$str['ErrorPasswordValid1'] = "Das Passwort muss aus Zahlen und Buchstaben bestehen.";
$str['ErrorPasswordValid2'] = "Das Passwort muss aus Zahlen, Buchstaben und Sonderzeichen (@!?|-_:+*.) bestehen.";
$str['ErrorUserGroupPermission'] = "Ihre Benutzerrechte erlauben es Ihnen nicht die Seite anzuzeigen.";
$str['ErrorLoginGroup'] = "Sie haben keine Benutzerrechte um die Seite anzuzeigen.";
$str['ErrorCaptcha'] = "Bitte geben Sie einen g&uuml;ltigen Code ein.";
$str['ErrorInstallPhp'] = "install.php existiert nicht im Verzeichnis";
$str['ErrorPluginExist'] = "Die PluginID existiert bereits in der Tabelle";
$str['ErrorVersionCheck'] = "Fehler: Es konnte nicht auf die neueste verf&uuml;gbare Version gepr&uuml;ft werden! Bitte pr&uuml;fen Sie dies manuell.";
$str['ErrorDeleteGroup'] = "Sie k&ouml;nnen keine Gruppe l&ouml;schen, die noch verwendet wird.";
$str['ErrorLoginMissingGroup'] = "Entschuldigung, aber Sie haben keine Berechtigung um den Inhalt anzuzeigen.";
$str['ErrorInvalidDate'] = "Ung&uuml;ltiges Datum.";
$str['ErrorIntegerOnly'] = "Sie d&uuml;rfen nur Ganzzahlen eingeben.";
$str['ErrorOldPassword'] = "Ihr aktuelles Passwort ist falsch.";
$str['ErrorDemoMode'] = "Sie sind als Demo-User angemeldet.";

// Plugin Date
$months = array(
1=>"Januar",
2=>"Februar",
3=>"M&auml;rz",
4=>"April",
5=>"Mai",
6=>"Juni",
7=>"Juli",
8=>"August",
9=>"September",
10=>"Oktober",
11=>"November",
12=>"Dezember");
$days = array(
"Sonntag",
"Montag",
"Dienstag",
"Mittwoch",
"Donnerstag",
"Freitag",
"Samstag");
$date_vars['format'] = "[WEEKDAY], [DAY]. [MONTH] [YEAR]";

// Plugin Sitemap
$str['Sitemap'] = "Sitemap";

// Plugin Search/Searchbox
$str['Search'] = "Suche";
$str['SearchResult'] = "Suchergebnis";
$str['SearchSubmit'] = "Suche";
$str['SearchNotFound'] = "Die Suche hat keinen Treffer erzielt.";
$str['SearchSubmitShort'] = "Suchen";

// Plugin Contact
$str['ContactSubject'] = "Webformular";
$str['Contact'] = "Kontakt";
$str['Phone'] = "Telefon";
$str['Message'] = "Nachricht";
$str['MessageSubmit'] = "Nachricht versenden";
$str['ErrorMessage'] = "Sie m&uuml;ssen eine Nachricht eingeben.";
$str['ContactMessageSent'] = "Vielen Dank f�r Ihre Nachricht! Ihre Nachricht wurde erfolgreich versendet.";

// Plugin Contact Extended
$str['Salutation'] = "Anrede";
$str['TitleMrs'] = "Frau";
$str['TitleMr'] = "Herr";
$str['Company'] = "Firma";
$str['Address'] = "Anschrift";
$str['PostCodeCity'] = "PLZ/Ort";
$str['MobilePhone'] = "Mobiltelefon";
$str['ErrorPhone'] = "Sie m&uuml;ssen eine Telefonnr. eingeben.";

// Plugin Location
$str['Location'] = "Sie sind hier: ";
$str['Home'] = "Home";

// Plugin Register
$str['RegNew'] = "Neuen Account registrieren";
$str['RegNewDone'] = "Registrierung erfolgreich";
$str['RegNewConfirm'] = "Best&auml;tigung der Registrierung";
$str['RegPassword'] = "Passwort (Best&auml;tigung)";
$str['RegErrorPassword'] = "Ihre Passwortbest&auml;tigung stimmt nicht mit Ihrem Passwort &uuml;berein.";
$str['RegNewSubmit'] = "Registrieren &amp; Account erstellen";
$str['RegInfo'] = "Bitte f&uuml;llen Sie das Formular aus, alle Felder sind Pflichtangaben!";
$str['RegDone'] = "Vielen Dank f&uuml;r die Registrierung. Wir haben eine <b>E-Mail</b> an Ihre E-Mailadresse mit Ihrem <b>Aktivierungslink</b> gesendet, bitte pr&uuml;fen Sie Ihr E-Mail Postfach! Sie m&uuml;ssen Ihren Account aktivieren, um diesen nutzen zu k&ouml;nnen.";
$str['RegConfirm'] = "Ihr Account wurde erfolgreich aktiviert.";
$str['RegSubject'] = "Registrierung / Accountaktivierung";
$str['RegMsg'] = "Hallo [USERNAME],
Bitte aktivieren Sie Ihren Account mit einem Klick auf den folgenden Link:

[HYPERLINK]

Mit besten Gr&uuml;�en

[AUTHOR]
[URL]";
$str['RegConfirmError'] = "Es wurde kein g&uuml;ltiger Account zur Aktivierung gefunden.";
$str['RegMsgAdmin'] = "Diese Nachricht wurde automatisch erstellt.

Sie haben einen neuen registierten Benutzer f�r [URL] :

Username: [USERNAME]
E-Mail: [EMAIL]
Geschlecht: [GENDER]

...powered by bloofoxCMS.";
?>