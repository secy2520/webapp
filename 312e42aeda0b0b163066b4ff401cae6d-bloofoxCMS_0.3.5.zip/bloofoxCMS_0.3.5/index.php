<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - index.php -
//
// Copyrights (c) 2006-2009 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

// Make or find session
session_name("sid");
session_start();

// Set error reporting
error_reporting (E_ALL ^ E_NOTICE);

// Define constants
define ('SYS_WORK_DIR', getcwd());
define ('SYS_INDEX', 1);
define ('SYS_FOLDER', '/system');

// Load required files
include_once(SYS_WORK_DIR."/config.php");
require_once(SYS_WORK_DIR."/functions.php");

// Check if setup report was created, if not start setup
if(!file_exists(SYS_WORK_DIR."/media/txt/install.txt")) {
	load_url("install/index.php");
}

// Check if setup folder still exists, if so then die
if(is_dir(SYS_WORK_DIR."/install")) {
	die("Error: the setup folder '/install' still exists! Please delete this folder from your server.");
}

// Load required libraries
require_once(SYS_WORK_DIR.SYS_FOLDER."/class_mysql.php");
require_once(SYS_WORK_DIR.SYS_FOLDER."/class_template.php");
require_once(SYS_WORK_DIR.SYS_FOLDER."/class_config.php");
require_once(SYS_WORK_DIR.SYS_FOLDER."/class_explorer.php");
require_once(SYS_WORK_DIR.SYS_FOLDER."/class_content.php");
require_once(SYS_WORK_DIR.SYS_FOLDER."/class_permissions.php");

// Init mysql library
$db = new DB_Tpl();

// Compare database version with file version
if(get_current_version() != get_database_version($db)) {
	die("Notice: database is in maintenance. Please try again later.");
}

// Search for valid config
$conf = new config();
if(!isset($_GET['page']) || CheckInteger($_GET['page']) == FALSE) {
	$sys_config_vars = $conf->get_config($db);
} else {
	$db->query("SELECT config_id FROM ".$tbl_prefix."sys_explorer WHERE eid = '".$_GET['page']."' LIMIT 1");
	while($db->next_record()):
		$config_id = $db->f("config_id");
	endwhile;
	$sys_config_vars = $conf->set_config($db,$config_id);
}

if($sys_config_vars['cid'] == "") {
	die("Error: no project configuration found! Please check your projects in Admincenter.");
}

// Get general settings
$sys_setting_vars = $conf->get_settings($db);

// Get language parameters
$sys_vars = $conf->get_language_vars($db,$sys_config_vars);
$sys_config_vars['language'] = $sys_vars['token'];
include(SYS_WORK_DIR."/languages/".$sys_vars['language']);

$perm = new permissions();
// handle logout and load index.php
if(isset($_GET['logout'])) {
	$perm->logout($db,"index.php");
}

// unblock account after register confirmation, source is email
if(isset($_GET['key'])) {
	$user_key = validate_text($_GET['key']);
	$db->query("UPDATE ".$tbl_prefix."sys_user SET `blocked` = '0' WHERE `key` = '".$user_key."' && blocked = '1'");
	$db->query("SELECT uid FROM ".$tbl_prefix."sys_user WHERE `key` = '".$user_key."' LIMIT 1");
	while($db->next_record()):
		$perm->set_current_user($db->f("uid"));
	endwhile;
	$perm->archive_session($db);
}

// check if login is required for content or for project
$login_ok = 0;
$login_failed = 0;
if(isset($_POST['login']) || $_GET['login'] == "true") {
	if($perm->login($db,validate_text($_POST['username']),validate_text($_POST['password'])) == 1) {
		$login_ok = 1;
		if($_GET['login'] == "true") {
			if(empty($_SESSION["login_page"])) {
				// load page index.php after successful login
				load_url("index.php");
			} else {
				load_url("index.php?page=".$_SESSION["login_page"]);
			}
		}
	} else {
		$login_failed = 1;
	}
}

// check if user is already logged in
$sys_vars['curr_usertext'] = get_caption("NotLoggedIn");
if($perm->check_session() == 1) {
	// session already exists
	$login_ok = 1;
	$sys_vars['username'] = $_SESSION["username"];
	$sys_vars['uid'] = $_SESSION["uid"];
	$sys_vars['login_page'] = $_SESSION["login_page"];
	$sys_vars['curr_usertext'] = get_caption("LoggedIn");
	$sys_vars['curr_logout'] = "<a href='index.php?logout' title='".get_caption('Logout')."'>".get_caption('Logout')."</a>";
	$sys_vars['logout'] = "<p class='logout'>".$sys_vars['curr_logout']." [ ".$_SESSION["username"]." ]</p>";
	$sys_group_vars = $perm->get_group($db,$_SESSION['usergroups']);
	if($perm->backend_access() == 1) {
		$sys_vars['curr_admin'] = "<a href='admin/index.php' title='".get_caption("Admincenter")."'>".get_caption("Admincenter")."</a>";
	}
}

// do group comparison for current user
$group_found = 0;
$group_found = $perm->compare_groups($sys_config_vars['user_groups']);

// get explorer entry for content
$sys_explorer_id = $_GET['page'];
if(empty($sys_explorer_id)) {
	$sys_explorer_id = $sys_config_vars['root_id'];
}

// check if parameter $page is a valid integer value
if(CheckInteger($sys_explorer_id) == FALSE) {
	unset($sys_explorer_id);
	$sys_explorer_id = $sys_config_vars['root_id'];
}

// check if parameter $start is a valid integer value
if(CheckInteger($_GET['start']) == FALSE) {
	$_GET['start'] = 1;
}

// check if parameter $print is a valid integer value
if(CheckInteger($_GET['print']) == FALSE || $_GET['print'] > 1) {
	$print = 0;
} else {
	$print = 1;
}

// get explorer vars
$expl = new explorer();
$sys_explorer_vars = $expl->get_explorer($db,$sys_config_vars,$sys_explorer_id);

// get explorer vars for shortcut entry
$sys_explorer_vars2 = $sys_explorer_vars;
if($sys_explorer_vars['link_type'] == 2) {
	$sys_explorer_vars = $expl->get_explorer($db,$sys_config_vars,$sys_explorer_vars['link_eid']);
}

// change template for explorer page
if($sys_explorer_vars['template_id'] != 0) {
	$sys_config_vars['tmpl_id'] = $sys_explorer_vars['template_id'];
}

// compare groups for content access
if($sys_explorer_vars['groups'] != "") {
	$group_found = $perm->compare_groups($sys_explorer_vars['groups']);
}

// set login is required or not
$login_required = 0;
if($group_found == 0 || $login_failed == 1) {
	$login_required = 1;
}

// initialize content class
$cont = new content();
if($login_required == 0) {
	$cont->set_eid($sys_explorer_vars['eid']);
}

// build template or handle error
$tpl = new Template();
$tpl->set_unknowns("keep");

$sys_tmpl_vars = $conf->get_tmpl_vars($db,$sys_config_vars,$print);

if(!file_exists(SYS_WORK_DIR."/templates/".$sys_tmpl_vars['name']."/".$sys_tmpl_vars['tmpl']) || empty($sys_tmpl_vars['tmpl'])) {
	die("Error: main template does not exist! Please check your template settings in Admincenter and your template folder '/templates'.");
}
if(!file_exists(SYS_WORK_DIR."/templates/".$sys_tmpl_vars['name']."/".$sys_tmpl_vars['text']) || empty($sys_tmpl_vars['text'])) {
	die("Error: article template does not exist! Please check your template settings in Admincenter and your template folder '/templates'.");
}
if(!file_exists(SYS_WORK_DIR."/templates/".$sys_tmpl_vars['name']."/".$sys_tmpl_vars['login']) || empty($sys_tmpl_vars['login'])) {
	die("Error: login template does not exist! Please check your template settings in Admincenter and your template folder '/templates'.");
}

// set content template or login window template if type is not "external link"
if($sys_explorer_vars['link_type'] != 3) {
	switch($sys_explorer_vars['link_type'])
	{
		default:
			// default content view
			$sys_tmpl_vars['content'] = "/templates/".$sys_tmpl_vars['name']."/".$sys_tmpl_vars['text'];
		break;
	}
}

// check if var cid is given
if(isset($_GET['cid'])) {
	if(CheckInteger($_GET['cid']) == FALSE) {
		unset($_GET['cid']);
	}
}
// if var cid is really defined then load single content plugin
if(isset($_GET['cid'])) {
	if($cont->plugin_available(33) == 1) {
		$sys_explorer_vars['link_type'] = 3; // handles not to load default text but specific plugin
		$sys_explorer_vars['link_plugin'] = 33; // text details
	}
}

// set login template and if needed login error message
if($login_required == 1) {
	if(isset($_POST['login']) && $login_ok == 0) {
		$login_error = "<p class='error'>".get_caption('ErrorLogin')."</p>";
	} else {
		if(isset($_POST['login']) && $group_found == 0) {
			$login_error = "<p class='error'>".get_caption('ErrorLoginGroup')."</p>";
		} else {
			if($login_ok == 1) {
				$login_error = "<p class='error'>".get_caption('ErrorLoginMissingGroup')."</p>";
			} else {
				$login_error = "";
			}
		}
	}
	
	$cont->set_login_vars(get_caption('Login'),$_SERVER['REQUEST_URI'],get_caption('Username'),get_caption('Password'),$login_error);
	$sys_tmpl_vars['content'] = "/templates/".$sys_tmpl_vars['name']."/".$sys_tmpl_vars['login'];
}

// set print variables; can be overwritten by a content plugin later
if($print == 0) {
	$sys_print_vars['print'] = "<div class='print'><a href='index.php?page=".$sys_explorer_id."&amp;start=".$_GET['start']."&amp;print=1' target='print' title='".get_caption('Print')."'>".get_caption('Print')."</a></div>";
}

// Load and handle plugins
include(SYS_WORK_DIR."/plugins.php");

// set templates
$basic_tmpl = array (
	"template"          => SYS_WORK_DIR."/templates/".$sys_tmpl_vars['name']."/".$sys_tmpl_vars['tmpl'], // Layout Template
	"template_content"  => SYS_WORK_DIR.$sys_tmpl_vars['content'] // Content Template
	);
$template_arrays = array_merge($basic_tmpl,$plugins_tmpl);

$tpl->set_file($template_arrays);

// include default content or login window
if($sys_explorer_vars['link_type'] != 3 || $login_required == 1) {
	//$cont->build_content($db,$login_required);
	include(SYS_WORK_DIR."/system/inc_content.php");
}

// include plugins
unset($sys_plugin_vars);
// Include all active module plugin files, if not print view
if($print != 1) {
	$db->query("SELECT install_path,index_file FROM ".$tbl_prefix."sys_plugin WHERE status = '1' && plugin_type = '0'");

	while($db->next_record()):
		include_once(SYS_WORK_DIR."/plugins/".$db->f("install_path").$db->f("index_file"));
	endwhile;
}

// Include called content plugin file
$db->query("SELECT install_path,index_file FROM ".$tbl_prefix."sys_plugin WHERE status = '1' && plugin_type = '1' && pid = '".$sys_explorer_vars['link_plugin']."' LIMIT 1");
while($db->next_record()):
	include_once(SYS_WORK_DIR."/plugins/".$db->f("install_path").$db->f("index_file"));
endwhile;

// get doctype
$tmpl_var_doctype = create_doctype($sys_config_vars['meta_doctype']);

// get header and replace title bar with current page
$tmpl_var_header = create_header($sys_config_vars,$sys_tmpl_vars,$sys_explorer_vars,$sys_plugin_vars);
			  
// load and parse template
$tpl->set_var(array(
	// default placeholders (should not be changed):
	"template_doctype"       => $tmpl_var_doctype,
	"template_header"        => $tmpl_var_header,
	"template_url"           => $sys_config_vars['url'],
	"template_title"       => $sys_config_vars['meta_title'],
	"template_copy"          => $sys_config_vars['meta_copyright'],
	"template_print"         => $sys_print_vars['print'],
	"template_pages"         => $sys_vars['pages'],
	"template_logout"        => $sys_vars['logout'],
	"template_body_tag"      => $sys_vars['body_tag'],
	// additional default placeholders:
	"curr_user"     => $sys_vars['username'],
	"curr_usertext" => $sys_vars['curr_usertext'],
	"curr_logout"   => $sys_vars['curr_logout'],
	"curr_admin"    => $sys_vars['curr_admin'],
	// these placeholders are for individual usage (such as plugins):
	"addon_1"       => "",
	"addon_2"       => "",
	"addon_3"       => ""
	));

$tpl->parse ("template_handle", array("template"));
$tpl->p ("template_handle");

if($sys_setting_vars['online_status'] == 1) {
	// Clear online status for users who didnt log out
	$sys_vars['old_time'] = time() - 3600; // 3600 = 1h
	$db->query("UPDATE ".$tbl_prefix."sys_user SET online_status = '0' WHERE online_status = '1' && curr_login < '".$sys_vars['old_time']."' && uid <> '".$sys_vars['uid']."' ORDER BY online_status");

	// Reactivate own online status if it was deactivated
	$db->query("UPDATE ".$tbl_prefix."sys_user SET online_status = '1' WHERE online_status = '0' && uid = '".$sys_vars['uid']."' ORDER BY uid");
}
?>