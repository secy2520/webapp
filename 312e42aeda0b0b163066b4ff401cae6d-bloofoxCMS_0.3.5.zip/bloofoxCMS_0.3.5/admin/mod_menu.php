<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - admin/mod_menu.php -
//
// Copyrights (c) 2006-2009 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

// Forbid direct call
if(!defined('SYS_INDEX')) {
	die("You can't call this file directly!");
}

for($i=1; $i<=22; $i++) {
	$sub_class[$i] = "class='subalways'";
}

for($j=1; $j<=6; $j++) {
	$menu_class[$j] = "class='always'";
}

switch($tmpl_set['handler'])
{
	case '/mod_plugins.php':
		$menu_class[3] = "class='current'";
		$sub_class[10] = "class='subcurrent'";
	break;
	
	case '/mod_content.php':
		$menu_class[2] = "class='current'";
		
		switch($page)
		{
			case 'media': $sub_class[5] = "class='subcurrent'"; break;
			case 'levels': $sub_class[4] = "class='subcurrent'"; break;
			case 'pages': $sub_class[3] = "class='subcurrent'"; break;
			case 'content': $sub_class[3] = "class='subcurrent'"; break;
			default: $sub_class[2] = "class='subcurrent'"; break;
		}
	break;

	case '/mod_settings.php':
		$menu_class[3] = "class='current'";
		
		switch($page)
		{
			case 'projects': $sub_class[7] = "class='subcurrent'"; break;
			case 'lang': $sub_class[8] = "class='subcurrent'"; break;
			case 'tmpl': $sub_class[9] = "class='subcurrent'"; break;
			case 'plugins': $sub_class[10] = "class='subcurrent'"; break;
			case 'charset': $sub_class[11] = "class='subcurrent'"; break;
			case 'editor': break;
			default: $sub_class[6] = "class='subcurrent'"; break;
		}
	break;
	
	case '/mod_user.php':
		$menu_class[4] = "class='current'";
		
		switch($page)
		{
			case 'groups': $sub_class[13] = "class='subcurrent'"; break;
			case 'permissions': $sub_class[14] = "class='subcurrent'"; break;
			case 'sessions': $sub_class[15] = "class='subcurrent'"; break;
			default: $sub_class[12] = "class='subcurrent'"; break;
		}
	break;
	
	case '/mod_tools.php':
		$menu_class[5] = "class='current'";
		switch($page)
		{
			case 'upload': $sub_class[17] = "class='subcurrent'"; break;
			case 'backup': $sub_class[18] = "class='subcurrent'"; break;
			case 'phpmyadmin': $sub_class[20] = "class='subcurrent'"; break;
			
			default: $sub_class[16] = "class='subcurrent'"; break;
		}
	break;
	
	default:
		switch($page)
		{
			case 'changepw':
				$menu_class[6] = "class='current'";
				$sub_class[22] = "class='subcurrent'"; 
			break;

			case 'stats':
				$menu_class[5] = "class='current'"; // Tools
				$sub_class[1] = "class='subcurrent'";
			break;
			
			case 'myprofile':
				$menu_class[6] = "class='current'";
				$sub_class[21] = "class='subcurrent'"; 
			break;
			
			default:
				$menu_class[1] = "class='current'"; // Home
			break;
		}
	break;
}

if($sys_group_vars['content'] == 1) {
	$menu2_sub1 = "<li><a ".$sub_class[2]." href=\"index.php?mode=content\">".get_caption('Articles')."</a></li>";
	$menu2_sub2 = "<li><a ".$sub_class[3]." href=\"index.php?mode=content&page=pages\">".get_caption('Pages')."</a></li>";
	$menu2_sub3 = "<li><a ".$sub_class[4]." href=\"index.php?mode=content&page=levels\">".get_caption('Levels')."</a></li>";
	$menu2_sub4 = "<li><a ".$sub_class[5]." href=\"index.php?mode=content&page=media\">".get_caption('Mediacenter')."</a></li>";
	$menu2_sub5 = "";
	$menu2_sub6 = "";
}

if($sys_group_vars['settings'] == 1) {
	$menu3_sub1 = "<li><a ".$sub_class[6]." href=\"index.php?mode=settings\">".get_caption('Settings')."</a></li>";
	$menu3_sub2 = "<li><a ".$sub_class[7]." href=\"index.php?mode=settings&page=projects\">".get_caption('Configurations')."</a></li>";
	$menu3_sub3 = "<li><a ".$sub_class[8]." href=\"index.php?mode=settings&page=lang\">".get_caption('Languages')."</a></li>";
	$menu3_sub4 = "<li><a ".$sub_class[9]." href=\"index.php?mode=settings&page=tmpl\">".get_caption('Templates')."</a></li>";
	$menu3_sub5 = "<li><a ".$sub_class[10]." href=\"index.php?mode=settings&page=plugins\">".get_caption('Plugins')."</a></li>";
	$menu3_sub6 = "<li><a ".$sub_class[11]." href=\"index.php?mode=settings&page=charset\">".get_caption('Charset')."</a></li>";
}

if($sys_group_vars['permissions'] == 1) {
	$menu4_sub1 = "<li><a ".$sub_class[12]." href=\"index.php?mode=user\">".get_caption('User')."</a></li>";
	$menu4_sub2 = "<li><a ".$sub_class[13]." href=\"index.php?mode=user&page=groups\">".get_caption('Groups')."</a></li>";
	$menu4_sub3 = "<li><a ".$sub_class[14]." href=\"index.php?mode=user&page=permissions\">".get_caption('Permissions')."</a></li>";
	$menu4_sub4 = "<li><a ".$sub_class[15]." href=\"index.php?mode=user&page=sessions\">".get_caption('Sessions')."</a></li>";
	$menu4_sub5 = "";
	$menu4_sub6 = "";
}

if($sys_group_vars['tools'] == 1) {
	$menu5_sub1 = "<li><a ".$sub_class[16]." href=\"index.php?mode=tools\">".get_caption('ToolsActivities')."</a></li>";
	$menu5_sub2 = "<li><a ".$sub_class[17]." href=\"index.php?mode=tools&page=upload\">".get_caption('ToolsUpload')."</a></li>";
	$menu5_sub3 = "<li><a ".$sub_class[18]." href=\"index.php?mode=tools&page=backup\">".get_caption('ToolsBackup')."</a></li>";
	$menu5_sub4 = "";
	$menu5_sub5 = "<li><a ".$sub_class[20]." href=\"index.php?mode=tools&page=phpmyadmin\">".get_caption('ToolsPhpmyadmin')."</a></li>";
	$menu5_sub6 = "<li><a ".$sub_class[1]." href=\"index.php?page=stats\">".get_caption('Statistics')."</a></li>";
}

$menu6_sub1 = "<li><a ".$sub_class[21]." href=\"index.php?page=myprofile\">".get_caption('MyProfile')."</a></li>";
$menu6_sub2 = "<li><a ".$sub_class[22]." href=\"index.php?page=changepw\">".get_caption('ChangePw')."</a></li>";
$menu1_sub1 = "<li><a href='index.php?mode=logout' title='".get_caption('Logout')."'>".get_caption('Logout')."</a></li>";

if(!empty($_SESSION["username"])) {
	$menu_logout = "<a href='index.php?mode=logout' title='".get_caption('Logout')."'>".get_caption('Logout')." [ ".$_SESSION["username"]." ]</a>";
}

// Set template block
$tpl->set_block("tmpl_menu", "menu", "menu_handle");

// Set variables
$tpl->set_var(array(
	"menu_title"      => "<p class=\"logo\"><span class=\"small\">bloofoxCMS</span><br />AdminCenter</p>",
	"menu_logout"     => $menu_logout,
	"menu_date"       => date($sys_vars['date']),
	"menu1"           => "<a ".$menu_class[1]." href=\"index.php\" title='".get_caption('Home')."'>".get_caption('Home')."</a>",
	"menu1_sub1"      => $menu1_sub1,
	"menu1_sub2"      => $menu1_sub2,
	"menu1_sub3"      => $menu1_sub3,
	"menu1_sub4"      => $menu1_sub4,
	"menu1_sub5"      => $menu1_sub5,
	"menu1_sub6"      => $menu1_sub6,
	"menu2"           => "<a ".$menu_class[2]." href=\"index.php?mode=content\" title='".get_caption('Contents')."'>".get_caption('Contents')."</a>",
	"menu2_sub1"      => $menu2_sub1,
	"menu2_sub2"      => $menu2_sub2,
	"menu2_sub3"      => $menu2_sub3,
	"menu2_sub4"      => $menu2_sub4,
	"menu2_sub5"      => $menu2_sub5,
	"menu2_sub6"      => $menu2_sub6,
	"menu3"           => "<a ".$menu_class[3]." href=\"index.php?mode=settings\" title='".get_caption('Administration')."'>".get_caption('Administration')."</a>",
	"menu3_sub1"      => $menu3_sub1,
	"menu3_sub2"      => $menu3_sub2,
	"menu3_sub3"      => $menu3_sub3,
	"menu3_sub4"      => $menu3_sub4,
	"menu3_sub5"      => $menu3_sub5,
	"menu3_sub6"      => $menu3_sub6,
	"menu4"           => "<a ".$menu_class[4]." href=\"index.php?mode=user\" title='".get_caption('Security')."'>".get_caption('Security')."</a>",
	"menu4_sub1"      => $menu4_sub1,
	"menu4_sub2"      => $menu4_sub2,
	"menu4_sub3"      => $menu4_sub3,
	"menu4_sub4"      => $menu4_sub4,
	"menu4_sub5"      => $menu4_sub5,
	"menu4_sub6"      => $menu4_sub6,
	"menu5"           => "<a ".$menu_class[5]." href=\"index.php?mode=tools\" title='".get_caption('Tools')."'>".get_caption('Tools')."</a>",
	"menu5_sub1"      => $menu5_sub1,
	"menu5_sub2"      => $menu5_sub2,
	"menu5_sub3"      => $menu5_sub3,
	"menu5_sub4"      => $menu5_sub4,
	"menu5_sub5"      => $menu5_sub5,
	"menu5_sub6"      => $menu5_sub6,
	"menu6"           => "<a ".$menu_class[6]." href=\"index.php?page=myprofile\" title='".get_caption('MyAccount')."'>".get_caption('MyAccount')."</a>",
	"menu6_sub1"      => $menu6_sub1,
	"menu6_sub2"      => $menu6_sub2
	));

// Parse template with variables
$tpl->parse("menu_handle", "menu", true);

?>