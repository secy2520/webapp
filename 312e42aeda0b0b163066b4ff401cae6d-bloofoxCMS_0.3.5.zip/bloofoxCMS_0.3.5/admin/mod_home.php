<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - admin/mod_home.php -
//
// Copyrights (c) 2006-2009 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

// Forbid direct call
if(!defined('SYS_INDEX')) {
	die("You can't call this file directly!");
}

// Set template block
$tpl->set_block("tmpl_content", "home", "home_handle");

switch($page)
{
	case 'changepw':
		include_once("include/inc_home_changepw.php");
	break;
	
	case 'profiles':
		include_once("include/inc_home_profiles.php");
	break;
	
	case 'stats':
		include_once("include/inc_home_stats.php");
	break;
	
	case 'myprofile':
		include_once("include/inc_home_myprofile.php");
	break;
	
	default:
		// Get latest login for current user
		$last_login = $perm->get_last_login($db);
		$failed_logins = $perm->count_failed_session($db,$last_login);

		// Create Who is online box
		$next = 0;
		$db->query("SELECT uid,username,curr_login FROM ".$tbl_prefix."sys_user WHERE online_status = '1' ORDER BY online_status LIMIT 10");
		while($db->next_record()):
			if($next == 1) {
				$home_online_users .= " | ";
			}
			$home_online_users .= $ac->create_link("index.php?page=profiles&user_id=",$db->f("uid"),$db->f("username"),"",$db->f("username"))
				." (".date($sys_vars['datetime'],$db->f("curr_login")).")";
			$next = 1;
		endwhile;
				
		// Create project overview
		$next = 0;
		$db->query("SELECT meta_title,lang_id,urls FROM ".$tbl_prefix."sys_config ORDER BY cid LIMIT 10");
		while($db->next_record()):
			$url = explode("\n",$db->f("urls"));
			if($next == 1) {
				$home_config_urls .= " | ";
			}
			$home_config_urls .= "<a href='".$url[0]."' target='_blank' title='".$url[0]."'>".$db->f("meta_title")."</a> (".$ac->get_lang_name($db->f("lang_id")).")";
			$next = 1;
		endwhile;

		// Create YourData section
		$sys_profile = $perm->get_user_profile($db,$_SESSION["uid"]);
		
		// Do version check
		if($sys_setting_vars['update_check'] == "1") {
			$home['upd_warning'] = $ac->get_update_message();
		}
		
		// Create IP Log
		$home['iplog'] = "<p>".get_caption('YourIPAddress')." ".$_SERVER['REMOTE_ADDR']."</p>";
		if($sys_setting_vars['login_protection'] == "1") {
			$home['iplog'] .= "<p>".get_caption('InfoIPLog')."</p>";
		}
		
		// Create password warning
		if($_SESSION["username"] == "admin" && $perm->get_current_password($db) == md5("admin")) {
			$home['pwd_warning'] = "<p style='color: red;'>".get_caption('WarningChangePassword')."</p>";
		}
		
		// Set variables
		if(empty($last_login)): $last_login = 0; endif;
		$tpl->set_var(array(
			"home_title"         => "<h2>".get_caption('WelcomeToAdmincenter')."</h2>",
			"home_system_title"  => "<p class='bold'>".get_caption('SystemInformation')."</p>",
			"home_database_info" => get_caption('Database').": ".$sys_vars['database'],
			"home_server_info"   => get_caption('Server').": ".$_SERVER['SERVER_NAME'],
			"home_bloofox_info"  => get_caption('Version').": ".get_current_version(),
			"home_mysql_info"    => "MySQL: ".mysql_get_client_info(),
			"home_php_info"      => "PHP: ".phpversion(),
			"home_account_title" => "<p class='bold'>".get_caption('MyAccount')."</p>",
			"home_loggedin"      => "<p>".get_caption('LoggedIn')." ".$_SESSION['username']." [ <a href='index.php?mode=logout'>".get_caption('Logout')."</a> ] </p>",
			"home_lastlogin"     => "<p>".get_caption('YourLastLogin').": ".date($sys_vars['datetime'],$last_login)."; ".get_caption('FailedLogins').": ".$failed_logins."</p>",
			"home_online_title"  => "<p class='bold'>".get_caption('WhoIsOnline')."</p>",
			"home_online_users"  => $home_online_users,
			"home_projects_title" => "<p class='bold'>".get_caption('Configurations')."</p>",
			"home_projects"      => $home_config_urls,
			"home_iplog_title"   => "<p class='bold'>".get_caption('IP Log')."</p>",
			"home_iplog"         => $home['iplog'],
			"home_pwd_warning"   => $home['pwd_warning'],
			"home_upd_warning"   => $home['upd_warning'],
			"legend_title"       => "<p class='bold'>".get_caption('Legend')."</p>",
			"legend_new"         => "<img src='images/icon_add.gif' alt='".get_caption("AddText")."' border='0' width='16' height='16' /> ".get_caption("AddText"),
			"legend_edit"        => "<img src='images/icon_edit.gif' alt='".get_caption("EditText")."' border='0' width='16' height='16' /> ".get_caption("EditText"),
			"legend_delete"      => "<img src='images/icon_trash.gif' alt='".get_caption("DeleteText")."' border='0' width='16' height='16' /> ".get_caption("DeleteText"),
			"legend_content"     => "<img src='images/icon_content.gif' alt='".get_caption("Articles")."' border='0' width='16' height='16' /> ".get_caption("Articles"),
			"legend_preview"     => "<img src='images/icon_preview.gif' alt='".get_caption("Preview")."' border='0' width='16' height='16' /> ".get_caption("Preview"),
			"legend_profile"     => "<img src='images/icon_profile.gif' alt='".get_caption("Profile")."' border='0' width='16' height='16' /> ".get_caption("Profile"),
			"legend_quit"        => "<img src='images/icon_exit.gif' alt='".get_caption("Quit")."' border='0' width='16' height='16' /> ".get_caption("Quit")
			));
	break;
}

// Parse template with variables
$tpl->parse("home_handle", "home", true);
?>