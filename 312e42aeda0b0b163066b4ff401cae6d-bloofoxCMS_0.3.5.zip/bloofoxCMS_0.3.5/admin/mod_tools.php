<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - admin/mod_tools.php -
//
// Copyrights (c) 2006-2009 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

// Forbid direct call
if(!defined('SYS_INDEX')) {
	die("You can't call this file directly!");
}

// Set template block
$tpl->set_block("tmpl_content", "tools", "tools_handle");

switch($page)
{
	case 'upload':
		include_once("include/inc_tools_upload.php");
	break;
	
	case 'backup':
		include_once("include/inc_tools_backup.php");
	break;
			
	case 'phpmyadmin':
		include_once("include/inc_tools_phpmyadmin.php");
	break;
	
	default: // Periodic Activities
		switch($action)
		{
			case 'optimize': // optimize tables
				if(isset($_POST['send']) && $sys_group_vars['demo'] == 0 && $sys_rights['tools']['write'] == 1) {
					// run sql command
					$db->query("OPTIMIZE TABLE ".$tbl_prefix."sys_charset, ".$tbl_prefix."sys_config, ".$tbl_prefix."sys_content, ".$tbl_prefix."sys_explorer, ".$tbl_prefix."sys_lang, ".$tbl_prefix."sys_media, ".$tbl_prefix."sys_permission, ".$tbl_prefix."sys_plugin, ".$tbl_prefix."sys_profile, ".$tbl_prefix."sys_session, ".$tbl_prefix."sys_setting, ".$tbl_prefix."sys_template, ".$tbl_prefix."sys_user, ".$tbl_prefix."sys_usergroup");
					// header page
					load_url("index.php?mode=tools");
				}
				
				// Set variables
				$tpl->set_var(array(
					"tools_title"    => "<h2>".get_caption("OptimizeDB")." - ".get_caption('ToolsPeriodic')." - ".get_caption('Tools')."</h2>",
					"tools_action"   => "index.php?mode=tools&action=optimize",
					"tools_question" => get_caption("OptimizeDB")."?",
					"tools_button_send" => "<input class='btn' type='submit' name='send' value='".get_caption("OptimizeDB")."' />"
					));
			break;

			case 'inactive_users': // delete inactive users till $date
				if(isset($_POST['send']) && $sys_group_vars['demo'] == 0 && $sys_rights['tools']['delete'] == 1) {
					$_POST['date_to'] = validate_date($_POST['date_to']);
					
					if(!mandatory_field($_POST['date_to']) || $_POST['date_to'] == 0) { $error = "<p class='error'>".get_caption('ErrorInvalidDate')."</p>"; }
					
					if($error == "") {
						// run sql command
						$db->query("DELETE FROM ".$tbl_prefix."sys_user WHERE status = '0' && user_since < '".$_POST['date_to']."'");
						// header page
						load_url("index.php?mode=tools");
					}
				}
				
				// Set variables
				$tpl->set_var(array(
					"tools_title"    => "<h2>".get_caption("ClearInactiveUsers")." - ".get_caption('ToolsPeriodic')." - ".get_caption('Tools')."</h2>",
					"tools_error"    => $error,
					"tools_action"   => "index.php?mode=tools&action=inactive_users",
					"tools_question" => get_caption("ClearInactiveUsers")."?",
					"tools_date"     => get_caption("RegisterTillDate")." <input type='text' name='date_to' size='10' maxlength='10' value='".date("d.m.Y",time()-3600*24*7)."' /> ".get_caption("DateFormat"),
					"tools_button_send" => "<input class='btn' type='submit' name='send' value='".get_caption("ClearInactiveUsers")."' />"
					));
			break;
			
			case 'deleted_users': // delete deleted users
				if(isset($_POST['send']) && $sys_group_vars['demo'] == 0 && $sys_rights['tools']['delete'] == 1) {
					// run sql command
					$db->query("DELETE FROM ".$tbl_prefix."sys_user WHERE deleted = '1'");
					// header page
					load_url("index.php?mode=tools");
				}
				
				// Set variables
				$tpl->set_var(array(
					"tools_title"    => "<h2>".get_caption("ClearDeletedUsers")." - ".get_caption('ToolsPeriodic')." - ".get_caption('Tools')."</h2>",
					"tools_action"   => "index.php?mode=tools&action=deleted_users",
					"tools_question" => get_caption("ClearDeletedUsers")."?",
					"tools_button_send" => "<input class='btn' type='submit' name='send' value='".get_caption("ClearDeletedUsers")."' />"
					));
			break;
			
			case 'sessions': // delete failed sessions till $date
				if(isset($_POST['send']) && $sys_group_vars['demo'] == 0 && $sys_rights['tools']['delete'] == 1) {
					$_POST['date_to'] = validate_date($_POST['date_to']);
					
					if(!mandatory_field($_POST['date_to']) || $_POST['date_to'] == 0) { $error = "<p class='error'>".get_caption('ErrorInvalidDate')."</p>"; }
					
					if($error == "") {
						// run sql command
						if($_POST['option'] == 1) {
							$db->query("DELETE FROM ".$tbl_prefix."sys_session WHERE status = '0' && timestamp < '".$_POST['date_to']."'");
						} else {
							$db->query("DELETE FROM ".$tbl_prefix."sys_session WHERE timestamp < '".$_POST['date_to']."'");
						}
						// header page
						load_url("index.php?mode=tools");
					}
				}
				
				// Set variables
				$tpl->set_var(array(
					"tools_title"    => "<h2>".get_caption("ClearSessions")." - ".get_caption('ToolsPeriodic')." - ".get_caption('Tools')."</h2>",
					"tools_error"    => $error,
					"tools_action"   => "index.php?mode=tools&action=sessions",
					"tools_question" => get_caption("ClearSessions")."?",
					"tools_date"     => get_caption("LoginTillDate")." <input type='text' name='date_to' size='10' maxlength='10'  value='".date("d.m.Y",time()-3600*24*7)."' /> ".get_caption("DateFormat"),
					"tools_option"   => "<input type='checkbox' name='option' /> ".get_caption("ClearFailedSessions"),
					"tools_button_send" => "<input class='btn' type='submit' name='send' value='".get_caption("ClearSessions")."' />"
					));
			break;
			
			default: // Create overview
				// Set variables
				$tpl->set_var(array(
					"tools_title"           => "<h2>".get_caption('ToolsActivities')." - ".get_caption('Tools')."</h2>",
					"tools_action_name"     => get_caption("Action"),
					"tools_activity_name"   => get_caption("Activity"),
					"tools_optimize"        => "<a href='index.php?mode=tools&action=optimize'>".get_caption("OptimizeDB")."</a>",
					"tools_optimize_action" => $ac->create_link("index.php?mode=tools&action=optimize&id=","1",get_caption("OptimizeDB"),"edit",get_caption("Edit")),
					"tools_inactive_users"  => "<a href='index.php?mode=tools&action=inactive_users'>".get_caption("ClearInactiveUsers")."</a>",
					"tools_inactive_users_action" => $ac->create_link("index.php?mode=tools&action=inactive_users&id=","1",get_caption("ClearInactiveUsers"),"edit",get_caption("Edit")),
					"tools_deleted_users"   => "<a href='index.php?mode=tools&action=deleted_users'>".get_caption("ClearDeletedUsers")."</a>",
					"tools_deleted_users_action" => $ac->create_link("index.php?mode=tools&action=deleted_users&id=","1",get_caption("ClearDeletedUsers"),"edit",get_caption("Edit")),
					"tools_sessions"        => "<a href='index.php?mode=tools&action=sessions'>".get_caption("ClearSessions")."</a>",
					"tools_sessions_action" => $ac->create_link("index.php?mode=tools&action=sessions&id=","1",get_caption("ClearSessions"),"edit",get_caption("Edit"))
					));
			break;
		}
	break;
}

// Parse template with variables
$tpl->parse("tools_handle", "tools", true);
?>