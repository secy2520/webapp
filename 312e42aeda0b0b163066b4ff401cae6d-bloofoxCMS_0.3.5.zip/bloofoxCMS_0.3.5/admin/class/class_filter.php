<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - admin/class/class_filter.php -
//
// Copyrights (c) 2006-2009 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

// Forbid direct call
if(!defined('SYS_INDEX')) {
	die("You can't call this file directly!");
}

class filter {
	//**
	// variables
	var $var = 1;
	
	//**
	// constructor
	function filter()
	{
	}
	
	//**
	// return filter form for contents
	function create_filter_content($db)
	{
		global $tbl_prefix;
		
		$filter_option1 = "<option value=''>- ".get_caption('FilterShowAllProjects')." -</option>";
		$db->query("SELECT cid,name FROM ".$tbl_prefix."sys_config ORDER BY cid");
		while($db->next_record()):
			if($_SESSION["filter_content"] == $db->f("cid")) {
				$filter_option1 .= "<option value='".$db->f("cid")."' selected='selected'>".$db->f("name")."</option>";
			} else {
				$filter_option1 .= "<option value='".$db->f("cid")."'>".$db->f("name")."</option>";
			}
		endwhile;
		
		$filter_form = "<form method='post'>"
			."<table><tr>"
			."<td><select name='filter_content'>".$filter_option1."</select></td>"
			."<td><input class='btn' type='submit' name='send' value='".get_caption('SetFilter')."' /></td>"
			."</tr></table>"
			."</form>";
		
		return($filter_form);
	}
	
	//**
	// return filter form for mediacenter
	function create_filter_media($db)
	{
		$filter_option = "<option value=''>- ".get_caption('FilterShowAllTypes')." -</option>";
		if($_SESSION["filter_media"] == "0") {
			$filter_option .= "<option value='0' selected='selected'>".get_caption('File')."</option>";
		} else {
			$filter_option .= "<option value='0'>".get_caption('File')."</option>";
		}
		if($_SESSION["filter_media"] == "1") {
			$filter_option .= "<option value='1' selected='selected'>".get_caption('Image')."</option>";
		} else {
			$filter_option .= "<option value='1'>".get_caption('Image')."</option>";
		}
		
		$filter_form = "<form method='post'>"
			."<table><tr>"
			."<td><select name='filter_media'>".$filter_option."</select></td>"
			."<td><input class='btn' type='submit' name='send' value='".get_caption('SetFilter')."' /></td>"
			."</tr></table>"
			."</form>";
		
		return($filter_form);
	}
	
	//**
	// return filter form for users
	function create_filter_user($db)
	{
		$filter_option = "<option value=''>- ".get_caption('FilterShowAllUsers')." -</option>";
		if($_SESSION["filter_user"] == "1") {
			$filter_option .= "<option value='1' selected='selected'>".get_caption('Active')."</option>";
		} else {
			$filter_option .= "<option value='1'>".get_caption('Active')."</option>";
		}
		if($_SESSION["filter_user"] == "0") {
			$filter_option .= "<option value='0' selected='selected'>".get_caption('Inactive')."</option>";
		} else {
			$filter_option .= "<option value='0'>".get_caption('Inactive')."</option>";
		}
		
		$filter_form = "<form method='post'>"
			."<table><tr>"
			."<td><select name='filter_user'>".$filter_option."</select></td>"
			."<td><input class='btn' type='submit' name='send' value='".get_caption('SetFilter')."' /></td>"
			."</tr></table>"
			."</form>";
		
		return($filter_form);
	}
}
?>