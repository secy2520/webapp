<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - admin/class/class_admincenter.php -
//
// Copyrights (c) 2006-2009 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

// Forbid direct call
if(!defined('SYS_INDEX')) {
	die("You can't call this file directly!");
}

class admincenter {
	//**
	// variables
	var $var = 1;
	var $insert_path = 0;
	
	//**
	// constructor
	function admincenter()
	{
		$_GET['cid'] = $this->clean_int_values($_GET['cid']);
		$_GET['eid'] = $this->clean_int_values($_GET['eid']);
		$_GET['mid'] = $this->clean_int_values($_GET['mid']);
		$_GET['lid'] = $this->clean_int_values($_GET['lid']);
		$_GET['tid'] = $this->clean_int_values($_GET['tid']);
		$_GET['pid'] = $this->clean_int_values($_GET['pid']);
		$_GET['gid'] = $this->clean_int_values($_GET['gid']);
		$_GET['sid'] = $this->clean_int_values($_GET['sid']);
		$_GET['userid'] = $this->clean_int_values($_GET['userid']);
	}
	
	//**
	// check and clean integer values in GET parameters
	function clean_int_values($value)
	{
		if(!CheckInteger($value)) {
			return(0);
		}
		return($value);
	}
	
	//**
	// creates action links to backend sites
	function create_link($url,$id,$title,$class,$caption,$target=0)
	{
		if(empty($url) || empty($id)) {
			return("<a href='#' title='".$title."' class='".$class."'>".$caption."</a> ");
		}
		
		if($target == 0) {
			return("<a href='".$url.$id."' title='".$title."' class='".$class."'>".$caption."</a> ");
		} else {
			return("<a href='".$url.$id."' title='".$title."' class='".$class."' target='_new'>".$caption."</a> ");
		}
	}
	
	//**
	// return username from user_id
	function get_username($user_id)
	{
		global $tbl_prefix;
		$db = new DB_Tpl();
		
		$db->query("SELECT username FROM ".$tbl_prefix."sys_user WHERE uid = '".$user_id."' ORDER BY uid");
		while($db->next_record()):
			$username = $db->f("username");
		endwhile;
		
		return($username);
	}
	
	//**
	// return language name from lang_id
	function get_lang_name($lang_id)
	{
		global $tbl_prefix;
		$db = new DB_Tpl();
		
		$db->query("SELECT name FROM ".$tbl_prefix."sys_lang WHERE lid = '".$lang_id."' ORDER BY lid");
		while($db->next_record()):
			$lang_name = $db->f("name");
		endwhile;
		
		return($lang_name);
	}
	
	//**
	// return template name from tmpl_id
	function get_tmpl_name($tmpl_id)
	{
		global $tbl_prefix;
		$db = new DB_Tpl();
		
		$db->query("SELECT name FROM ".$tbl_prefix."sys_template WHERE tid = '".$tmpl_id."' ORDER BY tid");
		while($db->next_record()):
			$tmpl_name = $db->f("name");
		endwhile;
		
		return($tmpl_name);
	}
	
	//**
	// return user groups
	function get_sys_usergroups($groups,$action)
	{
		global $tbl_prefix;
		$db = new DB_Tpl();
		
		$sys_usergroups = "";
		$sys_counter = 0;
		$db->query("SELECT name FROM ".$tbl_prefix."sys_usergroup ORDER BY gid");
		while($db->next_record()):
			$sys_counter += 1;
			$group_checked = 0;
			
			if($action == "edit") {
				for($i=0;$i<count($groups);$i++)
				{
					if($groups[$i] == $db->f("name")) {
						$group_checked = 1;
					}
				}
			} else {
				if($_POST[$sys_counter] == true) {
					$group_checked = 1;
				}
			}
			
			if($group_checked) {
				$sys_usergroups .= "<input type='checkbox' name='".$sys_counter."' value='".$db->f("name")."' checked='checked' /> ".$db->f("name")."<br />";
			} else {
				$sys_usergroups .= "<input type='checkbox' name='".$sys_counter."' value='".$db->f("name")."' /> ".$db->f("name")."<br />";
			}
		endwhile;
		
		return($sys_usergroups);
	}
	
	//**
	// return  templates
	function get_sys_templates($current)
	{
		global $tbl_prefix;
		$db = new DB_Tpl();

		$sys_tmpl = "";
		$db->query("SELECT tid,name FROM ".$tbl_prefix."sys_template WHERE be = '0' ORDER BY tid");
		while($db->next_record()):
			if($current == $db->f("tid")) {
				$sys_tmpl .= "<option value='".$db->f("tid")."' selected='selected'>".$db->f("name")."</option>";
			} else {
				$sys_tmpl .= "<option value='".$db->f("tid")."'>".$db->f("name")."</option>";
			}
		endwhile;
		
		return($sys_tmpl);
	}
	
	//**
	// return languages
	function get_sys_languages($current)
	{
		global $tbl_prefix;
		$db = new DB_Tpl();
		
		$sys_lang = "";
		$db->query("SELECT lid,name FROM ".$tbl_prefix."sys_lang ORDER BY lid");
		while($db->next_record()):
			if($current == $db->f("lid")) {
				$sys_lang .= "<option value='".$db->f("lid")."' selected='selected'>".$db->f("name")."</option>";
			} else {
				$sys_lang .= "<option value='".$db->f("lid")."'>".$db->f("name")."</option>";
			}
		endwhile;
		
		return($sys_lang);
	}
	
	//**
	// return charsets
	function get_sys_charset($current)
	{
		global $tbl_prefix;
		$db = new DB_Tpl();
		
		$sys_charset = "";
		$db->query("SELECT * FROM ".$tbl_prefix."sys_charset ORDER BY name");
		while($db->next_record()):
			if($current == $db->f("name")) {
				$sys_charset .= "<option value='".$db->f("name")."' selected='selected'>".$db->f("name")."</option>";
			} else {
				$sys_charset .= "<option value='".$db->f("name")."'>".$db->f("name")."</option>";
			}
		endwhile;
		
		return($sys_charset);
	}
	
	//**
	// return doctypes
	function get_doctypes($current)
	{
		global $doctype_setup;
		
		$doctypes = "";
		for($i=0; $i<count($doctype_setup); $i++) {
			if($current == $doctype_setup[$i]) {
				$doctypes .= "<option value='".$doctype_setup[$i]."' selected='selected'>".$doctype_setup[$i]."</option>";
			} else {
				$doctypes .= "<option value='".$doctype_setup[$i]."'>".$doctype_setup[$i]."</option>";
			}
		}
		
		return($doctypes);
	}
	
	//**
	// return group names for insert
	function get_group_names_for_insert()
	{
		global $tbl_prefix;
		$db = new DB_Tpl();
		
		$groups = "";
		$sys_counter = 0;
		$db->query("SELECT name FROM ".$tbl_prefix."sys_usergroup ORDER BY gid");
		while($db->next_record()):
			$sys_counter += 1;
			if($_POST[$sys_counter]) {
				$groups .= $db->f("name").",";
			}
		endwhile;
		$groups = substr($groups,0,-1);
		
		return($groups);
	}
	
	//**
	// return user groups for selection
	function get_sys_groups($current)
	{
		global $tbl_prefix;
		$db = new DB_Tpl();
		
		$sys_groups = "";
		$db->query("SELECT gid,name FROM ".$tbl_prefix."sys_usergroup ORDER BY gid");
		while($db->next_record()):
			if($current == $db->f("gid")) {
				$sys_groups .= "<option value='".$db->f("gid")."' selected='selected'>".$db->f("name")."</option>";
			} else {
				$sys_groups .= "<option value='".$db->f("gid")."'>".$db->f("name")."</option>";
			}
		endwhile;
		
		return($sys_groups);
	}
	
	//**
	// get files of a folder and make a list
	function get_files($folder,$selected,$format="")
	{
		$dir = opendir($folder);
		while($file = readdir($dir))
		{
			// only files in $format
			if($format != "") {
				$strpos = strpos($file,$format);
			} else {
				if(strpos($file,".") != 0) {
					$strpos = 0;
				} else {
					$strpos = 1;
				}
			}
			if($file != "." && $file != ".." && $strpos != 0)
			{
				if($this->insert_path == 1) {
					$file = $folder.$file;
				}
				if($selected == $file) {
					$dir_list .= "<option value='".$file."' selected='selected'>".$file."</option>";
				} else {
					$dir_list .= "<option value='".$file."'>".$file."</option>";
				}
			}
		}
		closedir($dir);
		return($dir_list);
	}
	
	//**
	// return folders
	function get_folders($current)
	{
		global $folder_setup;
		
		$folders = "";
		for($i=0; $i<count($folder_setup); $i++) {
			if($current == $folder_setup[$i]) {
				$folders .= "<option value='".$folder_setup[$i]."' selected='selected'>".$folder_setup[$i]."</option>";
			} else {
				$folders .= "<option value='".$folder_setup[$i]."'>".$folder_setup[$i]."</option>";
			}
		}
		
		// add template folders automatically
		$this->insert_path = 1;
		$folders .= $this->get_files("../templates/",$current,"");
		
		// add image folders automatically (folders in dir /media/images)
		$folders .= $this->get_files("../media/images/",$current,"");
		
		$this->insert_path = 0;
		return($folders);
	}
	
	//**
	// Get update information if relevant
	function get_update_message()
	{
		$version['current'] = get_current_version();
		// open file from bloofox.com server with version information
		$fp = @fopen("http://www.bloofox.com/versioncheck/version.txt","r");
		if(!$fp) {
			$version['check'] = "<p style='color: red;'>".get_caption('ErrorVersionCheck')."</p>\n";
		} else {
			while(!@feof($fp))
			{
				$version['latest'] = @fread($fp, 10);
			}
			@fclose($fp);
			
			// convert current and latest version
			$version['latest'] = explode(".", $version['latest']);
			$version['current'] = explode(" ",$version['current']);
			$version['current'] = explode(".",$version['current'][1]);
			
			if(file_exists("../update/index.php")) {
				$update_link = "<a href='../update'>".get_caption('Update')."</a>";
			}
			$version['check'] = "<p style='color: red;'>".get_caption('VersionUpdate')." ".$update_link."</p>";
			
			// compare current and latest version
			if($version['latest'][0] <= $version['current'][0]) {
				if($version['latest'][0] < $version['current'][0]) {
					$version['check'] = ""; // no update needed
				}
				if($version['latest'][1] <= $version['current'][1]) {
					if($version['latest'][1] < $version['current'][1]) {
						$version['check'] = ""; // no update needed
					}
					if($version['latest'][2] <= $version['current'][2]) {
						$version['check'] = ""; // no update needed
					}
				}
			}
		}
		
		return($version['check']);
	}
	
	//**
	// return language file for admincenter
	function get_admin_language_file($db)
	{
		global $tbl_prefix;
		
		if(isset($_SESSION['uid'])) {
			$db->query("SELECT be_lang FROM ".$tbl_prefix."sys_profile WHERE user_id = '".$_SESSION['uid']."' ORDER BY user_id LIMIT 1");
			while($db->next_record()):
				$lid = $db->f("be_lang");
			endwhile;
			
			$db->query("SELECT filename FROM ".$tbl_prefix."sys_lang WHERE lid = '".$lid."' ORDER BY lid LIMIT 1");
			while($db->next_record()):
				$filename = $db->f("filename");
			endwhile;
			
			if(mandatory_field($filename)) {
				return($filename);
			}
		}
		
		$db->query("SELECT filename FROM ".$tbl_prefix."sys_lang ORDER BY lid LIMIT 1");
		while($db->next_record()):
			$filename = $db->f("filename");
		endwhile;
		
		return($filename);
	}
	
	//**
	// validate post variables for projects
	function validate_post_vars_project()
	{
		$_POST['name'] = validate_text($_POST['name']);
		$_POST['meta_title'] = validate_text($_POST['meta_title']);
		$_POST['meta_desc'] = validate_text($_POST['meta_desc']);
		$_POST['meta_keywords'] = validate_text($_POST['meta_keywords']);
		$_POST['meta_author'] = validate_text($_POST['meta_author']);
		$_POST['meta_copyright'] = validate_text($_POST['meta_copyright']);
		$_POST['mail'] = validate_text($_POST['mail']);
	}

	//**
	// show demo error
	function show_demo_error($demo_mode=0) {
		if($demo_mode == 1) {
			return("<p class='error'>".get_caption('ErrorDemoMode')."</p>");
		}
		return('');
	}
}
?>