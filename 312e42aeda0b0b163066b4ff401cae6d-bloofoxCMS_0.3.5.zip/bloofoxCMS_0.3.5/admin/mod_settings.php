<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - admin/mod_settings.php -
//
// Copyrights (c) 2006-2009 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

// Forbid direct call
if(!defined('SYS_INDEX')) {
	die("You can't call this file directly!");
}

// Set template block
$tpl->set_block("tmpl_content", "settings", "settings_handle");

switch($page)
{
	case 'charset':
		include_once("include/inc_settings_charset.php");
	break;
	
	case 'editor':
		include_once("include/inc_settings_editor.php");
	break;
			
	case 'plugins':
		include_once("include/inc_settings_plugins.php");
	break;

	case 'tmpl':
		include_once("include/inc_settings_tmpl.php");
	break;
	
	case 'lang':
		include_once("include/inc_settings_lang.php");
	break;
	
	case 'projects':
		include_once("include/inc_settings_projects.php");
	break;
	
	default: // General
		include_once("include/inc_settings_general.php");
	break;
}

// Parse template with variables
$tpl->parse("settings_handle", "settings", true);
?>