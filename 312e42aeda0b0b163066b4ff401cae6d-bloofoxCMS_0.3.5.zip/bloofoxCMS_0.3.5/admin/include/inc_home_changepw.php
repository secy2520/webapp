<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - admin/inc_home_changepw.php -
//
// Copyrights (c) 2006-2008 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

// Forbid direct call
if(!defined('SYS_INDEX')) {
	die("You can't call this file directly!");
}

if(isset($_POST['send']) && $sys_group_vars['demo'] == 0) {
	// format input fields
	$_POST['old_pw'] = validate_text($_POST['old_pw']);
	$_POST['new_pw'] = validate_text($_POST['new_pw']);
	$_POST['new_pw_confirm'] = validate_text($_POST['new_pw_confirm']);
	$old_password = md5($_POST['old_pw']);
	
	// check valid old pwd
	if($old_password != $perm->get_current_password($db)) {
		$error = "<p class='error'>".get_caption('ErrorOldPassword')."</p>";
	}
	
	// check new pwd
	if(!mandatory_field($_POST['new_pw']) && $error == "") { $error = "<p class='error'>".get_caption('ErrorPassword')."</p>"; }
	if(!check_string_rules($_POST['new_pw'],6) && $error == "") { $error = "<p class='error'>".get_caption('ErrorPasswordShort')."</p>"; }
	if(!check_string_rules($_POST['new_pw'],6,$sys_setting_vars['pw_rule']) && $error == "") { $error = "<p class='error'>".get_caption('ErrorPasswordValid'.$sys_setting_vars['pw_rule'])."</p>"; }
	if($_POST['new_pw'] != $_POST['new_pw_confirm'] && $error == "") { $error = "<p class='error'>".get_caption('RegErrorPassword')."</p>"; }
	
	if($error == "") {
		// save changes in database
		$db->query("UPDATE ".$tbl_prefix."sys_user SET password = '".md5($_POST['new_pw'])."' WHERE uid = '".$_SESSION["uid"]."' ORDER BY uid LIMIT 1");
		
		//load_url("index.php?page=changepw");
		$error = "<p class='ok'>".get_caption('PasswordChanged')."</p>";
		unset($_POST);
	}
}
		
// Set variables
$tpl->set_var(array(
	"home_title"           => "<h2>".get_caption('ChangePw')." - ".get_caption('MyAccount')."</h2>",
	"home_error"           => $error,
	"home_action"          => "index.php?page=changepw",
	"home_old_pw"          => get_caption('OldPassword'),
	"home_old_pw_input"    => "<input type='password' name='old_pw' size='25' maxlength='250' value='".$_POST['old_pw']."' />",
	"home_new_pw"          => get_caption('NewPassword'),
	"home_new_pw_input"    => "<input type='password' name='new_pw' size='25' maxlength='250' value='".$_POST['new_pw']."' />",
	"home_pw_confirm"      => get_caption('RegPassword'),
	"home_pw_confirm_input" => "<input type='password' name='new_pw_confirm' size='25' maxlength='250' value='".$_POST['new_pw_confirm']."' />",
	"home_button_send"     => "<input class='btn' type='submit' name='send' value='".get_caption('SaveChanges')."' />"
	));
?>