<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - admin/inc_home_stats.php -
//
// Copyrights (c) 2006-2009 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

// Forbid direct call
if(!defined('SYS_INDEX')) {
	die("You can't call this file directly!");
}

// Make queries
$result1 = $db->query("SELECT cid FROM ".$tbl_prefix."sys_config");
$total1 = $db->num_rows();

$result2 = $db->query("SELECT eid FROM ".$tbl_prefix."sys_explorer");
$total2 = $db->num_rows();

$result3 = $db->query("SELECT cid FROM ".$tbl_prefix."sys_content");
$total3 = $db->num_rows();

$result4 = $db->query("SELECT lid FROM ".$tbl_prefix."sys_lang");
$total4 = $db->num_rows();

$result5 = $db->query("SELECT tid FROM ".$tbl_prefix."sys_template");
$total5 = $db->num_rows();

$result6 = $db->query("SELECT pid FROM ".$tbl_prefix."sys_plugin");
$total6 = $db->num_rows();

$result7 = $db->query("SELECT cid FROM ".$tbl_prefix."sys_charset");
$total7 = $db->num_rows();

$total_all = $total1 + $total2 + $total3 + $total4 + $total5 + $total6 + $total7;

$home_text = "<p class='bold'>".get_caption('General')."</p>";
$home_text .= "<table border='0' width='300'>";
// 1
$home_text .= "<tr class='bg_color2'>";
$home_text .= "<td>".get_caption('Configurations')."</td>";
$home_text .= "<td>".$total1."</td>";
if($total_all != 0) {
	$total1 = round($total1 / $total_all * 100);
}
$home_text .= "<td><img src='images/stats.gif' width='".$total1."' height='10' /></td>";
$home_text .= "</tr>";
// 2
$home_text .= "<tr class='bg_color2'>";
$home_text .= "<td>".get_caption('Pages')."</td>";
$home_text .= "<td>".$total2."</td>";
if($total_all != 0) {
	$total2 = round($total2 / $total_all * 100);
}
$home_text .= "<td><img src='images/stats.gif' width='".$total2."' height='10' /></td>";
$home_text .= "</tr>";
// 3
$home_text .= "<tr class='bg_color2'>";
$home_text .= "<td>".get_caption('Articles')."</td>";
$home_text .= "<td>".$total3."</td>";
if($total_all != 0) {
	$total3 = round($total3 / $total_all * 100);
}
$home_text .= "<td><img src='images/stats.gif' width='".$total3."' height='10' /></td>";
$home_text .= "</tr>";
// 4
$home_text .= "<tr class='bg_color2'>";
$home_text .= "<td>".get_caption('Languages')."</td>";
$home_text .= "<td>".$total4."</td>";
if($total_all != 0) {
	$total4 = round($total4 / $total_all * 100);
}
$home_text .= "<td><img src='images/stats.gif' width='".$total4."' height='10' /></td>";
$home_text .= "</tr>";
// 5
$home_text .= "<tr class='bg_color2'>";
$home_text .= "<td>".get_caption('Templates')."</td>";
$home_text .= "<td>".$total5."</td>";
if($total_all != 0) {
	$total5 = round($total5 / $total_all * 100);
}
$home_text .= "<td><img src='images/stats.gif' width='".$total5."' height='10' /></td>";
$home_text .= "</tr>";
// 6
$home_text .= "<tr class='bg_color2'>";
$home_text .= "<td>".get_caption('Plugins')."</td>";
$home_text .= "<td>".$total6."</td>";
if($total_all != 0) {
	$total6 = round($total6 / $total_all * 100);
}
$home_text .= "<td><img src='images/stats.gif' width='".$total6."' height='10' /></td>";
$home_text .= "</tr>";
// 7
$home_text .= "<tr class='bg_color2'>";
$home_text .= "<td>".get_caption('Charset')."</td>";
$home_text .= "<td>".$total7."</td>";
if($total_all != 0) {
	$total7 = round($total7 / $total_all * 100);
}
$home_text .= "<td><img src='images/stats.gif' width='".$total7."' height='10' /></td>";
$home_text .= "</tr>";

$home_text .= "</table>";

include("inc_home_stats_user.php");

// Set variables
$tpl->set_var(array(
	"home_title"     => "<h2>".get_caption('Statistics')."</h2>",
	"home_text"      => "<p>".$home_text."</p>",
	"home_stat_user" => "<p>".$home_stat_user."</p>"
	));
?>