<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - admin/inc_settings_tmpl.php -
//
// Copyrights (c) 2006-2008 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

// Forbid direct call
if(!defined('SYS_INDEX')) {
	die("You can't call this file directly!");
}

switch($action)
{
	case 'new':
		if(isset($_POST['send']) && $sys_group_vars['demo'] == 0 && $sys_rights['set_tmpl']['write'] == 1) {
			$_POST['name2'] = validate_text($_POST['name2']);
			
			if($_POST['name'] == "new") {
				if(!mandatory_field($_POST['name2']) && $error == "") { $error = "<p class='error'>".get_caption('ErrorName')."</p>"; }
				
				if(is_dir($path_to_template_files.$_POST['name2'])) {
					if($error == "") {
						$error = "<p class='error'>".get_caption('ErrorFolderExist')."</p>";
					}
				} else {
					$oldperms = fileperms($path_to_template_files);
					@chmod($path_to_template_files,$oldperms | 0222);
					if(is_writeable($path_to_template_files)) {
						if(!mkdir($path_to_template_files.$_POST['name2'],0777)) {
							if($error == "") {
								$error = "<p class='error'>".get_caption('ErrorWritePermission')." (".$path_to_template_files.")</p>";
							}
						} else {
							@chmod($path_to_template_files.$_POST['name2'],0777);
							$_POST['name'] = $_POST['name2'];
						}
					} else {
						if($error == "") {
							$error = "<p class='error'>".get_caption('ErrorWritePermission')." (".$path_to_template_files.")</p>";
						}
					}
					@chmod($path_to_template_files,$oldperms);
				}
			}
			
			if($error == "") {
				$db->query("INSERT INTO ".$tbl_prefix."sys_template (`tid`,`name`,`template`,`css`,`be`)
					VALUES ('','".$_POST['name']."','".$_POST['template']."','".$_POST['css']."','".$_POST['be']."')");
				$db->query("SELECT tid FROM ".$tbl_prefix."sys_template ORDER BY tid DESC LIMIT 1");
				while($db->next_record()):
					$tid = $db->f("tid");
				endwhile;
				load_url("index.php?mode=settings&page=tmpl&action=edit&tid=".$tid);
				//load_url("index.php?mode=settings&page=tmpl");
			}
		}
		
		// Set variables
		$tpl->set_var(array(
			"settings_title"    => "<h2>".get_caption('TemplateAdd')." - ".get_caption('Administration')."</h2>",
			"tab_general"       => get_caption('General'),
			"tmpl_action"       => "index.php?mode=settings&page=tmpl&action=new",
			"tmpl_error"        => $error,
			"tmpl_name"         => get_caption('Name'),
			"tmpl_name_input"   => "<select name='name'><option value='new'>".get_caption('CreateNewDir')."</option>".$ac->get_files($path_to_template_files,$_POST['name'],"")."</select>",
			"tmpl_newname"      => get_caption('DirName'),
			"tmpl_newname_input"=> "<input type='text' name='name2' size='20' maxlength='80' value='".$_POST['name2']."' />",
			//"tmpl_template"     => get_caption('Template'),
			//"tmpl_template_input" => "<input type='text' name='template' size='20' maxlength='250' value='".$_POST['template']."' />",
			//"tmpl_css"          => get_caption('CSS'),
			//"tmpl_css_input"    => "<input type='text' name='css' size='20' maxlength='250' value='".$_POST['css']."' />",
			"tmpl_be"           => get_caption('Backend'),
			"tmpl_be_input"     => "<select name='be'><option value='0'>".get_caption('No')."</option><option value='1'>".get_caption('Yes')."</option></select>",
			"tmpl_button_send"  => "<input class='btn' type='submit' name='send' value='".get_caption('TemplateAdd')."' />"
			));
	break;
	
	case 'edit':
		if(isset($_POST['send']) && $sys_group_vars['demo'] == 0 && $sys_rights['set_tmpl']['write'] == 1) {
			$_POST['name'] = validate_text($_POST['name']);
			$_POST['template'] = validate_text($_POST['template']);
			$_POST['css'] = validate_text($_POST['css']);
			$_POST['be'] = validate_text($_POST['be']);
			$_POST['template_print'] = validate_text($_POST['template_print']);
			$_POST['template_print_css'] = validate_text($_POST['template_print_css']);
			$_POST['template_login'] = validate_text($_POST['template_login']);
			$_POST['template_text'] = validate_text($_POST['template_text']);
			
			if(!mandatory_field($_POST['name']) && $error == "") { $error = "<p class='error'>".get_caption('ErrorName')."</p>"; }
			if(!mandatory_field($_POST['template']) && $error == "") { $error = "<p class='error'>".get_caption('ErrorTemplate')."</p>"; }
			if(!mandatory_field($_POST['css']) && $error == "") { $error = "<p class='error'>".get_caption('ErrorCSS')."</p>"; }
			if(!$_POST['be']) {
				if(!mandatory_field($_POST['template_print']) && $error == "") { $error = "<p class='error'>".get_caption('ErrorTemplatePrint')."</p>"; }
				if(!mandatory_field($_POST['template_print_css']) && $error == "") { $error = "<p class='error'>".get_caption('ErrorTemplatePrintCSS')."</p>"; }
				if(!mandatory_field($_POST['template_login']) && $error == "") { $error = "<p class='error'>".get_caption('ErrorTemplateLogin')."</p>"; }
				if(!mandatory_field($_POST['template_text']) && $error == "") { $error = "<p class='error'>".get_caption('ErrorTemplateText')."</p>"; }
			}
			
			$dir_exist = 1;
			if(!is_dir($path_to_template_files.$_POST['name'])) {
				if($error == "") {
					$error = "<p class='error'>".get_caption('ErrorFolderNotExist')."</p>";
				}
				$dir_exist = 0;
			}
			
			$file2_exist = 1;
			if(!file_exists($path_to_template_files.$_POST['name']."/".$_POST['template'])) {
				if($error == "") {
					$error = "<p class='error'>".get_caption('ErrorTemplateNotExist')."</p>";
				}
				$file2_exist = 0;
			}
			
			$file_exist = 1;
			if(!file_exists($path_to_template_files.$_POST['name']."/".$_POST['css'])) {
				if($error == "") {
					$error = "<p class='error'>".get_caption('ErrorCSSNotExist')."</p>";
				}
				$file_exist = 0;
			}
			
			if(mandatory_field($_POST['name']) && $dir_exist == 1) {
				$db->query("UPDATE ".$tbl_prefix."sys_template SET name = '".$_POST['name']."' WHERE tid = '".$_POST['tid']."' LIMIT 1");
				if($_POST['oldname'] != $_POST['name']) {
					$db->query("UPDATE ".$tbl_prefix."sys_template SET template = '".$_POST['template']."' WHERE tid = '".$_POST['tid']."' LIMIT 1");
					$db->query("UPDATE ".$tbl_prefix."sys_template SET css = '".$_POST['css']."' WHERE tid = '".$_POST['tid']."' LIMIT 1");
				}
			}
			if(mandatory_field($_POST['template']) && $file2_exist == 1) {
				$db->query("UPDATE ".$tbl_prefix."sys_template SET template = '".$_POST['template']."' WHERE tid = '".$_POST['tid']."' LIMIT 1");
			}
			if(mandatory_field($_POST['css']) && $file_exist == 1) {
				$db->query("UPDATE ".$tbl_prefix."sys_template SET css = '".$_POST['css']."' WHERE tid = '".$_POST['tid']."' LIMIT 1");
			}
			
			$db->query("UPDATE ".$tbl_prefix."sys_template SET be = '".$_POST['be']."' WHERE tid = '".$_POST['tid']."' LIMIT 1");

			if(mandatory_field($_POST['template_print'])) {
				$db->query("UPDATE ".$tbl_prefix."sys_template SET template_print = '".$_POST['template_print']."' WHERE tid = '".$_POST['tid']."' LIMIT 1");
			}
			if(mandatory_field($_POST['template_print_css'])) {
				$db->query("UPDATE ".$tbl_prefix."sys_template SET template_print_css = '".$_POST['template_print_css']."' WHERE tid = '".$_POST['tid']."' LIMIT 1");
			}
			if(mandatory_field($_POST['template_login'])) {
				$db->query("UPDATE ".$tbl_prefix."sys_template SET template_login = '".$_POST['template_login']."' WHERE tid = '".$_POST['tid']."' LIMIT 1");
			}
			if(mandatory_field($_POST['template_text'])) {
				$db->query("UPDATE ".$tbl_prefix."sys_template SET template_text = '".$_POST['template_text']."' WHERE tid = '".$_POST['tid']."' LIMIT 1");
			}
			
			if($error == "") {
				load_url("index.php?mode=settings&page=tmpl");
			}
		}
		
		// select record
		if(isset($_POST['tid'])) {
			$_GET['tid'] = $_POST['tid'];
		}
		$db->query("SELECT * FROM ".$tbl_prefix."sys_template WHERE tid = '".$_GET['tid']."' ORDER BY tid LIMIT 1");
		while($db->next_record()):
			$tid = $db->f("tid");
			$name = $db->f("name");
			$template = $db->f("template");
			$css = $db->f("css");
			$be = mark_selected_value($db->f("be"));
			$template_print = $db->f("template_print");
			$template_print_css = $db->f("template_print_css");
			$template_login = $db->f("template_login");
			$template_text = $db->f("template_text");
		endwhile;
		
		// Set variables
		$tpl->set_var(array(
			"settings_title"    => "<h2>".get_caption('TemplateEdit')." - ".get_caption('Administration')."</h2>",
			"tab_general"       => get_caption('General'),
			"tmpl_action"       => "index.php?mode=settings&page=tmpl&action=edit",
			"tmpl_error"        => $error,
			"tmpl_name"         => get_caption('Name'),
			"tmpl_name_input"   => "<select name='name' disabled>".$ac->get_files($path_to_template_files,$name,"")."</select><input type='hidden' name='name' value='".$name."' />",
			"tmpl_template"     => get_caption('Template'),
			"tmpl_template_input" => "<select name='template'><option value=''></option>".$ac->get_files($path_to_template_files.$name,$template,".htm")."</select>",
			"tmpl_template_edit"  => "<a href='index.php?mode=settings&page=editor&fileurl=templates/".$name."/".$template."' class='edit'><img src='images/icon_edit.gif' border='0' width='16' height='16' alt='".get_caption('EditText')."' /></a>",
			"tmpl_css"          => get_caption('CSS'),
			"tmpl_css_input"    => "<select name='css'><option value=''></option>".$ac->get_files($path_to_template_files.$name,$css,".css")."</select>",
			"tmpl_css_edit"     => "<a href='index.php?mode=settings&page=editor&fileurl=templates/".$name."/".$css."' class='edit'><img src='images/icon_edit.gif' border='0' width='16' height='16' alt='".get_caption('EditText')."' /></a>",
			"tmpl_be"           => get_caption('Backend'),
			"tmpl_be_input"     => "<select name='be'><option value='0' ".$be['1'].">".get_caption('No')."</option><option value='1' ".$be['2'].">".get_caption('Yes')."</option></select>",
			"tmpl_print"        => get_caption('TmplPrint'),
			"tmpl_print_input"  => "<select name='template_print'><option value=''></option>".$ac->get_files($path_to_template_files.$name,$template_print,".html")."</select>",
			"tmpl_print_edit"   => "<a href='index.php?mode=settings&page=editor&fileurl=templates/".$name."/".$template_print."' class='edit'><img src='images/icon_edit.gif' border='0' width='16' height='16' alt='".get_caption('EditText')."' /></a>",
			"tmpl_printcss"       => get_caption('TmplPrintCSS'),
			"tmpl_printcss_input" => "<select name='template_print_css'><option value=''></option>".$ac->get_files($path_to_template_files.$name,$template_print_css,".css")."</select>",
			"tmpl_printcss_edit"  => "<a href='index.php?mode=settings&page=editor&fileurl=templates/".$name."/".$template_print_css."' class='edit'><img src='images/icon_edit.gif' border='0' width='16' height='16' alt='".get_caption('EditText')."' /></a>",
			"tmpl_login"        => get_caption('TmplLogin'),
			"tmpl_login_input"  => "<select name='template_login'><option value=''></option>".$ac->get_files($path_to_template_files.$name,$template_login,".html")."</select>",
			"tmpl_login_edit"   => "<a href='index.php?mode=settings&page=editor&fileurl=templates/".$name."/".$template_login."' class='edit'><img src='images/icon_edit.gif' border='0' width='16' height='16' alt='".get_caption('EditText')."' /></a>",
			"tmpl_text"        => get_caption('TmplText'),
			"tmpl_text_input"  => "<select name='template_text'><option value=''></option>".$ac->get_files($path_to_template_files.$name,$template_text,".html")."</select>",
			"tmpl_text_edit"   => "<a href='index.php?mode=settings&page=editor&fileurl=templates/".$name."/".$template_text."' class='edit'><img src='images/icon_edit.gif' border='0' width='16' height='16' alt='".get_caption('EditText')."' /></a>",
			"tmpl_tid"          => "<input type='hidden' name='tid' value='".$tid."' />",
			"tmpl_button_send"  => "<input class='btn' type='submit' name='send' value='".get_caption('SaveChanges')."' />"
			));
	break;
	
	case 'del':
		if(isset($_POST['send']) && $sys_group_vars['demo'] == 0 && $sys_rights['set_tmpl']['delete'] == 1) {
			$db->query("DELETE FROM ".$tbl_prefix."sys_template WHERE tid = '".$_POST['tid']."' LIMIT 1");
			load_url("index.php?mode=settings&page=tmpl");
		}
		
		// select record
		if(isset($_POST['tid'])) {
			$_GET['tid'] = $_POST['tid'];
		}
		$db->query("SELECT tid,name FROM ".$tbl_prefix."sys_template WHERE tid = '".$_GET['tid']."' ORDER BY tid LIMIT 1");
		while($db->next_record()):
			$tid = $db->f("tid");
			$name = $db->f("name");
		endwhile;
		
		// Set variables
		$tpl->set_var(array(
			"settings_title"    => "<h2>".get_caption('TemplateDelete')." - ".get_caption('Administration')."</h2>",
			"tmpl_action"       => "index.php?mode=settings&page=tmpl&action=del",
			"tmpl_question"     => "<p>".get_caption('DeleteQuestion')."</p>",
			"tmpl_name"         => "<p class='bold'>".$name."</p>",
			"tmpl_tid"          => "<input type='hidden' name='tid' value='".$tid."' />",
			"tmpl_button_send"  => "<input class='btn' type='submit' name='send' value='".get_caption('TemplateDelete')."' />"
			));
	break;
	
	default:
		// Create template overview
		
		// Headline
		$settings_tmpl .= "<table><tr class='bg_color3'>"
			."<td><p class='bold'>".get_caption('Name')."</p></td>"
			."<td><p class='bold'>".get_caption('Template')."</p></td>"
			."<td><p class='bold'>".get_caption('CSS')."</p></td>"
			."<td><p class='bold'>".get_caption('Backend')."</p></td>"
			."<td><p class='bold'>".get_caption('Action')."</p></td>"
			."</tr>";
			
		// Lines
		$db->query("SELECT * FROM ".$tbl_prefix."sys_template ORDER BY tid");
		while($db->next_record()):
			$settings_tmpl .= "<tr class='bg_color2'>"
				."<td>".$db->f("name")."</td>"
				."<td><a href='index.php?mode=settings&page=editor&fileurl=templates/".$db->f("name")."/".$db->f("template")."'>".$db->f("template")."</a></td>"
				."<td><a href='index.php?mode=settings&page=editor&fileurl=templates/".$db->f("name")."/".$db->f("css")."'>".$db->f("css")."</a></td>"
				."<td>".translate_yesno($db->f("be"),get_caption('Yes'),get_caption('No'))."</td>"
				."<td>"
				.$ac->create_link("index.php?mode=settings&page=tmpl&action=edit&tid=",$db->f("tid"),get_caption('EditText'),"edit",get_caption('Edit'))
				.$ac->create_link("index.php?mode=settings&page=tmpl&action=del&tid=",$db->f("tid"),get_caption('Del'),"delete",get_caption('Delete'))
				."</td>"
				."</tr>";
		endwhile;
		$settings_tmpl .= "</table>";

		// Set variables
		$tpl->set_var(array(
			"settings_title"    => "<h2>".get_caption('Templates')." - ".get_caption('Administration')."</h2>",
			"settings_tmpl"     => $settings_tmpl,
			"settings_tmpl_new" => "<p><a class='edit' href='index.php?mode=settings&page=tmpl&action=new' title='".get_caption('TemplateAdd')."'><img src='images/icon_add.gif' alt='".get_caption('TemplateAdd')."' border='0' width='16' height='16' /></a></p>"
			));
	break;
}
?>