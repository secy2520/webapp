<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - admin/inc_settings_editor.php -
//
// Copyrights (c) 2006-2008 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

// Forbid direct call
if(!defined('SYS_INDEX')) {
	die("You can't call this file directly!");
}

// text editor
$backlink = $_SERVER["HTTP_REFERER"];

if(isset($_POST['send']) && $sys_group_vars['demo'] == 0 && $sys_rights['set_tmpl']['write'] == 1) {
	
	$newfile = str_replace("\\","",$_POST['file']);
	$fileurl = $_POST['fileurl'];
	$backlink = $_POST['backlink'];
	
	//write $newfile to file
	if(file_exists($fileurl)) {
		$oldperms = fileperms($fileurl);
		@chmod($fileurl,$oldperms | 0222);
		if(is_writeable($fileurl)==false) {
			$error = "<p class='error'>".get_caption('ErrorWritePermissionFile')."</p>";
		} else {
			$wf = fopen($fileurl,"w");
			fwrite($wf,$newfile);
			fclose($wf);
		}
		@chmod($fileurl,$oldperms);
	}
	
	// redirect back
	if($error == "") {
		load_url($_POST['backlink']);
	}
}

// show file
if(isset($_POST["fileurl"])) {
	$fileurl = $_POST["fileurl"];
}
if(isset($_GET["fileurl"])) {
	$fileurl = "../".$_GET["fileurl"];
}

if(file_exists($fileurl)) {
	$filelength = filesize($fileurl);
	$readfile = fopen($fileurl,"r");
	$file = fread($readfile,$filelength);
	fclose($readfile);
}

if(is_writeable($fileurl)==false) {
	$error = "<p class='error'>".get_caption('ErrorWritePermissionFile')."</p>";
}

// Set variables
$tpl->set_var(array(
	"settings_title"     => "<h2>".get_caption('EditorEdit')." - ".get_caption('Administration')."</h2>",
	"editor_action"      => "index.php?mode=settings&page=editor",
	"editor_error"       => $error,
	"editor_file"        => $fileurl,
	"editor_file_input"  => "<textarea name='file' cols='80' rows='20'>".$file."</textarea>",
	"editor_fileurl"     => "<input type='hidden' name='fileurl' value='".$fileurl."' />",
	"editor_backlink"    => "<input type='hidden' name='backlink' value='".$backlink."' />",
	"editor_button_send" => "<input class='btn' type='submit' name='send' value='".get_caption('SaveChanges')."' />"
	));
?>