<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - admin/inc_content_levels.php -
//
// Copyrights (c) 2006-2008 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

// Forbid direct call
if(!defined('SYS_INDEX')) {
	die("You can't call this file directly!");
}

if(isset($_GET['action']) && $sys_group_vars['demo'] == 0 && $sys_rights['content_levels']['write'] == 1) {
	// init tree class
	$tree = new tree($s_level_no);
	
	// save changes in database
	if(!CheckInteger($_GET['eid'])) {
		unset($_GET['action']);
	}
	switch($_GET['action'])
	{
		case 'move_left':
			$tree->move_left($db,$_GET['eid']);
		break;
		
		case 'move_right':
			$tree->move_right($db,$_GET['eid']);
		break;
		
		case 'move_up':
			$tree->move_up($db,$_GET['eid']);
		break;
		
		case 'move_down':
			$tree->move_down($db,$_GET['eid']);
		break;
	}
	// header url
	load_url("index.php?mode=content&page=levels");
}

// Create explorer overview
// Headline
$content_expl = "<table><tr class='bg_color3'>"
	."<td><p class='bold'>".get_caption('EntryID')."</p></td>"
	."<td><p class='bold'>".get_caption('Name')."</p></td>"
	."<td><p class='bold'>".get_caption('PreID')."</p></td>"
	."<td><p class='bold'>".get_caption('Sorting')."</p></td>"
	."<td><p class='bold'>".get_caption('Action')."</p></td>"
	."</tr>";

if(empty($_SESSION["filter_content"])) {
	$_SESSION["filter_content"] = "%";
}

function get_entries($content_expl,$which=0)
{
	global $tbl_prefix,$sys_vars,$expl_structure,$ac;
	// Init libraries
	$db = new DB_Tpl();
	
	$db->query("SELECT * FROM ".$tbl_prefix."sys_explorer WHERE config_id LIKE '".$_SESSION["filter_content"]."' && preid = '".$which."' ORDER BY preid,sorting");
	while($db->next_record()):
		$indent = $db->f("level") * 10 - 10;
		$bold = "";
		if($db->f("level") == 1) {
			$bold = " class='bold'";
		}
		$content_expl .= "<tr class='bg_color2'>"
			."<td>".$db->f("eid")."</td>"
			."<td><p style='text-indent: ".$indent."px;'><span".$bold.">".$db->f("name")."</span></p></td>"
			."<td>".$db->f("preid")."</td>"
			."<td>".$db->f("sorting")."</td>"
			."<td>"
			.$ac->create_link("index.php?mode=content&page=levels&action=move_left&eid=",$db->f("eid"),get_caption('MoveLeft'),"edit",get_caption('IcoLeft'))
			.$ac->create_link("index.php?mode=content&page=levels&action=move_right&eid=",$db->f("eid"),get_caption('MoveRight'),"edit",get_caption('IcoRight'))
			.$ac->create_link("index.php?mode=content&page=levels&action=move_up&eid=",$db->f("eid"),get_caption('MoveUp'),"edit",get_caption('IcoUp'))
			.$ac->create_link("index.php?mode=content&page=levels&action=move_down&eid=",$db->f("eid"),get_caption('MoveDown'),"edit",get_caption('IcoDown'))
			."</td>"
			."</tr>";
		$content_expl = get_entries($content_expl,$db->f("eid"));
	endwhile;
	
	return($content_expl);
}

$content_expl = get_entries($content_expl);
$content_expl .= "</table>";

// Set variables
$tpl->set_var(array(
	"content_title"    => "<h2>".get_caption('Levels')." - ".get_caption('Contents')."</h2>",
	"expl_overview"    => $content_expl
	));

// Parse template with variables
$tpl->parse("content_handle", "content", true);
?>