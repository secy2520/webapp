<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - admin/inc_settings_plugins.php -
//
// Copyrights (c) 2006-2008 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

// Forbid direct call
if(!defined('SYS_INDEX')) {
	die("You can't call this file directly!");
}

// Plugin class required
require_once("class/class_plugins.php");
$pm = new plugins();

switch($action)
{
	case 'new':
		// setup new plugin
		switch($_POST['post'])
		{
			case '2': // check install.php and insert into db
				$error = $pm->install($db,$_POST['folder']);
				
				if($error == "") {
					load_url("index.php?mode=settings&page=plugins");
				}
									
				// Set variables
				$tpl->set_var(array(
					"settings_title"      => "<h2>".get_caption('PluginAdd')." - ".get_caption('Administration')."</h2>",
					"plugins_text"        => $error
					));
			break;
			
			case '1': // select name and confirm install
				if($sys_group_vars['demo'] == 1 || $sys_rights['set_plugins']['write'] == 0) {
					load_url("index.php?mode=settings&page=plugins");
				}
				
				if($pm->install_file_exist($_POST["folder"]."/") == 0) {
					load_url("index.php?mode=settings&page=plugins");
				}
				
				$pm->set_install_values($_POST["folder"]."/");
				if($pm->plugin_exist($db) == 0) {
					$plugin_text = "<form method='post'>"
						."<table>"
						."<tr class='bg_color2'><td>".get_caption('Dir')."</td><td><input type='text' name='dir' size='30' value='/plugins/".$_POST['folder']."' disabled /></td></tr>"
						."<tr class='bg_color2'><td>".get_caption('Name')."</td><td><input type='text' name='name' size='20' value='".$_POST['folder']."' disabled /></td></tr>"
						."<tr><td><input type='hidden' name='post' value='2' /></td><td><input type='hidden' name='folder' value='".$_POST['folder']."' /></td></tr>"
						."</table>"
						."<input class='btn' type='submit' name='send' value='Install' />"
						."</form>";
				} else {
					$plugin_text = "<p class='error'>".get_caption('ErrorPluginExist')." ".$tbl_prefix."sys_plugin</p>";
				}
				
				// Set variables
				$tpl->set_var(array(
					"settings_title"      => "<h2>".get_caption('PluginAdd')." - ".get_caption('Administration')."</h2>",
					"plugins_text"        => $plugin_text
					));
			break;
			
			default:
				$folder = opendir($pm->plugin_dir);
				$plugin_folders = "<table>";
				$plugin_folders .= "<tr class='bg_color3'>"
					."<td width='200'><p class='bold'>".get_caption('Name')."</p></td>"
					."<td><p class='bold'>".get_caption('Version')."</p></td>"
					."<td><p class='bold'>".get_caption('Path')."</p></td>"
					."<td><p class='bold'>".get_caption('Action')."</p></td></tr>";
				
				$plugin_array = array();
				while($dir = readdir($folder))
				{
					if($dir != "." && $dir != ".."  && is_dir($pm->plugin_dir.$dir)) // only directories
					{
						unset($pm->plugin_vars);
						if($pm->install_file_exist($dir."/")) {
							$pm->set_install_values($dir."/");
							if($pm->plugin_exist($db) == 0) {
								$plugin_array[$dir] = $pm->plugin_vars['version'];
							}
						}
					}
				}
				closedir($folder);
				
				ksort($plugin_array);
				foreach($plugin_array as $key => $val) {
					$plugin_folders .= "<tr class='bg_color2'><td>".$key."</td>"
								."<td>".$val."</td>"
								."<td>/plugins/".$key."</td>"
								."<td><form method='post'><input type='hidden' name='folder' value='".$key."' />"
								."<input type='hidden' name='post' value='1' /><input class='btn' type='submit' name='send' value='".get_caption('Install')."' />"
								."</form></td></tr>";
				}
				$plugin_folders .= "</table>";
				
				// Set variables
				$tpl->set_var(array(
					"settings_title"      => "<h2>".get_caption('PluginAdd')." - ".get_caption('Administration')."</h2>",
					"plugins_text"        => $plugin_folders
					));
			break;
		}
	break;
	
	case 'edit':
		if(isset($_POST['send']) && $sys_group_vars['demo'] == 0 && $sys_rights['set_plugins']['write'] == 1) {
			$db->query("UPDATE ".$tbl_prefix."sys_plugin SET status = '".$_POST['status']."' WHERE pid = '".$_POST['pid']."' LIMIT 1");
			load_url("index.php?mode=settings&page=plugins");
		}
		
		// select record
		if(isset($_POST['pid'])) {
			$_GET['pid'] = $_POST['pid'];
		}
		$db->query("SELECT pid,name,status FROM ".$tbl_prefix."sys_plugin WHERE pid = '".$_GET['pid']."' ORDER BY pid LIMIT 1");
		while($db->next_record()):
			$pid = $db->f("pid");
			$name = $db->f("name");
			$status = mark_selected_value($db->f("status"));
		endwhile;
		
		// Set variables
		$tpl->set_var(array(
			"settings_title"    => "<h2>".get_caption('PluginEdit')." - ".get_caption('Administration')."</h2>",
			"plugins_action"    => "index.php?mode=settings&page=plugins&action=edit",
			"plugins_name"      => "<p class='bold'>".$name."</p>",
			"plugins_status"    => get_caption('Status'),
			"plugins_status_input" => "<select name='status'><option value='0' ".$status['1'].">".get_caption('Inactive')."</option><option value='1' ".$status['2'].">".get_caption('Active')."</option></select>",
			"plugins_pid"       => "<input type='hidden' name='pid' value='".$pid."' />",
			"plugins_button_send" => "<input class='btn' type='submit' name='send' value='".get_caption('SaveChanges')."' />"
			));
	break;
	
	case 'del':
		if(isset($_POST['send']) && $sys_group_vars['demo'] == 0 && $sys_rights['set_plugins']['delete'] == 1) {
			$db->query("SELECT install_path FROM ".$tbl_prefix."sys_plugin WHERE pid = '".$_POST['pid']."' LIMIT 1");
			while($db->next_record()):
				$plugin_vars['folder'] = $db->f("install_path");
			endwhile;
			
			$pm->uninstall($db,$plugin_vars['folder'],$_POST['pid']);
	
			load_url("index.php?mode=settings&page=plugins");
		}
		
		// select record
		if(isset($_POST['pid'])) {
			$_GET['pid'] = $_POST['pid'];
		}
		$db->query("SELECT pid,name FROM ".$tbl_prefix."sys_plugin WHERE pid = '".$_GET['pid']."' ORDER BY pid LIMIT 1");
		while($db->next_record()):
			$pid = $db->f("pid");
			$name = $db->f("name");
		endwhile;
		
		// Set variables
		$tpl->set_var(array(
			"settings_title"    => "<h2>".get_caption('PluginDelete')." - ".get_caption('Administration')."</h2>",
			"plugins_action"    => "index.php?mode=settings&page=plugins&action=del",
			"plugins_question"  => "<p>".get_caption('DeleteQuestion')."</p>",
			"plugins_name"      => "<p class='bold'>".$name."</p>",
			"plugins_pid"       => "<input type='hidden' name='pid' value='".$pid."' />",
			"plugins_button_send" => "<input class='btn' type='submit' name='send' value='".get_caption('PluginDelete')."' />"
			));
	break;
	
	default:
		// Create plugins overview
		
		// Headline
		$settings_plugins .= "<table><tr class='bg_color3'>"
			."<td><p class='bold'>".get_caption('PluginID')."</p></td>"
			."<td width='200'><p class='bold'>".get_caption('Name')."</p></td>"
			."<td><p class='bold'>".get_caption('Path')."</p></td>"
			."<td><p class='bold'>".get_caption('Type')."</p></td>"
			."<td><p class='bold'>".get_caption('Version')."</p></td>"
			."<td><p class='bold'>".get_caption('Status')."</p></td>"
			."<td><p class='bold'>".get_caption('Action')."</p></td>"
			."</tr>";
			
		// Lines
		$db->query("SELECT * FROM ".$tbl_prefix."sys_plugin ORDER BY pid");
		while($db->next_record()):
			if($db->f("admin_file") != "" && file_exists("../plugins/".$db->f("install_path").$db->f("admin_file"))) {
				$plugin_name = "<a href='index.php?mode=plugins&pluginID=".$db->f("pid")."'>".$db->f("name")."</a>";
			} else {
				$plugin_name = $db->f("name");
			}
			$settings_plugins .= "<tr class='bg_color2'>"
				."<td>".$db->f("pid")."</td>"
				."<td>".$plugin_name."</td>"
				."<td>/plugins/".$db->f("install_path")."</td>"
				."<td>".translate_yesno($db->f("plugin_type"),"Content","Module")."</td>"
				."<td>".$db->f("plugin_version")."</td>"
				."<td>".translate_yesno($db->f("status"),get_caption('Active'),get_caption('Inactive'))."</td>"
				."<td>"
				.$ac->create_link("index.php?mode=settings&page=plugins&action=edit&pid=",$db->f("pid"),get_caption('EditText'),"edit",get_caption('Edit'))
				.$ac->create_link("index.php?mode=settings&page=plugins&action=del&pid=",$db->f("pid"),get_caption('Del'),"delete",get_caption('Delete'))
				."</td>"
				."</tr>";
		endwhile;
		$settings_plugins .= "</table>";

		// Set variables
		$tpl->set_var(array(
			"settings_title"       => "<h2>".get_caption('Plugins')." - ".get_caption('Administration')."</h2>",
			"settings_plugins"     => $settings_plugins,
			"settings_plugins_new" => "<p><a class='edit' href='index.php?mode=settings&page=plugins&action=new' title='".get_caption('PluginAdd')."'><img src='images/icon_add.gif' alt='".get_caption('PluginAdd')."' border='0' width='16' height='16' /></a></p>"
		));
	break;
}
?>