<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - admin/inc_settings_lang.php -
//
// Copyrights (c) 2006-2008 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

// Forbid direct call
if(!defined('SYS_INDEX')) {
	die("You can't call this file directly!");
}

switch($action)
{
	case 'new':
		if(isset($_POST['send']) && $sys_group_vars['demo'] == 0 && $sys_rights['set_lang']['write'] == 1) {
			$_POST['name'] = validate_text($_POST['name']);
			$_POST['flag'] = validate_text($_POST['flag']);
			$_POST['filename'] = validate_text($_POST['filename']);
			$_POST['filename2'] = validate_text($_POST['filename2']);
			$_POST['date'] = validate_text($_POST['date']);
			$_POST['datetime'] = validate_text($_POST['datetime']);
			$_POST['token'] = validate_text($_POST['token']);
			
			if(!mandatory_field($_POST['name']) && $error == "") { $error = "<p class='error'>".get_caption('ErrorName')."</p>"; }
			//if(!mandatory_field($_POST['flag']) && $error == "") { $error = "<p class='error'>".get_caption('ErrorFlag')."</p>"; }
			if($_POST['filename'] == "new") {
				if(!mandatory_field($_POST['filename2']) && $error == "") { $error = "<p class='error'>".get_caption('ErrorFilename')."</p>"; }
								
				if(file_exists($path_to_lang_files.$_POST['filename2'])) {
					if($error == "") {
						$error = "<p class='error'>".get_caption('ErrorFileExist')."</p>";
					}
				} else {
					$oldperms = fileperms($path_to_lang_files);
					@chmod($path_to_lang_files,$oldperms | 0222);
					if(is_writeable($path_to_lang_files)) {
						// create new empty file
						$f = fopen($path_to_lang_files.$_POST['filename2'],"w+");
						fwrite($f,"<?php\n?>");
						fclose($f);
						@chmod($path_to_lang_files.$_POST['filename2'],0666);
						$_POST['filename'] = $_POST['filename2'];
					} else {
						if($error == "") {
							$error = "<p class='error'>".get_caption('ErrorWritePermission')." (".$path_to_lang_files.")</p>";
						}
					}
					@chmod($path_to_lang_files,$oldperms);
				}
			}
			
			if($error == "") {
				$db->query("INSERT INTO ".$tbl_prefix."sys_lang VALUES ('','".$_POST['name']."','".$_POST['flag']."','".$_POST['filename']."','".$_POST['date']."','".$_POST['datetime']."','".$_POST['token']."')");
				load_url("index.php?mode=settings&page=lang");
			}
		}
		
		// Set variables
		$tpl->set_var(array(
			"settings_title"    => "<h2>".get_caption('LanguageAdd')." - ".get_caption('Administration')."</h2>",
			"tab_general"       => get_caption('General'),
			"lang_action"       => "index.php?mode=settings&page=lang&action=new",
			"lang_error"        => $error,
			"lang_name"         => get_caption('Name'),
			"lang_name_input"   => "<input type='text' name='name' size='30' maxlength='250' value='".$_POST['name']."' />",
			"lang_flag"         => get_caption('Flag'),
			"lang_flag_input"   => "<select name='flag'><option value=''></option>".$ac->get_files($path_to_image_folder,$_POST['flag'],".")."</select>",
			"lang_filename"     => get_caption('File'),
			"lang_filename_input" => "<select name='filename'><option value='new'>".get_caption('CreateNewFile')."</option>".$ac->get_files($path_to_lang_files,$_POST['filename'],'.php')."</select> ".get_caption('FileName')." <input type='text' name='filename2' size='20' maxlength='80' value='".$_POST['filename2']."' />",
			"lang_date"         => get_caption('DateFormula'),
			"lang_date_input"   => "<input type='text' name='date' size='10' maxlength='20' value='".$_POST['date']."' />",
			"lang_datetime"     => get_caption('DateTimeFormula'),
			"lang_datetime_input" => "<input type='text' name='datetime' size='10' maxlength='20' value='".$_POST['datetime']."' />",
			"lang_token"        => get_caption('Token'),
			"lang_token_input"  => "<input type='text' name='token' size='5' maxlength='3' value='".$_POST['token']."' />",
			"lang_button_send"  => "<input class='btn' type='submit' name='send' value='".get_caption('LanguageAdd')."' />"
			));
	break;
	
	case 'edit':
		if(isset($_POST['send']) && $sys_group_vars['demo'] == 0 && $sys_rights['set_lang']['write'] == 1) {
			$_POST['name'] = validate_text($_POST['name']);
			$_POST['flag'] = validate_text($_POST['flag']);
			$_POST['filename'] = validate_text($_POST['filename']);
			$_POST['date'] = validate_text($_POST['date']);
			$_POST['datetime'] = validate_text($_POST['datetime']);
			$_POST['token'] = validate_text($_POST['token']);
			
			if(!mandatory_field($_POST['name']) && $error == "") { $error = "<p class='error'>".get_caption('ErrorName')."</p>"; }
			if(!mandatory_field($_POST['flag']) && $error == "") { $error = "<p class='error'>".get_caption('ErrorFlag')."</p>"; }
			if(!mandatory_field($_POST['filename']) && $error == "") { $error = "<p class='error'>".get_caption('ErrorFilename')."</p>"; }
			$file_exist = 1;
			if(!file_exists($path_to_lang_files.$_POST['filename'])) {
				if($error == "") {
					$error = "<p class='error'>".get_caption('ErrorFileNotExist')."</p>";
				}
				$file_exist = 0;
			}
			
			if(mandatory_field($_POST['name'])) {
				$db->query("UPDATE ".$tbl_prefix."sys_lang SET name = '".$_POST['name']."' WHERE lid = '".$_POST['lid']."' LIMIT 1");
			}
			if(mandatory_field($_POST['flag'])) {
				$db->query("UPDATE ".$tbl_prefix."sys_lang SET flag = '".$_POST['flag']."' WHERE lid = '".$_POST['lid']."' LIMIT 1");
			}
			if(mandatory_field($_POST['filename']) && $file_exist == 1) {
				$db->query("UPDATE ".$tbl_prefix."sys_lang SET filename = '".$_POST['filename']."' WHERE lid = '".$_POST['lid']."' LIMIT 1");
			}
			
			$db->query("UPDATE ".$tbl_prefix."sys_lang SET date = '".$_POST['date']."' WHERE lid = '".$_POST['lid']."' LIMIT 1");
			$db->query("UPDATE ".$tbl_prefix."sys_lang SET datetime = '".$_POST['datetime']."' WHERE lid = '".$_POST['lid']."' LIMIT 1");
			$db->query("UPDATE ".$tbl_prefix."sys_lang SET token = '".$_POST['token']."' WHERE lid = '".$_POST['lid']."' LIMIT 1");
			
			if($error == "") {
				load_url("index.php?mode=settings&page=lang");
			}
		}
		
		// select record
		if(isset($_POST['lid'])) {
			$_GET['lid'] = $_POST['lid'];
		}
		$db->query("SELECT * FROM ".$tbl_prefix."sys_lang WHERE lid = '".$_GET['lid']."' ORDER BY lid LIMIT 1");
		while($db->next_record()):
			$lid = $db->f("lid");
			$name = $db->f("name");
			$flag = $db->f("flag");
			$filename = $db->f("filename");
			$date = $db->f("date");
			$datetime = $db->f("datetime");
			$token = $db->f("token");
		endwhile;
		
		// Set variables
		$tpl->set_var(array(
			"settings_title"    => "<h2>".get_caption('LanguageEdit')." - ".get_caption('Administration')."</h2>",
			"tab_general"       => get_caption('General'),
			"lang_action"       => "index.php?mode=settings&page=lang&action=edit",
			"lang_error"        => $error,
			"lang_name"         => get_caption('Name'),
			"lang_name_input"   => "<input type='text' name='name' size='30' maxlength='250' value='".$name."' />",
			"lang_flag"         => get_caption('Flag'),
			"lang_flag_input"   => "<select name='flag'><option value=''></option>".$ac->get_files($path_to_image_folder,$flag,".")."</select>",
			"lang_filename"     => get_caption('File'),
			"lang_filename_input" => "<select name='filename'>".$ac->get_files($path_to_lang_files,$filename,'.php')."</select>",
			"lang_date"         => get_caption('DateFormula'),
			"lang_date_input"   => "<input type='text' name='date' size='10' maxlength='20' value='".$date."' />",
			"lang_datetime"     => get_caption('DateTimeFormula'),
			"lang_datetime_input" => "<input type='text' name='datetime' size='10' maxlength='20' value='".$datetime."' />",
			"lang_token"        => get_caption('Token'),
			"lang_token_input"  => "<input type='text' name='token' size='5' maxlength='3' value='".$token."' />",
			"lang_lid"          => "<input type='hidden' name='lid' value='".$lid."' />",
			"lang_button_send"  => "<input class='btn' type='submit' name='send' value='".get_caption('SaveChanges')."' />"
			));
	break;
	
	case 'del':
		if(isset($_POST['send']) && $sys_group_vars['demo'] == 0 && $sys_rights['set_lang']['delete'] == 1) {
			$db->query("DELETE FROM ".$tbl_prefix."sys_lang WHERE lid = '".$_POST['lid']."' LIMIT 1");
			load_url("index.php?mode=settings&page=lang");
		}
		
		// select record
		if(isset($_POST['lid'])) {
			$_GET['lid'] = $_POST['lid'];
		}
		$db->query("SELECT lid,name FROM ".$tbl_prefix."sys_lang WHERE lid = '".$_GET['lid']."' ORDER BY lid LIMIT 1");
		while($db->next_record()):
			$lid = $db->f("lid");
			$name = $db->f("name");
		endwhile;
		
		// Set variables
		$tpl->set_var(array(
			"settings_title"    => "<h2>".get_caption('LanguageDelete')." - ".get_caption('Administration')."</h2>",
			"lang_action"       => "index.php?mode=settings&page=lang&action=del",
			"lang_question"     => "<p>".get_caption('DeleteQuestion')."</p>",
			"lang_name"         => "<p class='bold'>".$name."</p>",
			"lang_lid"          => "<input type='hidden' name='lid' value='".$lid."' />",
			"lang_button_send"  => "<input class='btn' type='submit' name='send' value='".get_caption('LanguageDelete')."' />"
			));
	break;
	
	default:
		// Create lang overview
		
		// Headline
		$settings_lang .= "<table><tr class='bg_color3'>"
			."<td><p class='bold'>".get_caption('Name')."</p></td>"
			."<td><p class='bold'>".get_caption('Flag')."</p></td>"
			."<td><p class='bold'>".get_caption('File')."</p></td>"
			."<td><p class='bold'>".get_caption('DateFormula')."</p></td>"
			."<td><p class='bold'>".get_caption('Token')."</p></td>"
			."<td><p class='bold'>".get_caption('Action')."</p></td>"
			."</tr>";
			
		// Lines
		$db->query("SELECT * FROM ".$tbl_prefix."sys_lang ORDER BY lid");
		while($db->next_record()):
			$settings_lang .= "<tr class='bg_color2'>"
				."<td>".$db->f("name")."</td>"
				."<td>".$db->f("flag")."</td>"
				."<td><a href='index.php?mode=settings&page=editor&fileurl=languages/".$db->f("filename")."'>".$db->f("filename")."</a></td>"
				."<td>".$db->f("date")."</td>"
				."<td>".$db->f("token")."</td>"
				."<td>"
				.$ac->create_link("index.php?mode=settings&page=lang&action=edit&lid=",$db->f("lid"),get_caption('EditText'),"edit",get_caption('Edit'))
				.$ac->create_link("index.php?mode=settings&page=lang&action=del&lid=",$db->f("lid"),get_caption('Del'),"delete",get_caption('Delete'))
				."</td>"
				."</tr>";
		endwhile;
		$settings_lang .= "</table>";
	
		// Set variables
		$tpl->set_var(array(
			"settings_title"    => "<h2>".get_caption('Languages')." - ".get_caption('Administration')."</h2>",
			"settings_lang"     => $settings_lang,
			"settings_lang_new" => "<p><a class='edit' href='index.php?mode=settings&page=lang&action=new' title='".get_caption('LanguageAdd')."'><img src='images/icon_add.gif' alt='".get_caption('LanguageAdd')."' border='0' width='16' height='16' /></a></p>"
			));
	break;
}
?>