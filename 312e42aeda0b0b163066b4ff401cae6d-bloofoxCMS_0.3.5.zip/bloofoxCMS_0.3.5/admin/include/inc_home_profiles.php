<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - admin/inc_home_profiles.php -
//
// Copyrights (c) 2006-2008 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

// Forbid direct call
if(!defined('SYS_INDEX')) {
	die("You can't call this file directly!");
}

// Get user profile data
$db->query("SELECT * FROM ".$tbl_prefix."sys_profile WHERE user_id = '".$_GET['user_id']."' ORDER BY user_id LIMIT 1");
while($db->next_record()):
	$username = $ac->get_username($_GET['user_id']);
	$firstname = $db->f("firstname");
	$lastname = $db->f("lastname");
	$address1 = $db->f("address1");
	$address2 = $db->f("address2");
	$city = $db->f("city");
	$zip_code = $db->f("zip_code");
	if($db->f('show_email') == 1) {
		$email = $db->f("email");
	}
	$birthday = $db->f("birthday");
	$gender = translate_yesno($db->f("gender"),get_caption('GenderFemale'),get_caption('GenderMale'));
	$picture = $db->f("picture");
endwhile;
		
if(!empty($birthday)) {
	$birthday = date("d.m.Y",$birthday);
}
if(empty($picture)) {
	$picture = "standard.gif";
}

// Set variables
$tpl->set_var(array(
	"home_title"           => "<h2>".$username." - ".get_caption('PrivateProfile')."</h2>",
	"home_contact"         => get_caption('ContactInfo'),
	"home_firstname_title" => get_caption('Firstname'),
	"home_firstname"       => $firstname,
	"home_lastname_title"  => get_caption('Lastname'),
	"home_lastname"        => $lastname,
	"home_address1_title"  => get_caption('Address1'),
	"home_address1"        => $address1,
	"home_address2_title"  => get_caption('Address2'),
	"home_address2"        => $address2,
	"home_city_title"      => get_caption('City'),
	"home_city"            => $city,
	"home_zip_code_title"  => get_caption('ZipCode'),
	"home_zip_code"        => $zip_code,
	"home_email_title"     => get_caption('Email'),
	"home_email"           => $email,
	"home_birthday_title"  => get_caption('Birthday'),
	"home_birthday"        => $birthday,
	"home_gender_title"    => get_caption('Gender'),
	"home_gender"          => $gender,
	"home_picture_title"   => get_caption('Picture'),
	"home_picture"         => "<img src='".$path_to_profiles_folder.$picture."' border='0' alt='Foto' />"
	));
?>