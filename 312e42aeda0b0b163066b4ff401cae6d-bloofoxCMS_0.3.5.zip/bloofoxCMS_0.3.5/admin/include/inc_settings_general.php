<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - admin/inc_settings_general.php -
//
// Copyrights (c) 2008-2009 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

// Forbid direct call
if(!defined('SYS_INDEX')) {
	die("You can't call this file directly!");
}

if(isset($_POST['send']) && $sys_group_vars['demo'] == 0 && $sys_rights['set_general']['write'] == 1) {
	$db->query("UPDATE ".$tbl_prefix."sys_setting SET setting_value = '".$_POST['u1']."' WHERE sid = '1' LIMIT 1");
	$db->query("UPDATE ".$tbl_prefix."sys_setting SET setting_value = '".$_POST['u2']."' WHERE sid = '2' LIMIT 1");
	$db->query("UPDATE ".$tbl_prefix."sys_setting SET setting_value = '".$_POST['u3']."' WHERE sid = '3' LIMIT 1");
	$db->query("UPDATE ".$tbl_prefix."sys_setting SET setting_value = '".$_POST['u4']."' WHERE sid = '4' LIMIT 1");
	$db->query("UPDATE ".$tbl_prefix."sys_setting SET setting_value = '".$_POST['u5']."' WHERE sid = '5' LIMIT 1");
	
	if(!empty($_POST['u6'])) {
		if(email_is_valid($_POST['u6'])) {
			$db->query("UPDATE ".$tbl_prefix."sys_setting SET setting_value = '".$_POST['u6']."' WHERE sid = '6' LIMIT 1");
		} else {
			$error = "<p class='error'>".get_caption('ErrorEmailValid')."</p>";
		}
	}
	
	$db->query("UPDATE ".$tbl_prefix."sys_setting SET setting_value = '".$_POST['u7']."' WHERE sid = '7' LIMIT 1");
	$db->query("UPDATE ".$tbl_prefix."sys_setting SET setting_value = '".$_POST['u8']."' WHERE sid = '8' LIMIT 1");
	$db->query("UPDATE ".$tbl_prefix."sys_setting SET setting_value = '".$_POST['u9']."' WHERE sid = '9' LIMIT 1");
	
	if(!empty($_POST['u10'])) {
		if(CheckInteger($_POST['u10'])) {
			$db->query("UPDATE ".$tbl_prefix."sys_setting SET setting_value = '".$_POST['u10']."' WHERE sid = '10' LIMIT 1");
		} else {
			if($error == "") {
				$error = "<p class='error'>".get_caption('ErrorIntegerOnly')."</p>";
			}
		}
	}

	if(empty($error)) {
		load_url("index.php?mode=settings");
	}
}

// select record
if(isset($_POST['sid'])) {
	$_GET['sid'] = $_POST['sid'];
}
$db->query("SELECT * FROM ".$tbl_prefix."sys_setting ORDER BY sid");
while($db->next_record()):
	$sid = $db->f("sid");
	$setting[$sid] = $db->f("setting_value");
endwhile;

if($setting[1] == "1") { $u1_select['1'] = "checked='checked'"; } else { $u1_select['0'] = "checked='checked'"; }
if($setting[2] == "1") { $u2_select['1'] = "checked='checked'"; } else { $u2_select['0'] = "checked='checked'"; }
if($setting[3] == "1") { $u3_select['1'] = "checked='checked'"; } else { $u3_select['0'] = "checked='checked'"; }
if($setting[4] == "1") { $u4_select['1'] = "checked='checked'"; } else { $u4_select['0'] = "checked='checked'"; }
if($setting[5] == "1") { $u5_select['1'] = "checked='checked'"; } else { $u5_select['0'] = "checked='checked'"; }
if($setting[7] == "1") { $u7_select['1'] = "checked='checked'"; } else { $u7_select['0'] = "checked='checked'"; }
if($setting[8] == "1") { $u8_select['1'] = "checked='checked'"; } else { $u8_select['0'] = "checked='checked'"; }
if($setting[9] == "1") { $u9_select['1'] = "checked='checked'"; } elseif($setting[9] == "2") { $u9_select['2'] = "checked='checked'"; } else { $u9_select['0'] = "checked='checked'"; }

// Set variables
$tpl->set_var(array(
	"settings_title"       => "<h2>".get_caption('Settings')." - ".get_caption('Administration')."</h2>",
	"tab_general"          => get_caption('General'),
	"tab_security"         => get_caption('Security'),
	"settings_action"      => "index.php?mode=settings",
	"settings_error"       => $error,
	"settings_u1"          => get_caption('UpdateCheck'),
	"settings_u1_input"    => get_caption('Yes')." <input type='radio' name='u1' value='1' ".$u1_select['1']." /> ".get_caption('No')."<input type='radio' name='".$setting['sid']."' value='0' ".$u1_select['0']." />",
	"settings_u2"          => get_caption('RegisterNotification'),
	"settings_u2_input"    => get_caption('Yes')." <input type='radio' name='u2' value='1' ".$u2_select['1']." /> ".get_caption('No')."<input type='radio' name='u2' value='0' ".$u2_select['0']." />",
	"settings_u3"          => get_caption('LoginProtection'),
	"settings_u3_input"    => get_caption('Yes')." <input type='radio' name='u3' value='1' ".$u3_select['1']." /> ".get_caption('No')."<input type='radio' name='u3' value='0' ".$u3_select['0']." />",
	"settings_u4"          => get_caption('OnlineStatus'),
	"settings_u4_input"    => get_caption('Yes')." <input type='radio' name='u4' value='1' ".$u4_select['1']." /> ".get_caption('No')."<input type='radio' name='u4' value='0' ".$u4_select['0']." />",
	"settings_u5"          => get_caption('UserContentOnly'),
	"settings_u5_input"    => get_caption('Yes')." <input type='radio' name='u5' value='1' ".$u5_select['1']." /> ".get_caption('No')."<input type='radio' name='u5' value='0' ".$u5_select['0']." />",
	"settings_u6"          => get_caption('AdminMail'),
	"settings_u6_input"    => "<input type='text' name='u6' value='".$setting[6]."' size='30' maxlength='80' />",
	"settings_u7"          => get_caption('HtmlMails'),
	"settings_u7_input"    => get_caption('Yes')." <input type='radio' name='u7' value='1' ".$u7_select['1']." /> ".get_caption('No')."<input type='radio' name='u7' value='0' ".$u7_select['0']." />",
	"settings_u8"          => get_caption('HtmlEntitiesOff'),
	"settings_u8_input"    => get_caption('Yes')." <input type='radio' name='u8' value='1' ".$u8_select['1']." /> ".get_caption('No')."<input type='radio' name='u8' value='0' ".$u8_select['0']." />",
	"settings_u9"          => get_caption('PasswordRule'),
	"settings_u9_input"    => get_caption('PwRule0')." <input type='radio' name='u9' value='0' ".$u9_select['0']." /> ".get_caption('PwRule1')." <input type='radio' name='u9' value='1' ".$u9_select['1']." /> ".get_caption('PwRule2')."<input type='radio' name='u9' value='2' ".$u9_select['2']." />",
	"settings_u10"         => get_caption('TextboxWidth'),
	"settings_u10_input"   => "<input type='text' name='u10' value='".$setting[10]."' size='5' maxlength='10' />",
	"settings_sid"         => "<input type='hidden' name='sid' value='".$sid."' />",
	"settings_button_send" => "<input class='btn' type='submit' name='send' value='".get_caption('SaveChanges')."' />"
	));
?>