<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - admin/inc_user_permissions.php -
//
// Copyrights (c) 2006-2008 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

// Forbid direct call
if(!defined('SYS_INDEX')) {
	die("You can't call this file directly!");
}

switch($action)
{
	case 'new':
		if(isset($_POST['send']) && $sys_group_vars['demo'] == 0 && $sys_rights['user_permissions']['write'] == 1) {
			$db->query("INSERT INTO ".$tbl_prefix."sys_permission VALUES ('','".$_POST['group_id']."','".$_POST['page']."','".$_POST['object_w']."','".$_POST['object_d']."')");
			load_url("index.php?mode=user&page=permissions");
		}

		$sys_usergroups = "";
		$db->query("SELECT gid,name FROM ".$tbl_prefix."sys_usergroup ORDER BY gid");
		while($db->next_record()):
			if($_POST["group_id"] == $db->f("gid")) {
				$sys_usergroups .= "<option value='".$db->f("gid")."' selected='selected'>".$db->f("name")."</option>";
			} else {
				$sys_usergroups .= "<option value='".$db->f("gid")."'>".$db->f("name")."</option>";
			}
		endwhile;
		
		$sys_pages = "";
		$sys_pages .= "<option value='projects'>".get_caption('AreaConfigurations')."</option>";
		$sys_pages .= "<option value='set_lang'>".get_caption('AreaLanguages')."</option>";
		$sys_pages .= "<option value='set_tmpl'>".get_caption('AreaTemplates')."</option>";
		$sys_pages .= "<option value='set_plugins'>".get_caption('AreaPlugins')."</option>";
		$sys_pages .= "<option value='set_charsets'>".get_caption('AreaCharsets')."</option>";
		$sys_pages .= "<option value='set_general'>".get_caption('AreaSettings')."</option>";
		$sys_pages .= "<option value='content_pages'>".get_caption('AreaExplorer')."</option>";
		$sys_pages .= "<option value='content_default'>".get_caption('AreaContentsDefault')."</option>";
		$sys_pages .= "<option value='content_plugins'>".get_caption('AreaContentsPlugins')."</option>";
		$sys_pages .= "<option value='content_media'>".get_caption('AreaMediacenter')."</option>";
		$sys_pages .= "<option value='content_levels'>".get_caption('AreaLevels')."</option>";
		$sys_pages .= "<option value='user'>".get_caption('AreaUser')."</option>";
		$sys_pages .= "<option value='user_groups'>".get_caption('AreaGroups')."</option>";
		$sys_pages .= "<option value='user_permissions'>".get_caption('AreaPermissions')."</option>";
		$sys_pages .= "<option value='user_sessions'>".get_caption('AreaSessions')."</option>";
		$sys_pages .= "<option value='tools'>".get_caption('AreaTools')."</option>";

		// Set variables
		$tpl->set_var(array(
			"user_title"            => "<h2>".get_caption('PermissionsAdd')." - ".get_caption('Security')."</h2>",
			"tab_general"           => get_caption('General'),
			"user_action"           => "index.php?mode=user&page=permissions&action=new",
			"user_error"            => $error,
			"user_group_id"         => get_caption('Group'),
			"user_group_id_input"   => "<select name='group_id'>".$sys_usergroups."</select>",
			"user_page"             => get_caption('Area'),
			"user_page_input"       => "<select name='page'>".$sys_pages."</select>",
			"user_object_w"         => get_caption('Write'),
			"user_object_w_input"   => "<select name='object_w'><option value='0'>".get_caption('No')."</option><option value='1'>".get_caption('Yes')."</option></select>",
			"user_object_d"         => get_caption('Del'),
			"user_object_d_input"   => "<select name='object_d'><option value='0'>".get_caption('No')."</option><option value='1'>".get_caption('Yes')."</option></select>",
			"user_button_send"      => "<input class='btn' type='submit' name='send' value='".get_caption('PermissionsAdd')."' />"
			));
	break;
	
	case 'edit':
		if(isset($_POST['send']) && $sys_group_vars['demo'] == 0 && $sys_rights['user_permissions']['write'] == 1) {
			$db->query("UPDATE ".$tbl_prefix."sys_permission SET group_id = '".$_POST['group_id']."' WHERE pid = '".$_POST['pid']."' LIMIT 1");
			$db->query("UPDATE ".$tbl_prefix."sys_permission SET page = '".$_POST['page']."' WHERE pid = '".$_POST['pid']."' LIMIT 1");
			$db->query("UPDATE ".$tbl_prefix."sys_permission SET object_w = '".$_POST['object_w']."' WHERE pid = '".$_POST['pid']."' LIMIT 1");
			$db->query("UPDATE ".$tbl_prefix."sys_permission SET object_d = '".$_POST['object_d']."' WHERE pid = '".$_POST['pid']."' LIMIT 1");
		
			load_url("index.php?mode=user&page=permissions");
		}
		
		// select record
		if(isset($_POST['pid'])) {
			$_GET['pid'] = $_POST['pid'];
		}
		
		$db->query("SELECT * FROM ".$tbl_prefix."sys_permission WHERE pid = '".$_GET['pid']."' ORDER BY pid LIMIT 1");
		while($db->next_record()):
			$pid = $db->f("pid");
			$group_id = $db->f("group_id");
			$page = $db->f("page");
			$w = mark_selected_value($db->f("object_w"));
			$d = mark_selected_value($db->f("object_d"));
		endwhile;

		$sys_usergroups = "";
		$db->query("SELECT gid,name FROM ".$tbl_prefix."sys_usergroup ORDER BY gid");
		while($db->next_record()):
			if($group_id == $db->f("gid")) {
				$sys_usergroups .= "<option value='".$db->f("gid")."' selected='selected'>".$db->f("name")."</option>";
			} else {
				$sys_usergroups .= "<option value='".$db->f("gid")."'>".$db->f("name")."</option>";
			}
		endwhile;
		
		$sys_pages = "";
		
		$sys_pages .= "<option value='projects'>".get_caption('AreaConfigurations')."</option>";
		if($page == "set_lang") {
			$sys_pages .= "<option value='set_lang' selected='selected'>".get_caption('AreaLanguages')."</option>";
		} else {
			$sys_pages .= "<option value='set_lang'>".get_caption('AreaLanguages')."</option>";
		}
		if($page == "set_tmpl") {
			$sys_pages .= "<option value='set_tmpl' selected='selected'>".get_caption('AreaTemplates')."</option>";
		} else {
			$sys_pages .= "<option value='set_tmpl'>".get_caption('AreaTemplates')."</option>";
		}
		if($page == "set_plugins") {
			$sys_pages .= "<option value='set_plugins' selected='selected'>".get_caption('AreaPlugins')."</option>";
		} else {
			$sys_pages .= "<option value='set_plugins'>".get_caption('AreaPlugins')."</option>";
		}
		if($page == "set_charsets") {
			$sys_pages .= "<option value='set_charsets' selected='selected'>".get_caption('AreaCharsets')."</option>";
		} else {
			$sys_pages .= "<option value='set_charsets'>".get_caption('AreaCharsets')."</option>";
		}
		if($page == "set_general") {
			$sys_pages .= "<option value='set_general' selected='selected'>".get_caption('AreaSettings')."</option>";
		} else {
			$sys_pages .= "<option value='set_general'>".get_caption('AreaSettings')."</option>";
		}
		if($page == "content_explorer") {
			$sys_pages .= "<option value='content_pages' selected='selected'>".get_caption('AreaExplorer')."</option>";
		} else {
			$sys_pages .= "<option value='content_pages'>".get_caption('AreaExplorer')."</option>";
		}
		if($page == "content_default") {
			$sys_pages .= "<option value='content_default' selected='selected'>".get_caption('AreaContentsDefault')."</option>";
		} else {
			$sys_pages .= "<option value='content_default'>".get_caption('AreaContentsDefault')."</option>";
		}
		if($page == "content_plugins") {
			$sys_pages .= "<option value='content_plugins' selected='selected'>".get_caption('AreaContentsPlugins')."</option>";
		} else {
			$sys_pages .= "<option value='content_plugins'>".get_caption('AreaContentsPlugins')."</option>";
		}
		if($page == "content_media") {
			$sys_pages .= "<option value='content_media' selected='selected'>".get_caption('AreaMediacenter')."</option>";
		} else {
			$sys_pages .= "<option value='content_media'>".get_caption('AreaMediacenter')."</option>";
		}
		if($page == "content_levels") {
			$sys_pages .= "<option value='content_levels' selected='selected'>".get_caption('AreaLevels')."</option>";
		} else {
			$sys_pages .= "<option value='content_levels'>".get_caption('AreaLevels')."</option>";
		}
		if($page == "user") {
			$sys_pages .= "<option value='user' selected='selected'>".get_caption('AreaUser')."</option>";
		} else {
			$sys_pages .= "<option value='user'>".get_caption('AreaUser')."</option>";
		}
		if($page == "user_groups") {
			$sys_pages .= "<option value='user_groups' selected='selected'>".get_caption('AreaGroups')."</option>";
		} else {
			$sys_pages .= "<option value='user_groups'>".get_caption('AreaGroups')."</option>";
		}
		if($page == "user_permissions") {
			$sys_pages .= "<option value='user_permissions' selected='selected'>".get_caption('AreaPermissions')."</option>";
		} else {
			$sys_pages .= "<option value='user_permissions'>".get_caption('AreaPermissions')."</option>";
		}
		if($page == "user_sessions") {
			$sys_pages .= "<option value='user_sessions' selected='selected'>".get_caption('AreaSessions')."</option>";
		} else {
			$sys_pages .= "<option value='user_sessions'>".get_caption('AreaSessions')."</option>";
		}
		if($page == "tools") {
			$sys_pages .= "<option value='tools' selected='selected'>".get_caption('AreaTools')."</option>";
		} else {
			$sys_pages .= "<option value='tools'>".get_caption('AreaTools')."</option>";
		}
		
		// Set variables
		$tpl->set_var(array(
			"user_title"            => "<h2>".get_caption('PermissionsEdit')." - ".get_caption('Security')."</h2>",
			"tab_general"           => get_caption('General'),
			"user_action"           => "index.php?mode=user&page=permissions&action=edit",
			"user_error"            => $error,
			"user_group_id"         => get_caption('Group'),
			"user_group_id_input"   => "<select name='group_id'>".$sys_usergroups."</select>",
			"user_page"             => get_caption('Area'),
			"user_page_input"       => "<select name='page'>".$sys_pages."</select>",
			"user_object_w"         => get_caption('Write'),
			"user_object_w_input"   => "<select name='object_w'><option value='0' ".$w['1'].">".get_caption('No')."</option><option value='1' ".$w['2'].">".get_caption('Yes')."</option></select>",
			"user_object_d"         => get_caption('Del'),
			"user_object_d_input"   => "<select name='object_d'><option value='0' ".$d['1'].">".get_caption('No')."</option><option value='1' ".$d['2'].">".get_caption('Yes')."</option></select>",
			"user_pid"              => "<input type='hidden' name='pid' value='".$pid."' />",
			"user_button_send"      => "<input class='btn' type='submit' name='send' value='".get_caption('SaveChanges')."' />"
			));
	break;
	
	case 'del':
		if(isset($_POST['send']) && $sys_group_vars['demo'] == 0 && $sys_rights['user_permissions']['delete'] == 1) {
			$db->query("DELETE FROM ".$tbl_prefix."sys_permission WHERE pid = '".$_POST['pid']."' LIMIT 1");
			load_url("index.php?mode=user&page=permissions");
		}
		
		// select record
		if(isset($_POST['pid'])) {
			$_GET['pid'] = $_POST['pid'];
		}
		$db->query("SELECT * FROM ".$tbl_prefix."sys_permission WHERE pid = '".$_GET['pid']."' ORDER BY pid LIMIT 1");
		while($db->next_record()):
			$pid = $db->f("pid");
			$name = $db->f("group_id");
			$page = $db->f("page");
		endwhile;
		
		$db->query("SELECT name FROM ".$tbl_prefix."sys_usergroup WHERE gid = '".$name."' LIMIT 1");
		while($db->next_record()):
			$name = $db->f("name");
		endwhile;
		
		// Set variables
		$tpl->set_var(array(
			"user_title"       => "<h2>".get_caption('PermissionsDelete')." - ".get_caption('Security')."</h2>",
			"user_action"      => "index.php?mode=user&page=permissions&action=del",
			"user_question"    => "<p>".get_caption('DeleteQuestion')."</p>",
			"user_name"        => "<p class='bold'>".$name." - ".$page."</p>",
			"user_pid"         => "<input type='hidden' name='pid' value='".$pid."' />",
			"user_button_send" => "<input class='btn' type='submit' name='send' value='".get_caption('EntryDelete')."' />"
			));
	break;
	
	default:
		// Create permissions overview
		
		// Headline
		$user_permissions .= "<table><tr class='bg_color3'>"
			."<td><p class='bold'>".get_caption('Group')."</p></td>"
			."<td><p class='bold'>".get_caption('Area')."</p></td>"
			."<td><p class='bold'>".get_caption('Write')."</p></td>"
			."<td><p class='bold'>".get_caption('Del')."</p></td>"
			."<td><p class='bold'>".get_caption('Action')."</p></td>"
			."</tr>";
			
		// Lines
		$db->query("SELECT * FROM ".$tbl_prefix."sys_usergroup INNER JOIN ".$tbl_prefix."sys_permission ON ".$tbl_prefix."sys_usergroup.gid = ".$tbl_prefix."sys_permission.group_id ORDER BY pid");
		while($db->next_record()):
			$user_permissions .= "<tr class='bg_color2'>"
				."<td>".$db->f("name")."</td>"
				."<td>".$db->f("page")."</td>"
				."<td>".translate_yesno($db->f("object_w"),get_caption('Yes'),get_caption('No'))."</td>"
				."<td>".translate_yesno($db->f("object_d"),get_caption('Yes'),get_caption('No'))."</td>"
				."<td>"
				.$ac->create_link("index.php?mode=user&page=permissions&action=edit&pid=",$db->f("pid"),get_caption('EditText'),"edit",get_caption('Edit'))
				.$ac->create_link("index.php?mode=user&page=permissions&action=del&pid=",$db->f("pid"),get_caption('Del'),"delete",get_caption('Delete'))
				."</td>"
				."</tr>";
		endwhile;
		$user_permissions .= "</table>";

		// Set variables
		$tpl->set_var(array(
			"user_title"    => "<h2>".get_caption('Permissions')." - ".get_caption('Security')."</h2>",
			"user_permissions"     => $user_permissions,
			"user_permissions_new" => "<p><a class='edit' href='index.php?mode=user&page=permissions&action=new' title='".get_caption('PermissionsAdd')."'><img src='images/icon_add.gif' alt='".get_caption('PermissionsAdd')."' border='0' width='16' height='16' /></a></p>"
			));
	break;
}
?>