<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - admin/inc_content_content.php -
//
// Copyrights (c) 2006-2008 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

// Forbid direct call
if(!defined('SYS_INDEX')) {
	die("You can't call this file directly!");
}

// load and init content class
require_once("../".SYS_FOLDER."/class_content.php");
$contents = new content();

// get explorer_id from cid
if(isset($_GET['cid'])) {
	$db->query("SELECT explorer_id FROM ".$tbl_prefix."sys_content WHERE cid = '".$_GET['cid']."' LIMIT 1");
	while($db->next_record()):
		$_GET['eid'] = $db->f("explorer_id");
	endwhile;
}

// convert post var to get var
if(isset($_POST['eid'])) {
	$_GET['eid'] = $_POST['eid'];
}

// header back when NOT link_type "standard" or "plugin"
$page_vars = $contents->get_page_vars($db,$_GET['eid']);

if($page_vars['link_type'] != 0 && $page_vars['link_type'] != 3) {
	load_url("index.php?mode=content&page=pages");
}

switch($action)
{
	case 'new':
		if(isset($_POST['send']) && $sys_group_vars['demo'] == 0) {
			// get needed page field values
			$page_vars = $contents->get_page_vars($db,$_POST['eid']);
			
			// check permissions for page link_type "standard" or "plugin"
			if(($page_vars['link_type'] == 0 && $sys_rights['content_default']['write'] == 1) || ($page_vars['link_type'] == 3 && $sys_rights['content_plugins']['write'] == 1)) {
				// format input fields
				$_POST['title'] = validate_text($_POST['title']);
				$_POST['text'] = replace_specialchars($_POST['text']);
				if($admin_plugin[998] == 0) {
					$_POST['text'] = text_2_html($_POST['text']);
				}
					
				$sorting = $contents->get_sorting_number($db,$_POST['insert'],$_POST['eid']);
				
				$created_by = $_SESSION["username"];
				$created_at = time();
				
				$db->query("INSERT INTO ".$tbl_prefix."sys_content VALUES ('','".$_POST['eid']."','".$sorting."','','".$_POST['title']."','".$_POST['text']."','".$_POST['blocked']."','".$created_by."','".$created_at."','','')");
				
				// header url
				load_url("index.php?mode=content&page=content&eid=".$_POST['eid']);
			}
		}
			
		// include SPAW wysiwyg-editor for field text
		if($admin_plugin[998] == 1) {
			include_once("../plugins/spaw2/spaw.inc.php");
			$sw = new SpawEditor('text',
				stripslashes($_POST['text']),
				$sys_vars['token'], // language
				'', // toolbar mode
				'', // theme
				$sys_setting_vars["textbox_width"].'px', // width
				'200px' // height
				);
			$textarea = $sw->getHTML();
			$html_tags = "";
		} else {
			$text = html_2_text($text);
			$textarea = "<textarea name='text' cols='60' rows='10'>".$_POST['text']."</textarea>";
		}
		
		// Set variables
		$tpl->set_var(array(
			"content_title"         => "<h2>".get_caption('ArticleAdd')." - ".get_caption('Pages')." - ".get_caption('Contents')."</h2>",
			"content_action"        => "index.php?mode=content&page=content&action=new&eid=".$_GET['eid'],
			"content_page"          => get_caption('Page'),
			"content_page_input"    => $page_vars['name'],
			"content_insert"        => "<input type='radio' name='insert' value='top' checked='checked' /> ".get_caption('Top')." <input type='radio' name='insert' value='bottom' /> ".get_caption('Bottom'),
			//"content_type"        => "Art",
			//"content_type_input"  => "<select name='content_type'>".$sys_content_type."</select>",
			"content_header"        => get_caption('HeadLine'),
			"content_header_input"  => "<input type='text' name='title' value='".$_POST['title']."' size='60' maxlength='250' />",
			"content_text"          => get_caption('TextContent'),
			"content_text_input"    => $textarea.$html_tags,
			"content_blocked"       => get_caption('Blocked'),
			"content_blocked_input" => "<select name='blocked'><option value='0'>".get_caption('No')."</option><option value='1'>".get_caption('Yes')."</option></select>",
			"content_eid"           => "<input type='hidden' name='eid' value='".$_GET['eid']."' />",
			"content_button_send"   => "<p><input class='btn' type='submit' name='send' value='".get_caption('ArticleAdd')."' /></p>"
			));
			// Parse template with variables
		$tpl->parse("content_handle", "content", true);
	break;

	case 'edit': // edit content entry
		// default editing
		if((isset($_POST['send']) || isset($_POST['sendclose'])) && $sys_group_vars['demo'] == 0) {
			if(($page_vars['link_type'] == 0 && $sys_rights['content_default']['write'] == 1) || ($page_vars['link_type'] == 3 && $sys_rights['content_plugins']['write'] == 1)) {
				$cid = $_POST['cid'];
				// format input fields
				$_POST['title'] = validate_text($_POST['title']);
				$_POST['text'] = replace_specialchars($_POST['text']);
				if($admin_plugin[998] == 0) {
					$_POST['text'] = text_2_html($_POST['text']);
				}

				// save changes in database
				//$db2->query("UPDATE ".$tbl_prefix."sys_content SET content_type = '".$_POST['content_type']."' WHERE cid = '".$cid."' ORDER BY cid LIMIT 1");
				$db2->query("UPDATE ".$tbl_prefix."sys_content SET blocked = '".$_POST['blocked']."' WHERE cid = '".$cid."' ORDER BY cid LIMIT 1");
				
				$text_hash = md5($_POST['title'].$_POST['text']);
				if($_POST['text_hash'] != $text_hash) {
					$db2->query("UPDATE ".$tbl_prefix."sys_content SET title = '".$_POST['title']."' WHERE cid = '".$cid."' ORDER BY cid LIMIT 1");
					$db2->query("UPDATE ".$tbl_prefix."sys_content SET text = '".$_POST['text']."' WHERE cid = '".$cid."' ORDER BY cid LIMIT 1");
					// log change
					$db2->query("UPDATE ".$tbl_prefix."sys_content SET changed_by = '".$_SESSION['username']."' WHERE cid = '".$cid."' ORDER BY cid LIMIT 1");
					$changed_at = time();
					$db2->query("UPDATE ".$tbl_prefix."sys_content SET changed_at = '".$changed_at."' WHERE cid = '".$cid."' ORDER BY cid LIMIT 1");
				}
				
				if($_POST['eid'] != $_POST['old_eid']) {
					$db2->query("UPDATE ".$tbl_prefix."sys_content SET explorer_id = '".$_POST['eid']."' WHERE cid = '".$cid."' ORDER BY cid LIMIT 1");
					$sorting = $contents->get_sorting_number($db2,"bottom",$_POST['eid']);
					$db2->query("UPDATE ".$tbl_prefix."sys_content SET sorting = '".$sorting."' WHERE cid = '".$cid."' ORDER BY cid LIMIT 1");
				}
				
				// header url
				if(isset($_POST['sendclose'])) {
					load_url("index.php?mode=content&page=content&eid=".$_GET['eid']);
				} else {
					load_url("index.php?mode=content&page=content&action=edit&cid=".$cid);
				}
			}
		}
		
		// Select Record
		$db->query("SELECT * FROM ".$tbl_prefix."sys_content WHERE cid = '".$_GET['cid']."' ORDER BY cid LIMIT 1");
		
		while($db->next_record()):
			$cid = $db->f("cid");
			$eid = $db->f("explorer_id");
			//$content_type = $db->f("content_type");
			$title = $db->f("title");
			$text = $db->f("text");
			$blocked = mark_selected_value($db->f("blocked"));
			$text_hash = md5($title.$text);
			$created_by = $db->f("created_by");
			// content protection per user
			if($sys_setting_vars['user_content_only'] == 1 && $sys_rights['set_general']['write'] == 0) {
				if($created_by != $_SESSION['username']) {
					load_url("index.php?mode=content&page=content&eid=".$_GET['eid']);
				}
			}
			
			// include SPAW wysiwyg-editor for field text
			if($admin_plugin[998] == 1) {
				include_once("../plugins/spaw2/spaw.inc.php");
				$sw = new SpawEditor('text',
					stripslashes($text),
					$sys_vars['token'], // language
					'', // toolbar mode
					'', // theme
					$sys_setting_vars["textbox_width"].'px', // width
					'200px' // height
					);
				$textarea = $sw->getHTML();
				$html_tags = "";
			} else {
				$text = html_2_text($text);
				$textarea = "<textarea name='text' cols='60' rows='10'>".$text."</textarea>";
			}
			
			$content_created_at = "";
			if($db->f("created_at") != "") {
				$content_created_at = date($sys_vars['datetime'],$db->f("created_at"));
			}
			$content_changed_at = "";
			if($db->f("changed_at") != "") {
				$content_changed_at = date($sys_vars['datetime'],$db->f("changed_at"));
			}

			$content_info = get_caption('CreatedBy').": ".$db->f("created_by")."<br />"
				.get_caption('CreatedAt').": ".$content_created_at."<br />"
				.get_caption('ChangedBy').": ".$db->f("changed_by")."<br />"
				.get_caption('ChangedAt').": ".$content_changed_at;
				
			$content_articles = get_structure($content_articles,0,$eid);
			
			// Set variables
			$tpl->set_var(array(
				"content_title"        => "<h2>".get_caption('ArticleEdit')." - ".get_caption('Pages')." - ".get_caption('Contents')."</h2>",
				"content_action"       => "index.php?mode=content&page=content&action=edit&cid=".$cid,
				"content_info"         => $content_info,
				"content_page"          => get_caption('Page'),
				"content_page_input"    => "<select name='eid'>".$content_articles."</select><input type='hidden' name='old_eid' value='".$eid."' />",
				//"content_type"        => "Art",
				//"content_type_input"  => "<select name='content_type'>".$sys_content_type."</select>",
				"content_header"       => get_caption('HeadLine'),
				"content_header_input" => "<input type='text' name='title' value='".$title."' size='60' maxlength='250' />",
				"content_text"         => get_caption('TextContent'),
				"content_text_input"   => $textarea.$html_tags,
				"content_cid"          => "<input type='hidden' name='cid' value='".$cid."' />",
				"content_hash"         => "<input type='hidden' name='text_hash' value='".$text_hash."' />",
				"content_blocked"      => get_caption('Blocked'),
				"content_blocked_input" => "<select name='blocked'><option value='0' ".$blocked['1'].">".get_caption('No')."</option><option value='1' ".$blocked['2'].">".get_caption('Yes')."</option></select>",
				"content_button_send"  => "<p><input class='btn' type='submit' name='send' value='".get_caption('SaveChanges')."' /> <input class='btn' type='submit' name='sendclose' value='".get_caption('SaveAndClose')."' /></p>"
				));
			// Parse template with variables
			$tpl->parse("content_handle", "content", true);
		endwhile;
	break;
			
	case 'del':
		if(isset($_POST['send']) && $sys_group_vars['demo'] == 0) {
			if(($page_vars['link_type'] == 0 && $sys_rights['content_default']['delete'] == 1) || ($page_vars['link_type'] == 3 && $sys_rights['content_plugins']['delete'] == 1)) {
				$db->query("DELETE FROM ".$tbl_prefix."sys_content WHERE cid = '".$_POST['cid']."' LIMIT 1");
				load_url("index.php?mode=content&page=content&eid=".$_POST['eid']);
			}
		}
				
		// select record
		if(isset($_POST['cid'])) {
			$_GET['cid'] = $_POST['cid'];
		}
		$db->query("SELECT cid,title,explorer_id,created_by FROM ".$tbl_prefix."sys_content WHERE cid = '".$_GET['cid']."' ORDER BY cid LIMIT 1");
		while($db->next_record()):
			$cid = $db->f("cid");
			$title = $db->f("title");
			$eid = $db->f("explorer_id");
			$created_by = $db->f("created_by");
		endwhile;
		
		// content protection per user
		if($sys_setting_vars['user_content_only'] == 1 && $sys_rights['set_general']['write'] == 0) {
			if($created_by != $_SESSION['username']) {
				load_url("index.php?mode=content&page=content&eid=".$_GET['eid']);
			}
		}
				
		// Set variables
		$tpl->set_var(array(
			"content_title"    => "<h2>".get_caption('ArticleDelete')." - ".get_caption('Pages')." - ".get_caption('Contents')."</h2>",
			"content_action"   => "index.php?mode=content&page=content&action=del",
			"content_question" => "<p>".get_caption('DeleteQuestion')."</p>",
			"content_name"     => "<p class='bold'>".$title."</p>",
			"content_cid"      => "<input type='hidden' name='cid' value='".$cid."' /><input type='hidden' name='eid' value='".$eid."' />",
			"content_button_send" => "<input class='btn' type='submit' name='send' value='".get_caption('ArticleDelete')."' />"
			));
		$tpl->parse("content_handle", "content", true);
	break;
			
	default: // Article list
		// Move actions
		if(isset($_GET['action']) && (($page_vars['link_type'] == 0 && $sys_rights['content_default']['write'] == 1) || ($page_vars['link_type'] == 3 && $sys_rights['content_plugins']['write'] == 1))) {
			if(!CheckInteger($_GET['cid'])) {
				unset($_GET['action']);
			}
			switch($_GET['action'])
			{
				case 'move_up':
					// get cid of prev entry
					$db->query("SELECT cid,sorting FROM ".$tbl_prefix."sys_content WHERE explorer_id = '".$_GET['eid']."' ORDER BY sorting DESC");
					while($db->next_record()):
						if($prev == 1) {
							$prev_cid = $db->f("cid");
							$prev_sorting = $db->f("sorting");
							$prev = 0;
						}
						if($db->f("cid") == $_GET['cid']) {
							$curr_sorting = $db->f("sorting");
							$prev = 1;
						}
					endwhile;
					// change sorting
					if($prev_cid != 0) {
						$db->query("UPDATE ".$tbl_prefix."sys_content SET sorting = ".$curr_sorting." WHERE cid = '".$prev_cid."' LIMIT 1");
						$db->query("UPDATE ".$tbl_prefix."sys_content SET sorting = ".$prev_sorting." WHERE cid = '".$_GET['cid']."' LIMIT 1");
					}
				break;
		
				case 'move_down':
					// get cid of next entry
					$db->query("SELECT cid,sorting FROM ".$tbl_prefix."sys_content WHERE explorer_id = '".$_GET['eid']."' ORDER BY sorting");
					while($db->next_record()):
						if($next == 1) {
							$next_cid = $db->f("cid");
							$next_sorting = $db->f("sorting");
							$next = 0;
						}
						if($db->f("cid") == $_GET['cid']) {
							$curr_sorting = $db->f("sorting");
							$next = 1;
						}
					endwhile;
					// change sorting
					if($next_cid != 0) {
						$db->query("UPDATE ".$tbl_prefix."sys_content SET sorting = ".$curr_sorting." WHERE cid = '".$next_cid."' LIMIT 1");
						$db->query("UPDATE ".$tbl_prefix."sys_content SET sorting = ".$next_sorting." WHERE cid = '".$_GET['cid']."' LIMIT 1");
					}
				break;
			}
			load_url("index.php?mode=content&page=content&eid=".$_GET['eid']);
		}
		
		// Create Table
		$content_list .= "<table>"
			."<tr class='bg_color3'>"
			//."<td><p class='bold'>".get_caption('EntryID')."</p></td>"
			."<td width='200'><p class='bold'>".get_caption('Title')."</p></td>"
			."<td><p class='bold'>".get_caption('Blocked')."</p></td>"
			."<td><p class='bold'>".get_caption('CreatedBy')."</p></td>"
			."<td><p class='bold'>".get_caption('CreatedAt')."</p></td>"
			."<td width='80'><p class='bold'>".get_caption('Action')."</p></td>"
			."</tr>";
		
		// Select Record
		$db->query("SELECT * FROM ".$tbl_prefix."sys_content WHERE explorer_id = '".$_GET['eid']."' ORDER BY sorting");
		
		while($db->next_record()):
			$cid = $db->f("cid");
			$sorting = $db->f("sorting") / 2;
			//$content_type = $db->f("content_type");
			
			$created_at = "";
			if($db->f("created_at") != "") {
				$created_at = date($sys_vars['datetime'],$db->f("created_at"));
			}
			
			$content_list .= "<tr class='bg_color2'>"
				//."<td>".$db->f("explorer_id")."</td>"
				."<td><a href='index.php?mode=content&page=content&action=edit&cid=".$cid."' title='".substr(strip_tags($db->f("text")),0,200)."'>".$db->f("title")."</a></td>"
				."<td>".translate_yesno($db->f("blocked"),get_caption('Yes'),get_caption('No'))."</td>"
				."<td>".$db->f("created_by")."</td>"
				."<td>".$created_at."</td>"
				."<td>"
				.$ac->create_link("index.php?mode=content&page=content&action=edit&cid=",$cid,get_caption('EditText'),"edit",get_caption('Edit'))
				.$ac->create_link("index.php?mode=content&page=content&action=del&cid=",$cid,get_caption('Del'),"delete",get_caption('Delete'))
				.$ac->create_link("index.php?mode=content&page=content&action=move_up&cid=",$cid,get_caption('MoveUp'),"edit",get_caption('IcoUp'))
				.$ac->create_link("index.php?mode=content&page=content&action=move_down&cid=",$cid,get_caption('MoveDown'),"edit",get_caption('IcoDown'))
				."</td>";
		endwhile;
		
		// Close Table
		$content_list .= "</table>";
		
		// Set variables
		$tpl->set_var(array(
			"content_title"       => "<h2>".get_caption('Articles')." - ".get_caption('Pages')." - ".get_caption('Contents')."</h2>",
			"content_new"         => "<a class='edit' href='index.php?mode=content&page=content&action=new&eid=".$_GET['eid']."' title='".get_caption('ArticleAdd')."'><img src='images/icon_add.gif' alt='".get_caption('ArticleAdd')."' border='0' width='16' height='16' /></a> ",
			"content_list"        => $content_list,
			"content_filter"      => $page_vars['name']
			));

		// Parse template with variables
		$tpl->parse("content_handle", "content", true);

	break;
}
?>