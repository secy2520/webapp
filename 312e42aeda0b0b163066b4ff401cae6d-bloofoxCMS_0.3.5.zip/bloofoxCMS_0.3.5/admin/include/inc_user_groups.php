<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - admin/inc_user_groups.php -
//
// Copyrights (c) 2006-2008 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

// Forbid direct call
if(!defined('SYS_INDEX')) {
	die("You can't call this file directly!");
}

switch($action)
{
	case 'new':
		if(isset($_POST['send']) && $sys_group_vars['demo'] == 0 && $sys_rights['user_groups']['write'] == 1) {
			$_POST['name'] = validate_text($_POST['name']);
			
			if(!mandatory_field($_POST['name']) && $error == "") {
				$error = "<p class='error'>".get_caption('ErrorName')."</p>";
			}
								
			if($error == "") {
				$db->query("INSERT INTO ".$tbl_prefix."sys_usergroup VALUES ('','".$_POST['name']."','".$_POST['backend']."','".$_POST['content']."','".$_POST['settings']."','".$_POST['configure']."','".$_POST['permissions']."','".$_POST['tools']."','".$_POST['demo']."')");
				load_url("index.php?mode=user&page=groups");
			}
		}
		
		// Set variables
		$tpl->set_var(array(
			"user_title"            => "<h2>".get_caption('GroupAdd')." - ".get_caption('Security')."</h2>",
			"tab_general"           => get_caption('General'),
			"groups_action"         => "index.php?mode=user&page=groups&action=new",
			"groups_error"          => $error,
			"groups_name"           => get_caption('Name'),
			"groups_name_input"     => "<input type='text' name='name' size='25' maxlength='250' value='".$_POST['name']."' />",
			"groups_backend"        => get_caption('Backend'),
			"groups_backend_input"  => "<select name='backend'><option value='0'>".get_caption('No')."</option><option value='1'>".get_caption('Yes')."</option></select>",
			"groups_content"        => get_caption('Contents'),
			"groups_content_input"  => "<select name='content'><option value='0'>".get_caption('No')."</option><option value='1'>".get_caption('Yes')."</option></select>",
			"groups_settings"       => get_caption('Administration'),
			"groups_settings_input" => "<select name='settings'><option value='0'>".get_caption('No')."</option><option value='1'>".get_caption('Yes')."</option></select>",
			//"groups_configure"      => get_caption('Configurations'),
			//"groups_configure_input" => "<select name='configure'><option value='0'>".get_caption('No')."</option><option value='1'>".get_caption('Yes')."</option></select>",
			"groups_permissions"    => get_caption('Security'),
			"groups_permissions_input" => "<select name='permissions'><option value='0'>".get_caption('No')."</option><option value='1'>".get_caption('Yes')."</option></select>",
			"groups_tools"          => get_caption('Tools'),
			"groups_tools_input"    => "<select name='tools'><option value='0'>".get_caption('No')."</option><option value='1'>".get_caption('Yes')."</option></select>",
			"groups_demo"           => get_caption('Demo'),
			"groups_demo_input"     => "<select name='demo'><option value='0'>".get_caption('No')."</option><option value='1'>".get_caption('Yes')."</option></select>",
			"groups_button_send"    => "<input class='btn' type='submit' name='send' value='".get_caption('GroupAdd')."' />"
			));
	break;
	
	case 'edit':
		if(isset($_POST['send']) && $sys_group_vars['demo'] == 0 && $sys_rights['user_groups']['write'] == 1) {
			$_POST['name'] = validate_text($_POST['name']);
			
			if(!mandatory_field($_POST['name']) && $error == "") {
				$error = "<p class='error'>".get_caption('ErrorName')."</p>";
			}
			
			if(mandatory_field($_POST['name'])) {
				$db->query("UPDATE ".$tbl_prefix."sys_usergroup SET name = '".$_POST['name']."' WHERE gid = '".$_POST['gid']."' LIMIT 1");
				if($_POST['name'] != $_POST['name_old']) {
					$perm->rename_group($db,$_POST['name_old'],$_POST['name']);
				}
			}
			$db->query("UPDATE ".$tbl_prefix."sys_usergroup SET backend = '".$_POST['backend']."' WHERE gid = '".$_POST['gid']."' LIMIT 1");
			$db->query("UPDATE ".$tbl_prefix."sys_usergroup SET content = '".$_POST['content']."' WHERE gid = '".$_POST['gid']."' LIMIT 1");
			$db->query("UPDATE ".$tbl_prefix."sys_usergroup SET settings = '".$_POST['settings']."' WHERE gid = '".$_POST['gid']."' LIMIT 1");
			//$db->query("UPDATE ".$tbl_prefix."sys_usergroup SET configure = '".$_POST['configure']."' WHERE gid = '".$_POST['gid']."' LIMIT 1");
			$db->query("UPDATE ".$tbl_prefix."sys_usergroup SET permissions = '".$_POST['permissions']."' WHERE gid = '".$_POST['gid']."' LIMIT 1");
			$db->query("UPDATE ".$tbl_prefix."sys_usergroup SET tools = '".$_POST['tools']."' WHERE gid = '".$_POST['gid']."' LIMIT 1");
			$db->query("UPDATE ".$tbl_prefix."sys_usergroup SET demo = '".$_POST['demo']."' WHERE gid = '".$_POST['gid']."' LIMIT 1");
			
			if($error == "") {
				load_url("index.php?mode=user&page=groups");
			}
		}
		
		// select record
		if(isset($_POST['gid'])) {
			$_GET['gid'] = $_POST['gid'];
		}
		$db->query("SELECT * FROM ".$tbl_prefix."sys_usergroup WHERE gid = '".$_GET['gid']."' ORDER BY gid LIMIT 1");
		while($db->next_record()):
			$gid = $db->f("gid");
			$name = $db->f("name");
			$backend = mark_selected_value($db->f("backend"));
			$content = mark_selected_value($db->f("content"));
			$settings = mark_selected_value($db->f("settings"));
			//$configure = mark_selected_value($db->f("configure"));
			$permissions = mark_selected_value($db->f("permissions"));
			$tools = mark_selected_value($db->f("tools"));
			$demo = mark_selected_value($db->f("demo"));
		endwhile;
		
		// Set variables
		$tpl->set_var(array(
			"user_title"            => "<h2>".get_caption('GroupEdit')." - ".get_caption('Security')."</h2>",
			"tab_general"           => get_caption('General'),
			"groups_action"         => "index.php?mode=user&page=groups&action=edit",
			"groups_error"          => $error,
			"groups_name"           => get_caption('Name'),
			"groups_name_input"     => "<input type='text' name='name' size='25' maxlength='250' value='".$name."' />",
			"groups_backend"        => get_caption('Backend'),
			"groups_backend_input"  => "<select name='backend'><option value='0' ".$backend['1'].">".get_caption('No')."</option><option value='1' ".$backend['2'].">".get_caption('Yes')."</option></select>",
			"groups_content"        => get_caption('Contents'),
			"groups_content_input"  => "<select name='content'><option value='0' ".$content['1'].">".get_caption('No')."</option><option value='1' ".$content['2'].">".get_caption('Yes')."</option></select>",
			"groups_settings"       => get_caption('Administration'),
			"groups_settings_input" => "<select name='settings'><option value='0' ".$settings['1'].">".get_caption('No')."</option><option value='1' ".$settings['2'].">".get_caption('Yes')."</option></select>",
			//"groups_configure"      => get_caption('Configurations'),
			//"groups_configure_input" => "<select name='configure'><option value='0' ".$configure['1'].">".get_caption('No')."</option><option value='1' ".$configure['2'].">".get_caption('Yes')."</option></select>",
			"groups_permissions"    => get_caption('Security'),
			"groups_permissions_input" => "<select name='permissions'><option value='0' ".$permissions['1'].">".get_caption('No')."</option><option value='1' ".$permissions['2'].">".get_caption('Yes')."</option></select>",
			"groups_tools"          => get_caption('Tools'),
			"groups_tools_input"    => "<select name='tools'><option value='0' ".$tools['1'].">".get_caption('No')."</option><option value='1' ".$tools['2'].">".get_caption('Yes')."</option></select>",
			"groups_demo"           => get_caption('Demo'),
			"groups_demo_input"     => "<select name='demo'><option value='0' ".$demo['1'].">".get_caption('No')."</option><option value='1' ".$demo['2'].">".get_caption('Yes')."</option></select>",
			"groups_gid"            => "<input type='hidden' name='gid' value='".$gid."' /><input type='hidden' name='name_old' value='".$name."' />",
			"groups_button_send"    => "<input class='btn' type='submit' name='send' value='".get_caption('SaveChanges')."' />"
			));
	break;
	
	case 'del':
		if(isset($_POST['send']) && $sys_group_vars['demo'] == 0 && $sys_rights['user_groups']['delete'] == 1) {
			if($perm->delete_group($db,$_POST['name']) == 1) {
				$db->query("DELETE FROM ".$tbl_prefix."sys_usergroup WHERE gid = '".$_POST['gid']."' LIMIT 1");
			} else {
				$_SESSION['error'] = get_caption('ErrorDeleteGroup');
			}
			load_url("index.php?mode=user&page=groups");
		}
		
		// select record
		if(isset($_POST['gid'])) {
			$_GET['gid'] = $_POST['gid'];
		}
		$db->query("SELECT gid,name FROM ".$tbl_prefix."sys_usergroup WHERE gid = '".$_GET['gid']."' ORDER BY gid LIMIT 1");
		while($db->next_record()):
			$gid = $db->f("gid");
			$name = $db->f("name");
		endwhile;
		
		// Set variables
		$tpl->set_var(array(
			"user_title"         => "<h2>".get_caption('GroupDelete')." - ".get_caption('Security')."</h2>",
			"groups_action"      => "index.php?mode=user&page=groups&action=del",
			"groups_question"    => "<p>".get_caption('DeleteQuestion')."</p>",
			"groups_name"        => "<p class='bold'>".$name."</p>",
			"groups_gid"         => "<input type='hidden' name='gid' value='".$gid."' /><input type='hidden' name='name' value='".$name."' />",
			"groups_button_send" => "<input class='btn' type='submit' name='send' value='".get_caption('EntryDelete')."' />"
			));
	break;
	
	default:
		// Create groups overview
		if(!empty($_SESSION['error'])) {
			$user_groups = "<p class='error'>".$_SESSION['error']."</p>";
			unset($_SESSION['error']);
		}
		
		// Headline
		$user_groups .= "<table><tr class='bg_color3'>"
			."<td><p class='bold'>".get_caption('Name')."</p></td>"
			."<td><p class='bold'>".get_caption('Backend')."</p></td>"
			//."<td><p class='bold'>".get_caption('Configurations')."</p></td>"
			."<td><p class='bold'>".get_caption('Contents')."</p></td>"
			."<td><p class='bold'>".get_caption('Administration')."</p></td>"
			."<td><p class='bold'>".get_caption('Security')."</p></td>"
			."<td><p class='bold'>".get_caption('Tools')."</p></td>"
			."<td><p class='bold'>".get_caption('Demo')."</p></td>"
			."<td><p class='bold'>".get_caption('Action')."</p></td>"
			."</tr>";
			
		// Lines
		$db->query("SELECT * FROM ".$tbl_prefix."sys_usergroup ORDER BY gid");
		while($db->next_record()):
			$user_groups .= "<tr class='bg_color2'>"
				."<td>".$db->f("name")."</td>"
				."<td>".translate_yesno($db->f("backend"),get_caption('Yes'),get_caption('No'))."</td>"
				//."<td>".translate_yesno($db->f("configure"),get_caption('Yes'),get_caption('No'))."</td>"
				."<td>".translate_yesno($db->f("content"),get_caption('Yes'),get_caption('No'))."</td>"
				."<td>".translate_yesno($db->f("settings"),get_caption('Yes'),get_caption('No'))."</td>"
				."<td>".translate_yesno($db->f("permissions"),get_caption('Yes'),get_caption('No'))."</td>"
				."<td>".translate_yesno($db->f("tools"),get_caption('Yes'),get_caption('No'))."</td>"
				."<td>".translate_yesno($db->f("demo"),get_caption('Yes'),get_caption('No'))."</td>"
				."<td>"
				.$ac->create_link("index.php?mode=user&page=groups&action=edit&gid=",$db->f("gid"),get_caption('EditText'),"edit",get_caption('Edit'))
				.$ac->create_link("index.php?mode=user&page=groups&action=del&gid=",$db->f("gid"),get_caption('Del'),"delete",get_caption('Delete'))
				."</td>"
				."</tr>";
		endwhile;
		$user_groups .= "</table>";

		// Set variables
		$tpl->set_var(array(
			"user_title"    => "<h2>".get_caption('Groups')." - ".get_caption('Security')."</h2>",
			"user_groups"     => $user_groups,
			"user_groups_new" => "<p><a class='edit' href='index.php?mode=user&page=groups&action=new' title='".get_caption('GroupAdd')."'><img src='images/icon_add.gif' alt='".get_caption('GroupAdd')."' border='0' width='16' height='16' /></a></p>"
			));
	break;
}
?>