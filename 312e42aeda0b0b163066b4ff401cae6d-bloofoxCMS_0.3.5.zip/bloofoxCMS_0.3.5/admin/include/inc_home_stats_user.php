<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - admin/stat_user.php -
//
// Copyrights (c) 2006-2009 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

// Forbid direct call
if(!defined('SYS_INDEX')) {
	die("You can't call this file directly!");
}

$result1 = $db->query("SELECT pid FROM ".$tbl_prefix."sys_profile WHERE gender = '0'");
$total1 = $db->num_rows();

$result2 = $db->query("SELECT pid FROM ".$tbl_prefix."sys_profile WHERE gender = '1'");
$total2 = $db->num_rows();

$result3 = $db->query("SELECT uid FROM ".$tbl_prefix."sys_user WHERE deleted = '1'");
$total3 = $db->num_rows();

$result4 = $db->query("SELECT uid FROM ".$tbl_prefix."sys_user WHERE blocked = '1'");
$total4 = $db->num_rows();

$result5 = $db->query("SELECT uid FROM ".$tbl_prefix."sys_user WHERE status = '1'");
$total5 = $db->num_rows();

$result6 = $db->query("SELECT uid FROM ".$tbl_prefix."sys_user");
$total6 = $db->num_rows();

$result7 = $db->query("SELECT gid FROM ".$tbl_prefix."sys_usergroup");
$total7 = $db->num_rows();

$total_all = $total1 + $total2 + $total3 + $total4 + $total5 + $total6 + $total7;

$home_stat_user = "<p class='bold'>".get_caption('User')."</p>";
$home_stat_user .= "<table border='0' width='300'>";
// 1
$home_stat_user .= "<tr class='bg_color2'>";
$home_stat_user .= "<td>".get_caption('GenderMale')."</td>";
$home_stat_user .= "<td>".$total1."</td>";
if($total_all != 0) {
	$total1 = round($total1 / $total_all * 100);
}
$home_stat_user .= "<td><img src='images/stats.gif' width='".$total1."' height='10' /></td>";
$home_stat_user .= "</tr>";
// 2
$home_stat_user .= "<tr class='bg_color2'>";
$home_stat_user .= "<td>".get_caption('GenderFemale')."</td>";
$home_stat_user .= "<td>".$total2."</td>";
if($total_all != 0) {
	$total2 = round($total2 / $total_all * 100);
}
$home_stat_user .= "<td><img src='images/stats.gif' width='".$total2."' height='10' /></td>";
$home_stat_user .= "</tr>";
// 3
$home_stat_user .= "<tr class='bg_color2'>";
$home_stat_user .= "<td>".get_caption('Deleted')."</td>";
$home_stat_user .= "<td>".$total3."</td>";
if($total_all != 0) {
	$total3 = round($total3 / $total_all * 100);
}
$home_stat_user .= "<td><img src='images/stats.gif' width='".$total3."' height='10' /></td>";
$home_stat_user .= "</tr>";
// 4
$home_stat_user .= "<tr class='bg_color2'>";
$home_stat_user .= "<td>".get_caption('Blocked')."</td>";
$home_stat_user .= "<td>".$total4."</td>";
if($total_all != 0) {
	$total4 = round($total4 / $total_all * 100);
}
$home_stat_user .= "<td><img src='images/stats.gif' width='".$total4."' height='10' /></td>";
$home_stat_user .= "</tr>";
// 5
$home_stat_user .= "<tr class='bg_color2'>";
$home_stat_user .= "<td>".get_caption('Active')."</td>";
$home_stat_user .= "<td>".$total5."</td>";
if($total_all != 0) {
	$total5 = round($total5 / $total_all * 100);
}
$home_stat_user .= "<td><img src='images/stats.gif' width='".$total5."' height='10' /></td>";
$home_stat_user .= "</tr>";
// 6
$home_stat_user .= "<tr class='bg_color2'>";
$home_stat_user .= "<td>".get_caption('All')."</td>";
$home_stat_user .= "<td>".$total6."</td>";
if($total_all != 0) {
	$total6 = round($total6 / $total_all * 100);
}
$home_stat_user .= "<td><img src='images/stats.gif' width='".$total6."' height='10' /></td>";
$home_stat_user .= "</tr>";
// 7
$home_stat_user .= "<tr class='bg_color2'>";
$home_stat_user .= "<td>".get_caption('Groups')."</td>";
$home_stat_user .= "<td>".$total7."</td>";
if($total_all != 0) {
	$total7 = round($total7 / $total_all * 100);
}
$home_stat_user .= "<td><img src='images/stats.gif' width='".$total7."' height='10' /></td>";
$home_stat_user .= "</tr>";

$home_stat_user .= "</table>";

?>