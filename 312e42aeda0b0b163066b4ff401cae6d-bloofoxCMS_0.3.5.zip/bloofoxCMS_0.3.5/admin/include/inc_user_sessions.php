<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - admin/inc_user_sessions.php -
//
// Copyrights (c) 2006-2008 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

// Forbid direct call
if(!defined('SYS_INDEX')) {
	die("You can't call this file directly!");
}

switch($action)
{
	case 'kill':
		// Create sessions view
		if(isset($_POST['send']) && $sys_group_vars['demo'] == 0 && $sys_rights['user_sessions']['delete'] == 1) {
			$db->query("UPDATE ".$tbl_prefix."sys_session SET type = 1 WHERE sid = '".$_POST['sid']."' LIMIT 1");
			load_url("index.php?mode=user&page=sessions");
		}
		
		// select record
		if(isset($_POST['sid'])) {
			$_GET['sid'] = $_POST['sid'];
		}
		$db->query("SELECT * FROM ".$tbl_prefix."sys_session WHERE sid = '".$_GET['sid']."' ORDER BY sid LIMIT 1");
		while($db->next_record()):
			$sid = $db->f("sid");
		endwhile;
		
		// Set variables
		$tpl->set_var(array(
			"user_title"       => "<h2>".get_caption('KillSession')." - ".get_caption('Security')."</h2>",
			"user_action"      => "index.php?mode=user&page=sessions&action=kill",
			"user_question"    => "<p>".get_caption('DeleteQuestion')."</p>",
			"user_name"        => "<p class='bold'>".$sid."</p>",
			"user_sid"         => "<input type='hidden' name='sid' value='".$sid."' />",
			"user_button_send" => "<input class='btn' type='submit' name='send' value='".get_caption('KillSession')."' />"
			));
	break;

	default:
		// Create sessions view
		
		// Headline
		$user_sessions .= "<table><tr class='bg_color3'>"
			."<td><p class='bold'>".get_caption('Type')."</p></td>"
			."<td><p class='bold'>".get_caption('Username')."</p></td>"
			."<td><p class='bold'>".get_caption('Date')."</p></td>"
			."<td><p class='bold'>".get_caption('Time')."</p></td>"
			."<td><p class='bold'>".get_caption('Status')."</p></td>"
			."<td><p class='bold'>".get_caption('Timestamp')."</p></td>"
			."<td><p class='bold'>".get_caption('IP')."</p></td>"
			."<td><p class='bold'>".get_caption('MySession')."</p></td>"
			."<td><p class='bold'>".get_caption('Action')."</p></td>"
			."</tr>";
		
		// settings
		$start = $_GET['start'];
		$start = (isset($start)) ? abs((int)$start) : 0;
		$limit = 30;
		
		$db->query("SELECT sid FROM ".$tbl_prefix."sys_session");
		$total = $db->num_rows();
		$start = ($start > $total) ? $total - $limit : $start;

		// Lines
		$db->query("SELECT * FROM ".$tbl_prefix."sys_user INNER JOIN ".$tbl_prefix."sys_session ON ".$tbl_prefix."sys_session.uid = ".$tbl_prefix."sys_user.uid ORDER BY ".$tbl_prefix."sys_session.sid DESC LIMIT ".$start.",".$limit);
		while($db->next_record()):
			$own_session = 0;
			if($_SESSION['uid'] == $db->f("uid") && $db->f("type") == 0 && session_id() == $db->f("session_id")) {
				$own_session = 1;
			}
			if($db->f("type") == 0) {
				$type = get_caption('TypeOpen');
			} else {
				$type = get_caption('TypeClosed');
			}
			if($db->f("status") == 0) {
				$status = get_caption('StatusFailed');
			} else {
				$status = get_caption('StatusOK');
			}
			if($sys_group_vars['demo'] == 0) {
				$show_ip = $db->f("ip");
			} else {
				$show_ip = "***";
			}
			
			$user_sessions .= "<tr class='bg_color2'>"
				."<td>".$type."</td>"
				."<td>".$db->f("username")."</td>"
				."<td>".$db->f("date")."</td>"
				."<td>".$db->f("time")."</td>"
				."<td>".$status."</td>"
				."<td>".$db->f("timestamp")."</td>"
				."<td>".$show_ip."</td>"
				."<td>".translate_yesno($own_session,get_caption('Yes'),get_caption('No'))."</td>"
				."<td>";
			if($db->f("type") == 0) {
				$user_sessions .= $ac->create_link("index.php?mode=user&page=sessions&action=kill&sid=",$db->f("sid"),get_caption('KillSession'),"delete",get_caption('IcoExit'));
			}	
			$user_sessions .= "</td>"
				."</tr>";
		endwhile;
		$user_sessions .= "</table>";
		
		if($start > 0) {
			$prev = ($start - $limit < 0) ? 0 : ($start - $limit);
			$user_nextpage = "<a href='index.php?mode=user&page=sessions&start=".$prev."'>".get_caption('Prev')."</a>";
		}
		
		if($start + $limit < $total) {
			$next = $start + $limit;
			$user_nextpage .= " <a href='index.php?mode=user&page=sessions&start=".$next."'>".get_caption('Next')."</a>";
		}
		
		// Set variables
		$tpl->set_var(array(
			"user_title"     => "<h2>".get_caption('Sessions')." - ".get_caption('Security')."</h2>",
			"user_sessions"  => $user_sessions,
			"user_nextpage"  => $user_nextpage
			));
	break;
}
?>