<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - admin/inc_settings_charset.php -
//
// Copyrights (c) 2006-2008 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

// Forbid direct call
if(!defined('SYS_INDEX')) {
	die("You can't call this file directly!");
}

switch($action)
{
	case 'new':
		if(isset($_POST['send']) && $sys_group_vars['demo'] == 0 && $sys_rights['set_charsets']['write'] == 1) {
			if(mandatory_field($_POST['name'])) {
				$db->query("INSERT INTO ".$tbl_prefix."sys_charset (`cid`,`name`,`description`) VALUES ('','".$_POST['name']."','".$_POST['description']."')");
			}
			load_url("index.php?mode=settings&page=charset");
		}
		
		// Set variables
		$tpl->set_var(array(
			"settings_title"      => "<h2>".get_caption('CharsetAdd')." - ".get_caption('Administration')."</h2>",
			"tab_general"         => get_caption('General'),
			"charset_action"      => "index.php?mode=settings&page=charset&action=new",
			"charset_error"       => $error,
			"charset_name"        => get_caption('Name'),
			"charset_name_input"  => "<input type='text' name='name' size='30' maxlength='30' />",
			"charset_desc"        => get_caption('Description'),
			"charset_desc_input"  => "<input type='text' name='description' size='50' maxlength='50' />",
			"charset_button_send" => "<input class='btn' type='submit' name='send' value='".get_caption('CharsetAdd')."' />"
			));
	break;
	
	case 'edit':
		if(isset($_POST['send']) && $sys_group_vars['demo'] == 0 && $sys_rights['set_charsets']['write'] == 1) {
			if(mandatory_field($_POST['name'])) {
				$db->query("UPDATE ".$tbl_prefix."sys_charset SET name = '".$_POST['name']."' WHERE cid = '".$_POST['cid']."' LIMIT 1");
				$db->query("UPDATE ".$tbl_prefix."sys_charset SET description = '".$_POST['description']."' WHERE cid = '".$_POST['cid']."' LIMIT 1");
			}
			load_url("index.php?mode=settings&page=charset");
		}
		
		// select record
		if(isset($_POST['cid'])) {
			$_GET['cid'] = $_POST['cid'];
		}
		$db->query("SELECT * FROM ".$tbl_prefix."sys_charset WHERE cid = '".$_GET['cid']."' ORDER BY cid LIMIT 1");
		while($db->next_record()):
			$cid = $db->f("cid");
			$name = $db->f("name");
			$description = $db->f("description");
		endwhile;
		
		// Set variables
		$tpl->set_var(array(
			"settings_title"      => "<h2>".get_caption('CharsetEdit')." - ".get_caption('Administration')."</h2>",
			"tab_general"         => get_caption('General'),
			"charset_action"      => "index.php?mode=settings&page=charset&action=edit",
			"charset_error"       => $error,
			"charset_name"        => get_caption('Name'),
			"charset_name_input"  => "<input type='text' name='name' size='30' maxlength='250' value='".$name."' />",
			"charset_desc"        => get_caption('Description'),
			"charset_desc_input"  => "<input type='text' name='description' size='50' maxlength='50' value='".$description."' />",
			"charset_cid"         => "<input type='hidden' name='cid' value='".$cid."' />",
			"charset_button_send" => "<input class='btn' type='submit' name='send' value='".get_caption('SaveChanges')."' />"
			));
	break;
	
	case 'del':
		if(isset($_POST['send']) && $sys_group_vars['demo'] == 0 && $sys_rights['set_charsets']['delete'] == 1) {
			$db->query("DELETE FROM ".$tbl_prefix."sys_charset WHERE cid = '".$_POST['cid']."' LIMIT 1");
			load_url("index.php?mode=settings&page=charset");
		}
		
		// select record
		if(isset($_POST['cid'])) {
			$_GET['cid'] = $_POST['cid'];
		}
		$db->query("SELECT * FROM ".$tbl_prefix."sys_charset WHERE cid = '".$_GET['cid']."' ORDER BY cid LIMIT 1");
		while($db->next_record()):
			$cid = $db->f("cid");
			$name = $db->f("name");
		endwhile;
		
		// Set variables
		$tpl->set_var(array(
			"settings_title"      => "<h2>".get_caption('CharsetDelete')." - ".get_caption('Administration')."</h2>",
			"charset_action"      => "index.php?mode=settings&page=charset&action=del",
			"charset_question"    => "<p>".get_caption('DeleteQuestion')."</p>",
			"charset_name"        => "<p class='bold'>".$name."</p>",
			"charset_cid"         => "<input type='hidden' name='cid' value='".$cid."' />",
			"charset_button_send" => "<input class='btn' type='submit' name='send' value='".get_caption('CharsetDelete')."' />"
			));
	break;
	
	default:
		$settings_charset = "<table><tr class='bg_color3'>"
			."<td><p class='bold'>".get_caption('Name')."</p></td>"
			."<td><p class='bold'>".get_caption('Description')."</p></td>"
			."<td><p class='bold'>".get_caption('Action')."</p></td></tr>";
			
		$db->query("SELECT * FROM ".$tbl_prefix."sys_charset ORDER BY name");
		while($db->next_record()):
			$settings_charset .= "<tr class='bg_color2'><td>".$db->f("name")."</td>"
				."<td>".$db->f("description")."</td>"
				."<td>"
				.$ac->create_link("index.php?mode=settings&page=charset&action=edit&cid=",$db->f("cid"),get_caption('EditText'),"edit",get_caption('Edit'))
				.$ac->create_link("index.php?mode=settings&page=charset&action=del&cid=",$db->f("cid"),get_caption('Del'),"delete",get_caption('Delete'))
				."</td></tr>";
		endwhile;
		$settings_charset .= "</table>";
		
		// Set variables
		$tpl->set_var(array(
			"settings_title"       => "<h2>".get_caption('Charset')." - ".get_caption('Administration')."</h2>",
			"settings_charset"     => $settings_charset,
			"settings_charset_new" => "<p><a class='edit' href='index.php?mode=settings&page=charset&action=new' title='".get_caption('CharsetAdd')."'><img src='images/icon_add.gif' alt='".get_caption('CharsetAdd')."' border='0' width='16' height='16' /></a></p>"
			));
	break;
}
?>