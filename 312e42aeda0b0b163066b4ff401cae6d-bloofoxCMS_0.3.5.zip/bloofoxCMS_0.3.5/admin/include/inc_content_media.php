<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - admin/inc_content_media.php -
//
// Copyrights (c) 2006-2008 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

// Forbid direct call
if(!defined('SYS_INDEX')) {
	die("You can't call this file directly!");
}

// init filter class
$filters = new filter();

switch($action)
{
	case 'new':
		if(isset($_POST['send']) && $sys_group_vars['demo'] == 0 && $sys_rights['content_media']['write'] == 1) {
			if(!mandatory_field($_FILES["filename"]["name"]) && $error == "") { $error = "<p class='error'>".get_caption('ErrorFile')."</p>"; }
			
			if($_POST['media_type'] == 0 && $error == "") {
				if(file_exists($path_to_files_folder.$_FILES["filename"]["name"])) {
					$error = "<p class='error'>".get_caption('ErrorFileExist')."</p>";
				} else {
					if(!upload_file($path_to_files_folder)) { $error = "<p class='error'>".get_caption('ErrorWritePermission')."</p>"; }
				}
			} 
			if($_POST['media_type'] == 1 && $error == "") {
				if(file_exists($path_to_image_folder.$_FILES["filename"]["name"])) {
					$error = "<p class='error'>".get_caption('ErrorFileExist')."</p>";
				} else {
					if(!upload_file($path_to_image_folder)) { $error = "<p class='error'>".get_caption('ErrorWritePermission')."</p>"; }
				}
			}
			
			if($error == "") {
				load_url("index.php?mode=content&page=media");
			}
		} else {
			if(!upload_file($path_to_files_folder)) { $error = "<p class='error'>".get_caption('ErrorWritePermission')." (".$path_to_files_folder.")</p>"; }
			if(!upload_file($path_to_image_folder)) { $error .= "<p class='error'>".get_caption('ErrorWritePermission')." (".$path_to_image_folder.")</p>"; }
		}
		
		// Set variables
		$tpl->set_var(array(
			"settings_title"    => "<h2>".get_caption('MediafileAdd')." - ".get_caption('Contents')."</h2>",
			"tab_general"       => get_caption('General'),
			"media_action"      => "index.php?mode=content&page=media&action=new",
			"media_error"       => $error,
			"media_filename"    => get_caption('File'),
			"media_filename_input" => "<input type='file' name='filename' size='30' maxlength='250' />",
			"media_type"        => get_caption('Type'),
			"media_type_input"  => "<select name='media_type'><option value='0'>".get_caption('File')."</option><option value='1'>".get_caption('Image')."</option></select>",
			"media_button_send"  => "<input class='btn' type='submit' name='send' value='".get_caption('MediafileAdd')."' />"
			));
	break;
	
	case 'edit':
		if(isset($_POST['send']) && $sys_group_vars['demo'] == 0 && $sys_rights['content_media']['write'] == 1) {
								
			if(mandatory_field($_FILES["filename"]["name"])) {
				// upload file
				if($_POST['media_type'] == 0) {
					if(!upload_file($path_to_files_folder)) { $error = "<p class='error'>".get_caption('ErrorWritePermission')."</p>"; }
				} else {
					if(!upload_file($path_to_image_folder)) { $error = "<p class='error'>".get_caption('ErrorWritePermission')."</p>"; }
				}
				
				if($_POST['media_type'] != $_POST['media_type_old']) {
					if($_POST['media_type_old'] == 0) {
						delete_file($_POST['media_file'],$path_to_files_folder);
					} else {
						delete_file($_POST['media_file'],$path_to_image_folder);
					}
				}
			}
			
			if(!mandatory_field($_FILES["filename"]["name"])) {
				if($_POST['media_type'] != $_POST['media_type_old']) {
					if($_POST['media_type_old'] == 0) {
						@copy($path_to_files_folder.$_POST['media_file'],$path_to_image_folder.$_POST['media_file']);
						delete_file($_POST['media_file'],$path_to_files_folder);
					} else {
						@copy($path_to_image_folder.$_POST['media_file'],$path_to_files_folder.$_POST['media_file']);
						delete_file($_POST['media_file'],$path_to_image_folder);
					}
				}
			}
			
			if($error == "") {
				load_url("index.php?mode=content&page=media");
			}
		}
		
		// select record
		$filename = $_GET["file"];
		$type = mark_selected_value($_GET["type"]);
		$media_type = $_GET["type"];
		
		// Set variables
		$tpl->set_var(array(
			"settings_title"    => "<h2>".get_caption('MediafileEdit')." - ".get_caption('Contents')."</h2>",
			"tab_general"       => get_caption('General'),
			"media_action"      => "index.php?mode=content&page=media&action=edit",
			"media_error"       => $error,
			"media_filename"    => get_caption('File'),
			"media_filename_input" => $filename."<br /><input type='file' name='filename' size='30' maxlength='250' />",
			"media_type"        => get_caption('Type'),
			"media_type_input"  => "<select name='media_type'><option value='0' ".$type['1'].">".get_caption('File')."</option><option value='1' ".$type['2'].">".get_caption('Image')."</option></select>",
			"media_file"        => "<input type='hidden' name='media_file' value='".$filename."' />",
			"media_type_old"    => "<input type='hidden' name='media_type_old' value='".$media_type."' />",
			"media_button_send" => "<input class='btn' type='submit' name='send' value='".get_caption('SaveChanges')."' />"
			));
	break;
	
	case 'del':
		if(isset($_POST['send']) && $sys_group_vars['demo'] == 0 && $sys_rights['content_media']['delete'] == 1) {
			if($_POST['media_type'] == 0) {
				delete_file($_POST['media_file'],$path_to_files_folder);
			} else {
				delete_file($_POST['media_file'],$path_to_image_folder);
			}
			load_url("index.php?mode=content&page=media");
		}
		
		// select record
		$media_type = $_GET["type"];
		$filename = $_GET["file"];
		
		// Set variables
		$tpl->set_var(array(
			"settings_title"    => "<h2>".get_caption('MediafileDelete')." - ".get_caption('Contents')."</h2>",
			"media_action"      => "index.php?mode=content&page=media&action=del",
			"media_question"    => "<p>".get_caption('DeleteQuestion')."</p>",
			"media_filename"    => "<p class='bold'>".$filename."</p>",
			"media_file"        => "<input type='hidden' name='media_file' value='".$filename."' />",
			"media_type"        => "<input type='hidden' name='media_type' value='".$media_type."' />",
			"media_button_send" => "<input class='btn' type='submit' name='send' value='".get_caption('MediafileDelete')."' />"
			));
	break;
	
	default:
		// Create media overview
		
		// Filter
		if(isset($_POST["send"])) {
			if($_POST["filter_media"] == "") {
				$_SESSION["filter_media"] = "%";
			} else {
				$_SESSION["filter_media"] = $_POST["filter_media"];
			}
			load_url("index.php?mode=content&page=media");
		}

		$media_filter = $filters->create_filter_media($db);
		
		// Headline
		$settings_media .= "<table><tr class='bg_color3'>"
			."<td><p class='bold'>".get_caption('Type')."</p></td>"
			."<td><p class='bold'>".get_caption('File')."</p></td>"
			."<td><p class='bold'>".get_caption('FileSize')."</p></td>"
			."<td><p class='bold'>".get_caption('Dimension')."</p></td>"
			."<td><p class='bold'>".get_caption('ChangedAt')."</p></td>"
			."<td><p class='bold'>".get_caption('Action')."</p></td>"
			."</tr>";
		
		// Lines
		if(!isset($_SESSION["filter_media"])) {
			$_SESSION["filter_media"] = "%";
		}
		
		// Read dir
		function get_mediacenter($folder)
		{
			$dir=opendir($folder);
			$dir_list = array();

			while($file = readdir($dir))
			{
				if($file != "." && $file != ".." && $file != "index.htm" && !is_dir($folder.$file))
				{
					array_push($dir_list,$file);
				}
			}

			closedir($dir);
			
			return($dir_list);
		}
		
		if($_SESSION["filter_media"] == 0 || $_SESSION["filter_media"] == "%") {
			$array_files = get_mediacenter($path_to_files_folder);
			asort($array_files);
			
			while(list($key,$val) = each($array_files))
			{
				$path = $path_to_files_folder;
				
				$settings_media .= "<tr class='bg_color2'>"
					."<td>".get_caption("File")."</td>"
					."<td><a href='".$path.$val."' target='_blank'>".$val."</a></td>";
					if(file_exists($path.$val)) {
						$settings_media .= "<td>".round(filesize($path.$val)/1024,2)." KByte</td>";
						$settings_media .= "<td></td>";
						$settings_media .= "<td>".date($sys_vars['datetime'], filemtime($path.$val))."</td>";
					} else {
						$settings_media .= "<td>0 KByte</td>";
						$settings_media .= "<td></td>";
						$settings_media .= "<td></td>";
					}
				$settings_media .= "<td>"
					."<a href='index.php?mode=content&page=media&action=edit&file=".$val."&type=0' title='".get_caption('EditText')."' class='edit'>".get_caption('Edit')."</a> "
					."<a href='index.php?mode=content&page=media&action=del&file=".$val."&type=0' title='".get_caption('DeleteText')."' class='delete'>".get_caption('Delete')."</a>"
					."</td>"
					."</tr>";
			}
		}
		
		if($_SESSION["filter_media"] == 1 || $_SESSION["filter_media"] == "%") {
			$array_images = get_mediacenter($path_to_image_folder);
			asort($array_images);
			
			while(list($key,$val) = each($array_images))
			{
				$path = $path_to_image_folder;
				
				$settings_media .= "<tr class='bg_color2'>"
					."<td>".get_caption("Image")."</td>"
					."<td><a href='".$path.$val."' target='_blank'>".$val."</a></td>";
					if(file_exists($path.$val)) {
						$settings_media .= "<td>".round(filesize($path.$val)/1024,2)." KByte</td>";
						$imgsize = getimagesize($path.$val);
						$settings_media .= "<td>".$imgsize[0]."x".$imgsize[1]."</td>";
						$settings_media .= "<td>".date($sys_vars['datetime'], filemtime($path.$val))."</td>";
					} else {
						$settings_media .= "<td>0 KByte</td>";
						$settings_media .= "<td>0x0</td>";
						$settings_media .= "<td></td>";
					}
				
				$settings_media .= "<td>"
					."<a href='index.php?mode=content&page=media&action=edit&file=".$val."&type=1' title='".get_caption('EditText')."' class='edit'>".get_caption('Edit')."</a> "
					."<a href='index.php?mode=content&page=media&action=del&file=".$val."&type=1' title='".get_caption('DeleteText')."' class='delete'>".get_caption('Delete')."</a>"
					."</td>"
					."</tr>";
			}
		}
		
		$settings_media .= "</table>";

		// Set variables
		$tpl->set_var(array(
			"settings_title"        => "<h2>".get_caption('Mediacenter')." - ".get_caption('Contents')."</h2>",
			"settings_media_new"    => "<p><a class='edit' href='index.php?mode=content&page=media&action=new' title='".get_caption('FileAdd')."'><img src='images/icon_add.gif' alt='".get_caption('FileAdd')."' border='0' width='16' height='16' /></a></p>",
			"settings_media"        => $settings_media,
			"settings_media_filter" => $media_filter
			));
	break;
}
?>