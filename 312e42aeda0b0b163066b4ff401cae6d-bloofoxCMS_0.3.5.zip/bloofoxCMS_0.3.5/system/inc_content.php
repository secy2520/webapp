<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - system/inc_content.php -
//
// Copyrights (c) 2006 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

// Forbid direct call
if(!defined('SYS_INDEX')) {
	die("You can't call this file directly!");
}

// this code is included in index.php
switch($login_required)
{
	case '1': // Login required
		$db->query("SELECT eid,name FROM ".$tbl_prefix."sys_explorer WHERE link_type = '3' && link_plugin = '15' && config_id = '".$sys_explorer_vars['config_id']."' LIMIT 1");
		while($db->next_record()):
			$sys_vars['login_register'] = "<p class='small'><a href='".create_url($db->f("eid"),$db->f("name"),$sys_config_vars['mod_rewrite'])."'>".$db->f("name")."</a></p>";
		endwhile;
		
		$sys_vars['body_tag'] = "onLoad=\"focus_user()\"";
	
		// set template block
		$tpl->set_block("template_content", "content", "content_handle");

		$tpl->set_var(array(
			"login_title"    => $cont->title,
			"login_action"   => $cont->action,
			"login_user"     => $cont->user,
			"login_pass"     => $cont->pass,
			"login_error"    => $cont->error,
			"login_register" => $sys_vars['login_register']
		));

		// parse template
		$tpl->parse("content_handle", "content", true);
	break;
	
	default: // Select articles for page
		if(!isset($_GET['cid'])) {
			// create page handling
			$sys_vars = $cont->create_pages($db,$_GET['start'],$sys_vars);

			// get all sys_contents
			$db->query("SELECT * FROM ".$tbl_prefix."sys_content WHERE explorer_id = '".$cont->eid."' AND blocked = '0' ORDER BY sorting LIMIT ".$sys_vars['start'].",".$cont->limit."");
		} else {
			// get single sys_content
			$db->query("SELECT * FROM ".$tbl_prefix."sys_content WHERE cid = '".$_GET['cid']."' AND blocked = '0' LIMIT 1");
		}
		$no_of_records = $db->num_rows();
		
		// set template block
		$tpl->set_block("template_content", "content", "content_handle");
		
		while($db->next_record()):
			$text = $cont->format_text($db->f("text"));
			$title = $db->f("title");
			
			$tpl->set_var(array(
				"title"    => $title,
				"text"     => $text
			));
		
			// parse template
			$tpl->parse("content_handle", "content", true);
		endwhile;
		
		// if no contents were found show this content
		if($no_of_records == 0) {
			$tpl->set_var(array(
				"title"    => get_caption("Notice"),
				"text"     => get_caption("NoticeArticlesNotFound")
			));
				
			// parse template
			$tpl->parse("content_handle", "content", true);
		}
	break;
}
?>