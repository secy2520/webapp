<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - plugins/text_blog/text_blog.php -
//
// Copyrights (c) 2006-2009 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

// check plugin ID
// text_blog must have "30"
if($login_required == 0 && $sys_explorer_vars['link_plugin'] == 30) {
	
	// init db connection
	$db2 = new DB_Tpl();
	
	// create page handling
	$sys_vars = $cont->create_pages($db2,$_GET['start'],$sys_vars);
	
	// set template block
	$tpl->set_block("template_content", "content", "content_handle");

	// get sys_contents
	$db2->query("SELECT * FROM ".$tbl_prefix."sys_content WHERE explorer_id = '".$cont->eid."' AND blocked = '0' ORDER BY sorting LIMIT ".$sys_vars['start'].",".$cont->limit."");
	$no_of_records = $db2->num_rows();
	
	while($db2->next_record()):
		$text = $cont->format_text($db2->f("text"));
		
		if($db2->f("created_at") != "") {
			$write_weekday = date("w",$db2->f("created_at"));
			$write_day = date("d",$db2->f("created_at"));
			$write_month = date("n",$db2->f("created_at"));
			$write_year = date("Y",$db2->f("created_at"));
			$write_time = date("H:i",$db2->f("created_at"));
			$content_written = $days[$write_weekday].", ".$write_day.". ".$months[$write_month]." ".$write_year." (".$write_time.")";
		} else {
			$content_written = "";
		}
		
		$tpl->set_var(array(
			"title"    => "<a name='".$db2->f("cid")."'></a>".$db2->f("title"),
			"text"     => $text,
			"date"     => $content_written,
			"posted"   => get_caption('PostedBy')." ".$db2->f("created_by")
		));
	
		// parse template
		$tpl->parse("content_handle", "content", true);
	endwhile;
	
	// if no contents were found show this content
	if($no_of_records == 0) {
		$tpl->set_var(array(
			"title"    => get_caption('Notice'),
			"text"     => get_caption("NoticeArticlesNotFound"),
			"date"     => "",
			"posted"   => ""
		));
	
		// parse template
		$tpl->parse("content_handle", "content", true);
	}
}
?>