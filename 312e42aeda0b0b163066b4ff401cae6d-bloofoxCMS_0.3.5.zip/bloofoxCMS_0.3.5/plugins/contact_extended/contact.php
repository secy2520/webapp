<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - plugins/contact_extended/contact.php -
//
// Copyrights (c) 2009 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

// check plugin ID
// Contact must have "5"
if($login_required == 0 && $sys_explorer_vars['link_plugin'] == 6) {

	$sys_print_vars['print'] = "";
	$sys_plugin_vars['css'] = "<link rel='stylesheet' type='text/css' href='plugins/contact_extended/contact.css' />\n";
		
	// set template block
	$tpl->set_block("template_content", "content", "content_handle");
	
	switch($contact_vars['get'])
	{
		case '1': // contact message sent
			$tpl->set_var(array(
				"contact_title"       => "<h1>".$sys_explorer_vars['name']."</h1>",
				"contact_message"     => get_caption('ContactMessageSent')
				));
		break;
		
		default: // contact form
		$error = "";
		if(isset($_POST['send'])) {
			// Block external postings
			$HTTP_REFERER = $_SERVER['HTTP_REFERER'];
			if(strpos($HTTP_REFERER,$_SERVER['SERVER_NAME']) == 0) {
				load_url("index.php");
			}
			// Validate input fields
			$_POST['firstname'] = validate_text($_POST['firstname']);
			$_POST['name'] = validate_text($_POST['name']);
			$_POST['company'] = validate_text($_POST['company']);
			$_POST['phone'] = validate_text($_POST['phone']);
			$_POST['address'] = validate_text($_POST['address']);
			$_POST['city'] = validate_text($_POST['city']);
			$_POST['mobile'] = validate_text($_POST['mobile']);
			$_POST['message'] = validate_text($_POST['message']);
			$_POST['email'] = validate_text($_POST['email']);
			$_POST['code'] = validate_text($_POST['code']);
			
			if(!mandatory_field($_POST['name'])) { $error = "<p class='error'>".get_caption('ErrorName')."</p>"; }
			if(!email_is_valid($_POST['email']) && $error == "") { $error = "<p class='error'>".get_caption('ErrorEmailValid')."</p>"; }
			if(!mandatory_field($_POST['phone']) && $error == "") { $error = "<p class='error'>".get_caption('ErrorPhone')."</p>"; }
			if(!mandatory_field($_POST['message']) && $error == "") { $error = "<p class='error'>".get_caption('ErrorMessage')."</p>"; }
			if(($_SESSION["contact"] != $_POST['code'] || !mandatory_field($_POST['code'])) && $error == "") { $error = "<p class='error'>".get_caption('ErrorCaptcha')."</p>"; }
			
			if($error == "") {
				$contact_vars['msg'] = "";
				$contact_vars['msg'] .= "Server-URL: ".$sys_config_vars['url']."\n\n";
				$contact_vars['msg'] .= "Salutation: ".$_POST['title']."\n\n";
				$contact_vars['msg'] .= "First Name: ".$_POST['firstname']."\n\n";
				$contact_vars['msg'] .= "Last Name: ".$_POST['name']."\n\n";
				$contact_vars['msg'] .= "Company: ".$_POST['company']."\n\n";
				$contact_vars['msg'] .= "Phone: ".$_POST['phone']."\n\n";
				$contact_vars['msg'] .= "Mobile: ".$_POST['mobile']."\n\n";
				$contact_vars['msg'] .= "Message: ".$_POST['message']."\n\n";
				$contact_vars['msg'] .= "Email: ".$_POST['email']."\n\n";
				$contact_vars['msg'] .= "Code: ".$_POST['code']."\n\n";
				
				// Parameter: recipient, sender, subject, body, mode (1=html,0=plain)
				send_mail($sys_config_vars['mail'],$_POST['email'],get_caption('ContactSubject'),$contact_vars['msg'],$sys_setting_vars['html_mails']);
				
				load_url("index.php?page=".$sys_explorer_vars['eid']."&sent=1");
			}
		}
		
		if(isset($_POST['title'])) {
			$contact_vars['caption_salut_0'] = get_caption('TitleMrs');
			if($_POST['title'] == $contact_vars['caption_salut_0']) {
				$contact_vars['salut'][0] = "checked='checked'";
				$contact_vars['salut'][1] = "";
			} else {
				$contact_vars['salut'][0] = "";
				$contact_vars['salut'][1] = "checked='checked'";
			}
		}
		
		include("system/class_captcha.php");
		$captcha = new captcha('temp');
		
		$tpl->set_var(array(
			"contact_title"         => "<h1>".$sys_explorer_vars['name']."</h1>",
			"contact_action"        => $_SERVER['REQUEST_URI'],
			"contact_error"         => $error,
			"contact_salutation"       => get_caption('Salutation'),
			"contact_salutation_input" => get_caption('TitleMrs')." <input type='radio' name='title' value='".get_caption('TitleMrs')."' ".$contact_vars['salut'][0]." /> &nbsp;".get_caption('TitleMr')." <input type='radio' name='title' value='".get_caption('TitleMr')."' ".$contact_vars['salut'][1]." />",
			"contact_firstname"        => get_caption('FirstName'),
			"contact_firstname_input"  => "<input class='text' type='text' name='firstname' size='30' maxlength='30' value='".$_POST['firstname']."' />",
			"contact_name"          => get_caption('LastName'),
			"contact_name_input"    => "<input class='text' type='text' name='name' size='30' maxlength='30' value='".$_POST['name']."' />",
			"contact_company"       => get_caption('Company'),
			"contact_company_input" => "<input class='text' type='text' name='company' size='30' maxlength='30' value='".$_POST['company']."' />",
			"contact_address"       => get_caption('Address'),
			"contact_address_input" => "<input class='text' type='text' name='address' size='30' maxlength='30' value='".$_POST['address']."' />",
			"contact_city"       => get_caption('PostCodeCity'),
			"contact_city_input" => "<input class='text' type='text' name='city' size='30' maxlength='50' value='".$_POST['city']."' />",
			"contact_phone"         => get_caption('Phone'),
			"contact_phone_input"   => "<input class='text' type='text' name='phone' size='30' maxlength='30' value='".$_POST['phone']."' />",
			"contact_mobile"        => get_caption('MobilePhone'),
			"contact_mobile_input"  => "<input class='text' type='text' name='mobile' size='30' maxlength='30' value='".$_POST['mobile']."' />",
			"contact_email"         => get_caption('Email'),
			"contact_email_input"   => "<input class='email' type='text' name='email' size='60' maxlength='250' value='".$_POST['email']."' />",
			"contact_message"       => get_caption('Message'),
			"contact_message_input" => "<textarea class='message' name='message' cols='40' rows='5'>".$_POST['message']."</textarea>",
			"contact_captcha"       => get_caption('CaptchaCode'),
			"contact_captcha_image" => "<img class='captcha' src='captcha.php?var=contact' border='0' alt='Captcha' width='".$captcha->get_image_width()."' height='".$captcha->get_image_height()."' />",
			"contact_captcha_input" => "<input class='captcha' type='text' name='code' size='20' />",
			"contact_submit"        => "<input type='submit' name='send' value='".get_caption('MessageSubmit')."' />"
			));
		break;
	}
	// parse template
	$tpl->parse("content_handle", "content", true);
}
?>