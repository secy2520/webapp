<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - plugins/gallery/gallery.php -
//
// Copyrights (c) 2006-2009 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

// check plugin ID
// gallery must have "40"
if($login_required == 0 && $sys_explorer_vars['link_plugin'] == 40) {

	// define css stylesheet for html header
	$sys_plugin_vars['css'] = "<script type=\"text/javascript\" src=\"plugins/gallery/lightbox/js/prototype.js\"></script>\n"
				."<script type=\"text/javascript\" src=\"plugins/gallery/lightbox/js/scriptaculous.js?load=effects\"></script>\n"
				."<script type=\"text/javascript\" src=\"plugins/gallery/lightbox/js/lightbox.js\"></script>\n"
				."<link rel=\"stylesheet\" type=\"text/css\" href=\"plugins/gallery/lightbox/css/lightbox.css\" media=\"screen\" />\n"
				."<link rel=\"stylesheet\" type=\"text/css\" href=\"plugins/gallery/gallery.css\" />\n";
	
	// set template block
	$tpl->set_block("template_content", "content", "content_handle");
	
	switch($gallery_vars['mode'])
	{
		case 'album': // album view
			// get sys_contents
			$db2->query("SELECT * FROM ".$tbl_prefix."sys_content WHERE explorer_id = '".$cont->eid."' && blocked = '0' ORDER BY sorting LIMIT 1");
			$no_of_records = $db2->num_rows();
			
			while($db2->next_record()):
				$text = $cont->format_text($db2->f("text"));
				
				$tpl->set_var(array(
					"album_title"    => $db2->f("title"),
					"album_text"     => $text
				));
			endwhile;
			
			if($no_of_records == 0) {
				$tpl->set_var(array(
					"album_title"    => "",
					"album_text"     => ""
				));
			}
			
			// get underneath albums
			$curr_time = time();
			$db2->query("SELECT * FROM ".$tbl_prefix."sys_explorer WHERE config_id = '".$sys_explorer_vars['config_id']."' "
				."&& link_type = 3 && preid = ".$sys_explorer_vars['eid']." && invisible = '0' && blocked = '0' "
				."&& startdate < '".$curr_time."' && (enddate > '".$curr_time."' || enddate = '') ORDER BY preid,sorting");
			$no_of_records = $db2->num_rows();
			
			// init db connection
			$db3 = new DB_Tpl();
			
			while($db2->next_record()):
				$db3->query("SELECT title,text FROM ".$tbl_prefix."sys_content WHERE explorer_id = ".$db2->f("eid")." ORDER BY sorting LIMIT 1");
				while($db3->next_record()):
					$gallery_title = $db3->f("title");
					$gallery_settings = $db3->f("text");
				endwhile;
				
				// build vars
				$temp_gallery_vars = explode(";",strip_tags($gallery_settings));
				$gallery_vars['dir'] = "media/images";
				
				for($x=0;$x<count($temp_gallery_vars);$x++)
				{
					$temp_var = explode("=",$temp_gallery_vars[$x]);
					$gallery_vars[trim($temp_var[0])] = trim($temp_var[1]);
				}
				
				if(!is_dir(SYS_WORK_DIR."/".$gallery_vars['dir'])) {
					$gallery_vars['dir'] = "media/images";
				}
				// get first image of dir and count
				$image_counter = 0;
				$dir = opendir(SYS_WORK_DIR."/".$gallery_vars['dir']);
				while($file = readdir($dir)) {
					if($file != "." && $file != "..") {
						if(ereg("\.",$file)) {
							$image_counter++;
							if($image_counter == 1) {
								$gallery_image = "<a href='".create_url($db2->f("eid"),$db2->f("name"),$sys_config_vars['mod_rewrite'])."' title='".$gallery_title."'><img src='plugins/gallery/show.php?dir=".$gallery_vars['dir']."&amp;img=".$file."&amp;width=".$gallery_vars['img_width_intro']."' alt='".$gallery_title."' /></a>";
							}
						}
					}
				}
				closedir($dir);
				
				$tpl->set_var(array(
					"gallery_title"    => "<a href='".create_url($db2->f("eid"),$db2->f("name"),$sys_config_vars['mod_rewrite'])."' title='".$gallery_title."'>".$gallery_title."</a>",
					"gallery_image"    => $gallery_image,
					"gallery_size"     => $image_counter." ".get_caption("Pictures")
				));
				
				// parse template
				$tpl->parse("content_handle", "content", true);
			endwhile;
			
			// if no contents were found show this content
			if($no_of_records == 0) {
				//load_url($sys_config_vars['url']);
				$tpl->set_var(array(
					"gallery_title"    => get_caption("Notice"),
					"gallery_image"    => "",
					"gallery_size"     => get_caption("No album found yet!")
				));
				
				// parse template
				$tpl->parse("content_handle", "content", true);
			}
		break;
		
		default: // thumbnails view
			// open dir with pictures
			if(!is_dir(SYS_WORK_DIR."/".$gallery_vars['dir'])) {
				$gallery_vars['dir'] = "media/images";
			}
			
			// create page navigation
			function create_pages($start,$sys_vars,$counter)
			{
				global $sys_explorer_vars,$sys_config_vars,$gallery_vars;
				
				if(empty($gallery_vars['img_limit'])) {
					$gallery_vars['img_limit'] = $counter;
				}
				$sys_vars['limit'] = $gallery_vars['img_limit'];
				$sys_vars['start'] = 0;
				
				$sys_vars['start'] = $start * $sys_vars['limit'] - $sys_vars['limit'];
				if($sys_vars['start'] < 0) { $sys_vars['start'] = 0; }
				
				// count all
				$no_of_records = $counter;
				
				$factor = $no_of_records / $sys_vars['limit'];
				$factor = ceil($factor);
				
				if($factor > 1) {
					$sys_vars['pages'] = "<p><span class='bold'>".get_caption('PageHandling').":</span> ";
					for($x=1; $x<=$factor; $x++) {
						if($start == $x) {
							$sys_vars['pages'] .= "<a href='".create_url($sys_explorer_vars['eid'],$sys_explorer_vars['name'],$sys_config_vars['mod_rewrite'],'','',$x)."'><span class='bold'>".$x."</span></a> ";
						} else {
							$sys_vars['pages'] .= "<a href='".create_url($sys_explorer_vars['eid'],$sys_explorer_vars['name'],$sys_config_vars['mod_rewrite'],'','',$x)."'>".$x."</a> ";
						}
					}
					$sys_vars['pages'] .= "</p>";
				}
				
				return($sys_vars);
			}
			
			// Get image format
			function get_image_type($image)
			{
				if(strstr(strtolower($image), ".gif")) {
					$img_type = "GIF";
					return($img_type);
				}
				if(strstr(strtolower($image), ".jpg") || strstr(strtolower($image), ".jpeg")) {
					$img_type = "JPEG";
					return($img_type);
				}
				if(strstr(strtolower($image), ".png")) {
					$img_type = "PNG";
					return($img_type);
				}
				return(".");
			}
			
			// Search for all pictures in specified directory
			$counter = 0;
			if(empty($gallery_vars['img_limit'])) {
				$no_limit = 1;
			} else {
				$upper_limit = $_GET['start'] * $gallery_vars['img_limit'];
				$lower_limit = $_GET['start'] * $gallery_vars['img_limit'] - $gallery_vars['img_limit'];
			}
			$dir = opendir(SYS_WORK_DIR."/".$gallery_vars['dir']);
			while($file = readdir($dir)) {
				if($file != "." && $file != ".." && get_image_type($file) != ".") {
					if(ereg("\.",$file)) {
						if(empty($gallery_vars[$file])) {
							$gallery_vars[$file] = $file;
						}
						if($no_limit != 1) {
							if($counter >= $lower_limit && $counter < $upper_limit) {
								// while picture set template var
								$tpl->set_var(array(
									"album_title" => $gallery_vars['title'],
									"album_image" => "<a rel='lightbox[group]' href='plugins/gallery/show.php?dir=".$gallery_vars['dir']."&amp;img=".$file."&amp;width=".$gallery_vars['img_width_large']."' title='".$gallery_vars[$file]."'><img src='plugins/gallery/show.php?dir=".$gallery_vars['dir']."&amp;img=".$file."&amp;width=".$gallery_vars['img_width']."' alt='".$file."' /></a>"
								));
								
								// parse template
								$tpl->parse("content_handle", "content", true);
							}
						} else {
							// while picture set template var
							$tpl->set_var(array(
								"album_title" => $gallery_vars['title'],
								"album_image" => "<a rel='lightbox[group]' href='plugins/gallery/show.php?dir=".$gallery_vars['dir']."&amp;img=".$file."&amp;width=".$gallery_vars['img_width_large']."' title='".$gallery_vars[$file]."'><img src='plugins/gallery/show.php?dir=".$gallery_vars['dir']."&amp;img=".$file."&amp;width=".$gallery_vars['img_width']."' alt='".$file."' /></a>"
							));
							
							// parse template
							$tpl->parse("content_handle", "content", true);
						}
						
						// count images
						$counter++;
					}
			    }
			}
			closedir($dir);
			
			// create page handling
			$sys_vars = create_pages($_GET['start'],$sys_vars,$counter);
		break;
	}
}
?>