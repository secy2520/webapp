<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - plugins/gallery/show.php -
//
// Copyrights (c) 2006 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

// Block external linkings
$HTTP_REFERER = $_SERVER['HTTP_REFERER'];
if(strpos($HTTP_REFERER,$_SERVER['SERVER_NAME']) == 0) {
	die("Forget It!");
}

// load functions lib
define ('SYS_INDEX', 1);
require_once("../../functions.php");
$_GET['dir'] = validate_text($_GET['dir']);
$_GET['img'] = validate_text($_GET['img']);

if(CheckInteger($_GET['width']) == FALSE) {
	$_GET['width'] = 480;
}

// Path to image
$path_to_image = "../../".$_GET['dir']."/".$_GET['img'];

// Get image format
function get_image_type($image)
{
	if(strstr(strtolower($image), ".gif")) {
		$img_type = "GIF";
	}
	if(strstr(strtolower($image), ".jpg") || strstr(strtolower($image), ".jpeg")) {
		$img_type = "JPEG";
	}
	if(strstr(strtolower($image), ".png")) {
		$img_type = "PNG";
	}
	return($img_type);
}

// Image handling for gallery
$img_type = get_image_type($_GET['img']);
switch($img_type)
{
	case 'GIF':
		header("Content-type:image/gif");
		$im = @ImageCreateFromGIF($path_to_image); // open file
	break;
	
	case 'PNG':
		header("Content-type:image/png");
		$im = @ImageCreateFromPNG($path_to_image); // open file
	break;
	
	default: // JPEG
		header("Content-type:image/jpeg");
		$im = @ImageCreateFromJPEG($path_to_image); // open file
	break;
}

if(!$im) { // if no image then create empty image with error
	$im = ImageCreate(120, 90);
	$bgc = ImageColorAllocate($im, 255, 255, 255);
	$tc = ImageColorAllocate($im, 0, 0, 0);
	ImageFilledRectangle($im, 0, 0, 120, 90, $bgc);
	ImageString($im, 3, 5, 5, "Error: cannot open file", $tc);
} else {
	// Original size
	$img_size = GetImageSize($path_to_image);

	// Calculate thumb size
	$thumb_size = $_GET['width'];
	
	$new_width = $thumb_size;
	$new_wp = (100 * $new_width) / $img_size[0];
	$new_height = ($img_size[1] * $new_wp) / 100;

	$new_image = imagecreatetruecolor($new_width, $new_height);
	ImageCopyResized($new_image, $im, 0, 0, 0, 0, $new_width, $new_height, $img_size[0], $img_size[1]);

	switch($img_type)
	{
		case 'GIF':
			ImageGIF($new_image);
		break;
		
		case 'PNG':
			ImagePNG($new_image);
		break;
		
		default: // JPEG
			ImageJPEG($new_image);
		break;
	}
}
imagedestroy($new_image);
?>