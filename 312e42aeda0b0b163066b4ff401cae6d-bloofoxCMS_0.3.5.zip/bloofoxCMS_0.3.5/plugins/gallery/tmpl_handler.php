<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - plugins/gallery/tmpl_handler.php -
//
// Copyrights (c) 2006-2007 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

// init db connection
$db2 = new DB_Tpl();

// get sys_content with settings
$db2->query("SELECT * FROM ".$tbl_prefix."sys_content WHERE explorer_id = '".$cont->eid."' && blocked = '1' ORDER BY sorting LIMIT 1");

// init default vars
$gallery_vars['dir'] = "media/images";
$gallery_vars['img_width'] = 120;
$gallery_vars['img_width_big'] = 480;
$gallery_vars['img_width_intro'] = 160;

while($db2->next_record()):
	$gallery_vars['title'] = $db2->f("title");
	$temp_gallery_vars = explode(";",strip_tags($db2->f("text")));
endwhile;
	
// create gallery_vars from temp_gallery_vars
if(!empty($temp_gallery_vars)) {
	for($x=0;$x<count($temp_gallery_vars);$x++)
	{
		$temp_var = explode("=",$temp_gallery_vars[$x]);
		$gallery_vars[trim($temp_var[0])] = trim($temp_var[1]);
	}
}

// choose template file
switch($gallery_vars['mode'])
{
	case 'album': // album view
		$sys_tmpl_vars['content'] = "/plugins/".$db->f("install_path")."gallery_album.html";
	break;
	
	default: // thumbnails view
		$sys_tmpl_vars['content'] = "/plugins/".$db->f("install_path")."gallery.html";
	break;
}
?>