<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - plugins/change_pw/change_pw.php -
//
// Copyrights (c) 2006-2009 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

// check plugin ID
// change_pw must have "17"
if($login_required == 0 && $sys_explorer_vars['link_plugin'] == 17) {

	// set template block
	$tpl->set_block("template_content", "content", "content_handle");
	
	// init db connection
	$db2 = new DB_Tpl();
	
	// No print view
	$sys_print_vars['print'] = "";
	
	$sys_plugin_vars['title'] = "";
			
	$error = "";
	if(isset($_POST['send']) && $perm->check_session() == 1 && $sys_group_vars['demo'] == 0) {
		// Block external postings
		$HTTP_REFERER = $_SERVER['HTTP_REFERER'];
		if(strpos($HTTP_REFERER,$_SERVER['SERVER_NAME']) == 0) {
			load_url("index.php");
		}
		// Validate input fields
		$_POST['old_pw'] = validate_text($_POST['old_pw']);
		$_POST['new_pw'] = validate_text($_POST['new_pw']);
		$_POST['new_pw_confirm'] = validate_text($_POST['new_pw_confirm']);
		$old_password = md5($_POST['old_pw']);
		
		// check valid old pwd
		if($old_password != $perm->get_current_password($db2)) {
			$error = "<p class='error'>".get_caption('ErrorOldPassword')."</p>";
		}
		
		// check new pwd
		if(!mandatory_field($_POST['new_pw']) && $error == "") { $error = "<p class='error'>".get_caption('ErrorPassword')."</p>"; }
		if(!check_string_rules($_POST['new_pw'],6) && $error == "") { $error = "<p class='error'>".get_caption('ErrorPasswordShort')."</p>"; }
		if(!check_string_rules($_POST['new_pw'],6,$sys_setting_vars['pw_rule']) && $error == "") { $error = "<p class='error'>".get_caption('ErrorPasswordValid'.$sys_setting_vars['pw_rule'])."</p>"; }
		if($_POST['new_pw'] != $_POST['new_pw_confirm'] && $error == "") { $error = "<p class='error'>".get_caption('RegErrorPassword')."</p>"; }
		
		// change password in db
		if($error == "") {
			$db2->query("UPDATE ".$tbl_prefix."sys_user SET password = '".md5($_POST['new_pw'])."' WHERE uid = '".$_SESSION["uid"]."' ORDER BY uid LIMIT 1");
			
			$error = "<p class='bold'>".get_caption('PasswordChanged')."</p>";
			unset($_POST);
		}
	}
	
	// show error if user is not logged in and page is not group protected
	if($perm->check_session() == 0) {
		$error = "<p class='error'>".get_caption('You must be logged in to change your password.')."</p>";
	}
	
	$tpl->set_var(array(
		"plugin_title"            => "<h1>".get_caption('ChangePw')." - ".get_caption('MyAccount')."</h1>",
		"plugin_action"           => $_SERVER['REQUEST_URI'],
		"plugin_error"            => $error,
		"plugin_old_pw"           => get_caption('OldPassword'),
		"plugin_old_pw_input"     => "<input type='password' name='old_pw' size='25' maxlength='250' value='".$_POST['old_pw']."' />",
		"plugin_new_pw"           => get_caption('NewPassword'),
		"plugin_new_pw_input"     => "<input type='password' name='new_pw' size='25' maxlength='250' value='".$_POST['new_pw']."' />",
		"plugin_pw_confirm"       => get_caption('RegPassword'),
		"plugin_pw_confirm_input" => "<input type='password' name='new_pw_confirm' size='25' maxlength='250' value='".$_POST['new_pw_confirm']."' />",
		"plugin_button_send"      => "<input type='submit' name='send' value='".get_caption('SaveChanges')."' />"
		));
	$tpl->parse("content_handle", "content", true);
}

?>