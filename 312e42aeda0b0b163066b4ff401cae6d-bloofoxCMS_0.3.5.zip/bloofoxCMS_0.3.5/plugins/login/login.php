<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - plugins/login/login.php -
//
// Copyrights (c) 2006-2008 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

// set template block
$tpl->set_block("plugin_login", "login", "login_handle");
if($login_ok == 0) {
	// get page with register form
	$db2->query("SELECT eid,name FROM ".$tbl_prefix."sys_explorer WHERE link_type = '3' && link_plugin = '15' && config_id = '".$sys_explorer_vars['config_id']."' LIMIT 1");
	while($db2->next_record()):
		$sys_vars['login_register'] = "<p class='small'><a href='".create_url($db2->f("eid"),$db2->f("name"),$sys_config_vars['mod_rewrite'])."' title='".$db2->f("name")."'>".$db2->f("name")."</a></p>";
	endwhile;
	
	// create login form
	$login_vars['form'] = ""
		."<form action=\"index.php?login=true\" method=\"post\">"
		.get_caption('Username')."<br />"
		."<input type='text' name='username' size='20' /><br />"
		.get_caption('Password')."<br />"
		."<input type='password' name='password' size='20' /><br />"
		."<input type='submit' value='".get_caption('Login')."' name='login' /><br />"
		.$sys_vars['login_register']
		."</form>";
	
	// assign variables to template
	$tpl->set_var(array(
		"login_title"      => get_caption('Login'),
		"login_form"       => $login_vars['form']
	));
}

if($login_ok == 1) {
	// create hyperlink to admincenter
	if(!empty($sys_vars['curr_admin'])) {
		$sys_vars['account_menu'] = "<li>".$sys_vars['curr_admin']."</li>";
	}
	// get page with change password form
	$db2->query("SELECT eid,name FROM ".$tbl_prefix."sys_explorer WHERE link_type = '3' && link_plugin = '17' && config_id = '".$sys_explorer_vars['config_id']."' LIMIT 1");
	while($db2->next_record()):
		$sys_vars['login_changepw'] = "<li><a href='".create_url($db2->f("eid"),get_caption('ChangePw'),$sys_config_vars['mod_rewrite'])."' title='".get_caption('ChangePw')."'>".get_caption('ChangePw')."</a></li>";
	endwhile;

	// create account menu
	$login_form = "<ul class='login_menu'>"
		.$sys_vars['account_menu']
		."<li><a href='index.php?page=".$sys_vars['login_page']."' title='".get_caption('Home')."'>".get_caption('Home')."</a></li>"
		.$sys_vars['login_changepw']
		."<li>".$sys_vars['curr_logout']."</li>"
		."</ul>";
		
	// assign variables to template
	$tpl->set_var(array(
		"login_title"      => get_caption('MyAccount'),
		"login_form"       => $login_form
	));
}

// parse template
$tpl->parse("login_handle", "login", true);
?>