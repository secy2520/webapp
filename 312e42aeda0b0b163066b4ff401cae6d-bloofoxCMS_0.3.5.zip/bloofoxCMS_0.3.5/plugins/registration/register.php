<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - plugins/registration/register.php -
//
// Copyrights (c) 2006-2009 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

// check plugin ID
// register must have "15"
if($login_required == 0 && $sys_explorer_vars['link_plugin'] == 15) {

	// set template block
	$tpl->set_block("template_content", "content", "content_handle");
	
	// init db connection
	$db2 = new DB_Tpl();
	
	// No print view
	$sys_print_vars['print'] = "";
	
	switch($reg_vars['get'])
	{
		case '2': // register finished
			$sys_plugin_vars['title'] = "- ".get_caption('RegNewDone');
			
			$tpl->set_var(array(
				"reg_title"      => "<h1>".get_caption('RegNewDone')."</h1>",
				"reg_action"     => "",
				"reg_error"      => $error,
				"reg_info"       => "<p>".get_caption('RegDone')."</p>"
				));
			$tpl->parse("content_handle", "content", true);
		break;
	
		case '3': // registration confirmed, account activated
			$sys_plugin_vars['title'] = "- ".get_caption('RegNewConfirm');
			$confirm = "<p>".get_caption('RegConfirm')."</p>";
			
			$db2->query("SELECT uid FROM ".$tbl_prefix."sys_user WHERE `key` = '".$_GET['key']."' && status = '0' && blocked = '0'");
			$num_rows = $db2->num_rows();
			$db2->query("UPDATE ".$tbl_prefix."sys_user SET `status` = '1' WHERE `key` = '".$_GET['key']."' && status = '0' && blocked = '0'");
			if($num_rows == 0) {
				$error = "<p class='error'>".get_caption('RegConfirmError')."</p>";
				$confirm = "";
			}
			
			$tpl->set_var(array(
				"reg_title"      => "<h1>".get_caption('RegNewConfirm')."</h1>",
				"reg_action"     => "",
				"reg_error"      => $error,
				"reg_info"       => $confirm
				));
			$tpl->parse("content_handle", "content", true);
		break;
		
		default: // register new account
			$sys_plugin_vars['title'] = "- ".get_caption('RegNew');
			
			$error = "";
			if(isset($_POST['send'])) {
				// Block external postings
				$HTTP_REFERER = $_SERVER['HTTP_REFERER'];
				if(strpos($HTTP_REFERER,$_SERVER['SERVER_NAME']) == 0) {
					load_url("index.php");
				}
				// Validate input fields
				$_POST['un'] = validate_text($_POST['un']);
				$_POST['un'] = strtolower($_POST['un']);
				$_POST['pwd'] = validate_text($_POST['pwd']);
				$_POST['pwd2'] = validate_text($_POST['pwd2']);
				$_POST['em'] = validate_text($_POST['em']);
				$_POST['code'] = validate_text($_POST['code']);
									
				if(!mandatory_field($_POST['un']) && $error == "") { $error = "<p class='error'>".get_caption('ErrorUsername')."</p>"; }
				if(!check_string_rules($_POST['un'],3) && $error == "") { $error = "<p class='error'>".get_caption('ErrorUsernameShort')."</p>"; }
				if(!available_username($db2,$_POST['un']) && $error == "") { $error = "<p class='error'>".get_caption('ErrorUsernameExist')."</p>"; }
				if(!mandatory_field($_POST['pwd']) && $error == "") { $error = "<p class='error'>".get_caption('ErrorPassword')."</p>"; }
				if(!check_string_rules($_POST['pwd'],6) && $error == "") { $error = "<p class='error'>".get_caption('ErrorPasswordShort')."</p>"; }
				if(!check_string_rules($_POST['pwd'],6,$sys_setting_vars['pw_rule']) && $error == "") { $error = "<p class='error'>".get_caption('ErrorPasswordValid'.$sys_setting_vars['pw_rule'])."</p>"; }
				if($_POST['pwd'] != $_POST['pwd2'] && $error == "") { $error = "<p class='error'>".get_caption('RegErrorPassword')."</p>"; }
				if(!email_is_valid($_POST['em']) && $error == "") { $error = "<p class='error'>".get_caption('ErrorEmailValid')."</p>"; }
				if(($_SESSION["register"] != $_POST['code'] || !mandatory_field($_POST['code'])) && $error == "") { $error = "<p class='error'>".get_caption('ErrorCaptcha')."</p>"; }
				
				if($error == "") {
				// create account in db
					$_POST['pwd'] = md5($_POST['pwd']);
					$reg_vars['timestamp'] = time();
					
					$reg_vars['group'] = "";
					$db2->query("SELECT name FROM ".$tbl_prefix."sys_usergroup WHERE gid = '".$sys_config_vars["default_group"]."' ORDER BY gid");
					while($db2->next_record()):
						$reg_vars['group'] .= $db2->f("name").",";
					endwhile;
					$reg_vars['group'] = substr($reg_vars['group'],0,-1);
					
					// generate key for confirmation
					mt_srand((double)microtime()*1000000);
					$reg_vars['signs'] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890";
					$reg_vars['key'] = "";
					while(strlen($reg_vars['key']) < 10)
					{
						$reg_vars['key'] .= substr($reg_vars['signs'],(rand()%(strlen($reg_vars['signs']))),1);
					}
					
					$db2->query("INSERT INTO ".$tbl_prefix."sys_user (`uid`,`username`,`password`,`groups`,`online_status`,`blocked`,`deleted`,`status`,`user_since`,`last_login`,`curr_login`,`key`) VALUES ('','".$_POST['un']."','".$_POST['pwd']."','".$reg_vars['group']."','0','0','".$sys_config_vars['user_deleted']."','0','".$reg_vars['timestamp']."','0','0','".$reg_vars['key']."')");
					$db2->query("SELECT uid FROM ".$tbl_prefix."sys_user WHERE username = '".$_POST['un']."' LIMIT 1");
					while($db2->next_record()):
						$user_id = $db2->f("uid");
					endwhile;
					$db2->query("INSERT INTO ".$tbl_prefix."sys_profile VALUES ('','".$user_id."','','','','','','','".$_POST['em']."','','".$_POST['gender']."','','0','0','0')");
					
					// send email to new user
					$regmsg = get_caption('RegMsg');
					$regmsg = str_replace("[USERNAME]",$_POST['un'],$regmsg);
					$regmsg = str_replace("[HYPERLINK]",$sys_config_vars['url']."/index.php?page=".$sys_explorer_vars['eid']."&register=3&key=".$reg_vars['key'],$regmsg);
					$regmsg = str_replace("[AUTHOR]",$sys_config_vars['meta_author'],$regmsg);
					$regmsg = str_replace("[URL]",$sys_config_vars['url'],$regmsg);
					
					send_mail($_POST['em'],$sys_config_vars['mail'],get_caption('RegSubject'),$regmsg,$sys_setting_vars['html_mails']);
					// send email to admin
					if($sys_setting_vars['register_notify'] == "1") {
						$regmsg = get_caption('RegMsgAdmin');
						$regmsg = str_replace("[USERNAME]",$_POST['un'],$regmsg);
						$regmsg = str_replace("[EMAIL]",$_POST['em'],$regmsg);
						$regmsg = str_replace("[GENDER]",$_POST['gender'],$regmsg);
						$regmsg = str_replace("[URL]",$sys_config_vars['url'],$regmsg);
						if(!empty($sys_setting_vars['admin_mail'])) {
							$sys_config_vars['mail'] = $sys_setting_vars['admin_mail'];
						}
						send_mail($sys_config_vars['mail'],$sys_config_vars['mail'],"NOTIFY: ".get_caption('RegSubject'),$regmsg,$sys_setting_vars['html_mails']);
					}
					
					// header to step 2
					load_url("index.php?page=".$sys_explorer_vars['eid']."&register=2");
				}
			}
			
			include("system/class_captcha.php");
			$captcha = new captcha('temp');
			
			$tpl->set_var(array(
				"reg_title"        => "<h1>".get_caption('RegNew')."</h1>",
				"reg_action"       => $_SERVER['REQUEST_URI'],
				"reg_error"        => $error,
				"reg_info"         => "<p>".get_caption('RegInfo')."</p>",
				"reg_user"         => get_caption('Username'),
				"reg_user_input"   => "<input type='text' name='un' size='30' maxlength='80' value='".$_POST['un']."' />",
				"reg_pass"         => get_caption('Password'),
				"reg_pass_input"   => "<input type='password' name='pwd' size='20' maxlength='80' />",
				"reg_pass2"        => get_caption('RegPassword'),
				"reg_pass2_input"  => "<input type='password' name='pwd2' size='20' maxlength='80' />",
				"reg_email"        => get_caption('Email'),
				"reg_email_input"  => "<input type='text' name='em' size='30' maxlength='250' value='".$_POST['em']."' />",
				"reg_gender"       => get_caption('Gender'),
				"reg_gender_input" => "<input type='radio' name='gender' value='1' checked='checked' />".get_caption('GenderFemale')." <input type='radio' name='gender' value='0' />".get_caption('GenderMale'),
				"reg_captcha"      => get_caption('CaptchaCode'),
				"reg_captcha_input"=> "<img src='captcha.php?var=register' border='0' alt='Captcha' width='".$captcha->get_image_width()."' height='".$captcha->get_image_height()."' /><br /><input type='text' name='code' />",
				"reg_submit"       => "<input type='submit' name='send' value='".get_caption('RegNewSubmit')."' />"
				));
			$tpl->parse("content_handle", "content", true);
		break;
	}
}

?>