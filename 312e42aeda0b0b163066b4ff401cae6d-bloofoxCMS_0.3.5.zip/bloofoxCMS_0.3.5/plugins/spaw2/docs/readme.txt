SPAW Editor PHP Edition v.2.0.3
-------------------------------
Thank you for downloading SPAW Editor!

SPAW Editor PHP Edition version 2.0 adds following major features:
- completely redesigned and rewritten modular architecture
- tabbed multi-document interface
- floating/shared toolbars
- resizable editing area
- context menu
- file manager plugin
- support for Opera 9 browser
- and many more

Installation, configuration, etc.
---------------------------------
Basic isntallation is as simple as extracting all the files and uploading to
a directory on your web server. Then you need to rename config/config.default.php
file to config/config.php (if installing for the first time) and you are ready
to start using SPAW. Point your browser to http://yourdomain.com/spaw2/demo/demo.php
to check your installation

For detailed configuration and usage instructions refer to integrator's guide
in docs/documentation/integrators.html

Licence
-------
SPAW Editor is released under the terms for GNU General Public License Version 2.
Refer to the file docs/license.txt for details.

In case you would like to use SPAW Editor on other terms than described in GPL
you can obtain a commercial license by visiting our purchase page at
http://www.solmetra.lt/en/disp.php/en_products/en_spaw/en_spaw_purchase

Getting Support
---------------
Get answers to your questions, post your ideas and suggestions in our forums at
http://forums.solmetra.com

Get latest development updates and other (not always) useful information in our
developer blog at http://blog.solmetra.com
