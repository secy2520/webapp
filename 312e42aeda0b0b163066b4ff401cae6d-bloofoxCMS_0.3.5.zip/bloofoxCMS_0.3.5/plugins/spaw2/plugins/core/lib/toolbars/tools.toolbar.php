<?php
$items = array
(
  new SpawTbButton("core", "cleanup", "isInDesignMode", "", "codeCleanupClick"),
  new SpawTbButton("core", "toggle_borders", "isInDesignMode", "toggleBordersPushed", "toggleBordersClick"),
  new SpawTbImage("core", "separator"),
);
?>
