<?php
$items = array
(
  new SpawTbDropdown("core", "fontname", "isStandardFunctionEnabled", "standardFunctionStatusCheck", "standardFunctionChange"),
  new SpawTbDropdown("core", "fontsize", "isStandardFunctionEnabled", "standardFunctionStatusCheck", "standardFunctionChange"),
  new SpawTbImage("core", "separator"),
);
?>
