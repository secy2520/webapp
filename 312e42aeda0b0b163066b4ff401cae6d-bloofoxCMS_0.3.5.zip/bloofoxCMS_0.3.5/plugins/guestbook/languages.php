<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - plugins/guestbook/languages.php -
//
// Copyrights (c) 2008 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

switch($sys_vars['language'])
{
	case "english.php":
	// English
	$str['gb_SignGuestbook'] = "Sign the guestbook";
	$str['gb_Posted'] = "Posted";
	$str['gb_on'] = "on";
	$str['gb_by'] = "by";
	$str['gb_Comment'] = "Comment";
	$str['gb_Prev'] = "Previous";
	$str['gb_Next'] = "Next";
	break;
	
	case "deutsch.php":
	// Deutsch
	$str['gb_SignGuestbook'] = "In das G�stebuch schreiben";
	$str['gb_Posted'] = "Geschrieben";
	$str['gb_on'] = "am";
	$str['gb_by'] = "von";
	$str['gb_Comment'] = "Kommentar";
	$str['gb_Prev'] = "Vorherige";
	$str['gb_Next'] = "N�chste";
	break;
	
	default:
	// default, if language file could not be identified
	$str['gb_SignGuestbook'] = "Sign the guestbook";
	$str['gb_Posted'] = "Posted";
	$str['gb_on'] = "on";
	$str['gb_by'] = "by";
	$str['gb_Comment'] = "Comment";
	$str['gb_Prev'] = "Previous";
	$str['gb_Next'] = "Next";
	break;
}
?>