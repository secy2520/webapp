<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - plugins/guestbook/admin.php -
//
// Copyrights (c) 2008 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

switch($page)
{
	case "del":
		if(isset($_POST['send']) && $sys_group_vars['demo'] == 0) {
			if(CheckInteger($_POST['cid'])) {
				$db->query("DELETE FROM ".$tbl_prefix."plugin_gbook WHERE cid = '".$_POST['cid']."'");
			}
			
			load_url("index.php?mode=plugins&pluginID=1000");
		}
		
		// select record
		if(isset($_POST['cid'])) {
			$_GET['cid'] = $_POST['cid'];
		}
		
		if(!CheckInteger($_GET['cid'])) {
			load_url("index.php?mode=plugins&pluginID=1000");
		}
		
		$db->query("SELECT cid,text FROM ".$tbl_prefix."plugin_gbook WHERE cid = '".$_GET['cid']."' ORDER BY cid LIMIT 1");
		while($db->next_record()):
			$cid = $db->f("cid");
			$text = $db->f("text");
		endwhile;
		
		$tpl->set_var(array(
			"plugins_title"   => "<h1>Plugin: ".$plugin_name."</h1>",
			"plugins_content" => $plugin_content,
			"gb_action"       => "index.php?mode=plugins&pluginID=1000&page=del",
			"gb_question"     => get_caption('DeleteQuestion'),
			"gb_text"         => $text,
			"gb_cid"          => "<input type='hidden' name='cid' value='".$cid."' />",
			"gb_submit"       => "<input class='btn' type='submit' name='send' value='".get_caption('EntryDelete')."' />"
			));
		
		// Parse template with variables
		$tpl->parse("plugins_handle", "plugins", true);
	break;
	
	default: // Plugin
		$db->query("SELECT * FROM ".$tbl_prefix."plugin_gbook ORDER BY cid DESC");
		$gb_vars["rows"] = $db->num_rows();
		
		while($db->next_record()):
			$tpl->set_var(array(
				"plugins_title"   => "<h1>Plugin: ".$plugin_name."</h1>",
				"plugins_content" => $plugin_content,
				"gb_str_date"     => get_caption("Date"),
				"gb_val_date"     => date($sys_vars["datetime"],$db->f("timestamp")),
				"gb_str_name"     => get_caption("Name"),
				"gb_val_name"     => $db->f("name"),
				"gb_str_email"    => get_caption("E-Mail"),
				"gb_val_email"    => $db->f("email"),
				"gb_str_ip"       => get_caption("IP"),
				"gb_val_ip"       => $db->f("ip_address"),
				"gb_str_action"   => get_caption("Action"),
				"gb_val_action"   => "<a href='index.php?mode=plugins&pluginID=1000&page=del&cid=".$db->f("cid")."' class='delete' title='".get_caption('DeleteText')."'>".get_caption('Delete')."</a>"
			));
			
			// Parse template with variables
			$tpl->parse("plugins_handle", "plugins", true);
		endwhile;
		
		if($gb_vars["rows"] == 0) {
			$tpl->set_var(array(
				"plugins_title"   => "<h1>Plugin: ".$plugin_name."</h1>",
				"plugins_content" => $plugin_content,
				"gb_str_date"     => get_caption("Date"),
				"gb_val_date"     => "",
				"gb_str_name"     => get_caption("Name"),
				"gb_val_name"     => "",
				"gb_str_email"    => get_caption("E-Mail"),
				"gb_val_email"    => "",
				"gb_str_ip"       => get_caption("IP"),
				"gb_val_ip"       => "",
				"gb_str_action"   => get_caption("Action"),
				"gb_val_action"   => ""
			));
			
			// Parse template with variables
			$tpl->parse("plugins_handle", "plugins", true);
		}
	break;
}
?>