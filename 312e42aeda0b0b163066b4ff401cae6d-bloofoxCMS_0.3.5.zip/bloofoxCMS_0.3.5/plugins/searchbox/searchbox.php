<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - plugins/searchbox/searchbox.php -
//
// Copyrights (c) 2006-2007 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

// Find result page in explorer
$db2 = new DB_Tpl();
$db2->query("SELECT eid,name FROM ".$tbl_prefix."sys_explorer WHERE config_id = '".$sys_explorer_vars['config_id']."' && link_type = '3' && link_plugin = '3' LIMIT 1");
while($db2->next_record()):
	$search_vars['search_site_url'] = create_url($db2->f("eid"),$db2->f("name"),$sys_config_vars['mod_rewrite']);
endwhile;

// Template Block-Setup
$tpl->set_block("plugin_searchbox", "searchbox", "searchbox_handle");

$tpl->set_var(array(
	"search_title"     => get_caption('Search'),
	"search_action"    => $search_vars['search_site_url'],
	"search"           => $_POST['search'],
	"search_submit"    => "<input type='submit' value='".get_caption('SearchSubmitShort')."' />"
));
			 
$tpl->parse("searchbox_handle", "searchbox", true);
?>