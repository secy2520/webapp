<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - plugins/plugin_module/plugin.php -
//
// Copyrights (c) 2006-2008 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

// Some variables
$plugin_module['title'] = "Sample plugin";

$plugin_module['content'] = "This is only a sample plugin. You may use it as a template for your own module plugins";

// Template Block-Setup
$tpl->set_block("plugin_plugin_module", "plugin_module", "plugin_module_handle");

$tpl->set_var(array(
	"plugin_title"    => $plugin_module['title'],
	"plugin_content"  => $plugin_module['content']
	));

$tpl->parse("plugin_module_handle", "plugin_module", true);
?>