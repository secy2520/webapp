<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - plugins/date/install.php -
//
// Copyrights (c) 2006 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

// Version
$sys_plugin_vars['version'] = "1.0";

// Parameter
$sys_plugin_vars['pluginID'] = 1;
$sys_plugin_vars['index_file'] = "date.php";
$sys_plugin_vars['index_tmpl'] = "date.html";
$sys_plugin_vars['tmpl_handler'] = "";
$sys_plugin_vars['admin_file'] = "";
$sys_plugin_vars['admin_handler'] = "";
$sys_plugin_vars['plugin_type'] = 0;

// Queries

?>