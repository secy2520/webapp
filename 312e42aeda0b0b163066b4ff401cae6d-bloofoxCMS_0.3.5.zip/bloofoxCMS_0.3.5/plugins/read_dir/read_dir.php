<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - plugins/read_dir/read_dir.php -
//
// Copyrights (c) 2006-2009 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

// check plugin ID
// Read Dir must have "21"
if($login_required == 0 && $sys_explorer_vars['link_plugin'] == 21) {

	$sys_print_vars['print'] = "";
	
	// set template block
	$tpl->set_block("template_content", "read_dir", "read_dir_handle");
	
	// Read dir
	$default_folder = "templates/";
	$folder = opendir($default_folder);
	$dir_files = "";

	while($file = readdir($folder))
	{
		if($file != "." && $file != ".." && !is_dir($file)) // only files
		{
			$dir_files .= "<a href='".$default_folder.$file."'>".$file."</a><br />";
		}
	}
	closedir($folder);
	
	$tpl->set_var(array(
		"plugin_title"       => "<h1>".$sys_explorer_vars['name']."</h1>",
		"plugin_action"      => $_SERVER['REQUEST_URI'],
		"plugin_error"       => $error,
		"plugin_content"     => $dir_files
		));
}

// parse template
$tpl->parse("read_dir_handle", "read_dir", true);
?>