<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - plugins/text_details/text_details.php -
//
// Copyrights (c) 2006-2009 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

// check plugin ID
// text_news must have "33"
if($login_required == 0 && $sys_explorer_vars['link_plugin'] == 33) {
	// css
	$sys_plugin_vars['css'] = "<link href=\"plugins/text_details/text.css\" rel=\"stylesheet\" type=\"text/css\" />\n";
	
	// print view
	$sys_print_vars['print'] = "<div class='print'><a href='index.php?page=".$sys_explorer_id."&amp;cid=".$_GET['cid']."&amp;print=1' target='print' title='".get_caption('Print')."'>".get_caption('Print')."</a></div>";
	
	// set template block
	$tpl->set_block("template_content", "content", "content_handle");

	// get sys_contents
	$db2->query("SELECT * FROM ".$tbl_prefix."sys_content WHERE cid = '".$_GET['cid']."' AND blocked = '0' LIMIT 1");
	$no_of_records = $db2->num_rows();
	
	while($db2->next_record()):
		$text = $cont->format_text($db2->f("text"));
		
		$tpl->set_var(array(
			"title"        => "<a name='".$db2->f("cid")."'></a>".$db2->f("title"),
			"text"         => $text
		));
	
		// parse template
		$tpl->parse("content_handle", "content", true);
	endwhile;
	
	// if no contents were found show this content
	if($no_of_records == 0) {
		load_url($sys_config_vars['url']);
	}
}
?>