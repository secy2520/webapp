<?php
//*****************************************************************//
// This file is part of bloofoxCMS! Do not delete this copyright!!!
// - plugins/submenu/submenu.php -
//
// Copyrights (c) 2006-2007 Alexander Lang, Germany
// info@bloofox.com
// http://www.bloofox.com
//
// bloofoxCMS is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// any later version.
//
// bloofoxCMS is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with bloofoxCMS; if not, please contact the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//*****************************************************************//

$curr_time = time();
$db2 = new DB_Tpl();

// Set Template Block for "submenu"
$tpl->set_block("plugin_submenu", "submenu", "submenu_handle");

// Select Records
$db2->query("SELECT * FROM ".$tbl_prefix."sys_explorer WHERE preid = '".$sys_explorer_vars['eid']."' && blocked = '0' && invisible = '0' && startdate < '".$curr_time."' && (enddate > '".$curr_time."' || enddate = '') ORDER BY sorting");
$menu_vars['total'] = $db2->num_rows();

if($menu_vars['total'] == 0) {
	$db2->query("SELECT * FROM ".$tbl_prefix."sys_explorer WHERE level > 2 && preid = '".$sys_explorer_vars['preid']."' && blocked = '0' && invisible = '0' && startdate < '".$curr_time."' && (enddate > '".$curr_time."' || enddate = '') ORDER BY sorting");
	$menu_vars['total'] = $db2->num_rows();
}

if($login_required == 0) {
	while($db2->next_record()):
		$menu_vars['target'] = "";
		if($db2->f("link_target") != "") {
			$menu_vars['target'] = "target='".$db2->f("link_target")."'";
		}
		$menu_vars['active'] = "";
		if($sys_explorer_vars['eid'] == $db2->f("eid")) {
			$menu_vars['active'] = "class='active'";
		}
	
		if($db2->f("link_type") == 1) {
			$menu_vars['name'] = "<a ".$menu_vars['active']." href='".$db2->f("link_url")."' ".$menu_vars['target']." title='".$db2->f("name")."'>".$db2->f("name")."</a>";
		} else {
			$menu_vars['name'] = "<a ".$menu_vars['active']." href='".create_url($db2->f("eid"),$db2->f("name"),$sys_config_vars['mod_rewrite'])."' ".$menu_vars['target']." title='".$db2->f("name")."'>".$db2->f("name")."</a>";
		}

		// Set Variables
		$tpl->set_var(array(
			"menu_title"  => "<p class='bold'>".get_caption('Contents')."</p>",
			"menu_name"   => $menu_vars['name']
			));
		// Parse Template
		$tpl->parse("submenu_handle", "submenu", true);
	endwhile;
}

if($login_required == 1 || $menu_vars['total'] == 0)
{
	$tpl->set_var(array(
		"menu_title"  => "",
		"menu_name"   => ""
		));
	$tpl->parse("submenu_handle", "submenu", true);
}
?>